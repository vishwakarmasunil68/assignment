import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VerifyNowOrderPage } from './verify-now-order';

@NgModule({
  declarations: [
    VerifyNowOrderPage,
  ],
  imports: [
    IonicPageModule.forChild(VerifyNowOrderPage),
  ],
})
export class VerifyNowOrderPageModule {}
