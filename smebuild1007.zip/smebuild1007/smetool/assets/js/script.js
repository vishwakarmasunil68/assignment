 function dob(){
	// alert(123);
	 $('#BirthDate').addClass('durgesh');
	var d = new Date();
	var year = d.getFullYear() - 18;
	d.setFullYear(year);
	$('#BirthDate').datepicker({ changeYear: true, dateFormat: 'dd/mm/yy', changeMonth: true, yearRange: '1920:' + year + '', defaultDate: d});
  }

 $(window).bind("pageshow", function() {
	 $("form")[0].reset();
 });

	$(document).ready(function(){
		dob();
		//var 
		$('.fen-quiz-step.active').find(":radio").change(function() {
			var names = {};
			$(':radio').each(function() {
				names[$(this).attr('name')] = true;
			});
			var count = 0;
			$.each(names, function() { 
				count++;
			});
			if ($(':radio:checked').length === count) {
				//alert("all answered");
			}
		}).change();

		$('.quiz-wrapper').on('click', '.validateSlides > a.next-quiz', function(){
			var count = 0;
			var textbox = 0;
			var radiobtn = 0;
			var msgN = "";
			var index = $(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').index();
			if(index == 0)
			{
				$(this).parent().parent().find('.prev-quiz').show();
				$('#aviva_sme_form').yiiActiveForm('validateAttribute', 'dynamicmodel-name');
				$('#aviva_sme_form').yiiActiveForm('validateAttribute', 'dynamicmodel-mobile');
				$('#aviva_sme_form').yiiActiveForm('validateAttribute', 'dynamicmodel-dob');
				$('#aviva_sme_form').yiiActiveForm('validateAttribute', 'dynamicmodel-email');
				$('#aviva_sme_form').yiiActiveForm('validateAttribute', 'dynamicmodel-company');
				$('#aviva_sme_form').yiiActiveForm('validateAttribute', 'dynamicmodel-city');
				$('#aviva_sme_form').yiiActiveForm('validateAttribute', 'dynamicmodel-terms_condition');
				setTimeout(function(){
					if(!$('#aviva_sme_form').find('.has-error').length > 0) {
						$('.quiz-wrapper .validateSlides > a.next-quiz').parents(".final-action").parent().find('.fen-quiz-steps').find('.fen-quiz-step').eq(0).removeClass('active');
						$('.quiz-wrapper .validateSlides > a.next-quiz').parents(".final-action").parent().find('.fen-quiz-steps').find('.fen-quiz-step').eq(1).addClass('active');
						//$(this).parents(".questions-wrap").parent().parent().parent().addClass('hide');
						//$(this).parents(".questions-wrap").parent().parent().parent().next().removeClass('hide');
						$('.quiz-wrapper .validateSlides > a.next-quiz').parent().prev().find('.prev-quiz').css('visibility', 'visible');
						$('.quiz-wrapper .validateSlides > a.next-quiz').parent().prev().removeClass('firstPrev');
						$("html, body").scrollTop(0);
					}
				}, 200);
			}
			else if (index == 1)
			{
				var count2 = 0;
				var msg2 = 0;

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="rating"]').is(':checked')){
					$('.answer .error_block_q1').text("Please select your company structure (company-type)");
					msg2 += 1;
				}else{
					count2 = count2 + 1;
				}

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="pbe"]').is(':checked')){
					$('.error_block_q7').text("Please answer if your are planing for business expansion");
					msg2 += 1;
				}else{
					count2 = count2 + 1;
				}

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('.check_radio_cmb').is(':checked')){
					$('.error_block_q8').text("Please answer if you have taken any loans");
					msg2 += 1;
				}else{
					count2 = count2 + 1;
				}

				if($(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input.dependbefore.active').val() == ""){
					$('.error_block_q9').text("Please input unsecured loan amount");
					msg2 += 1;
				}else{
					count2 = count2 + 1;
				}

				if($(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input.aturn.active').val() == ""){
					$('.error_block_q3').text("Please enter your company's annual turnover");
					$('.error_block_q5').text("Please enter your company's annual turnover");
					msg2 += 1;
				}else{
					count2 = count2 + 1;
				}

				if($(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input.assetval.active').val() == ""){
					$('.error_block_q4').text("Please enter your total asset value of your company");
					$('.error_block_q6').text("Please enter your total asset value of your company");
					msg2 += 1;
				}else{
					count2 = count2 + 1;
				}

				if(partnership == 0){
					var count = 0;
					var zero = 1;
					var newmsg = '';
					$('.fen-quiz-step').eq(1).find('input[name^="share"]').each(function(i){
						var alln = parseFloat($(this).val());
						count = count + alln;
						if($(this).val() == ""){
							msg2 += 1;
							newmsg += (i+1)+ ' , ';
							$('.error_block_q1a').text('Please input share for partner '+ newmsg.replace(/,\s*$/, ""));
						}
						else if(alln <= "0"){
							msg2 += 1;
							newmsg += 'partner\'s share value can\'t be 0\n\n ';
							zero = 0;
						}
						else {
							$('.error_block_q1a').text('');
						}
					});
					if(count < 100){
						$('.error_block_q1a').text('The sum of share between partners should be 100 \n\n');
					}
					if(count != 100){
						msg2 += 'The sum of share between partners should be 100 \n\n';
					}
					if(count == 100 && zero != 0){
						count2 = count2 + 1;
					}
				}
				else{
					count2 = count2 + 1;
				}

				if(count2 == 7){
					$(this).parents(".final-action").parent().find('.fen-quiz-steps').find('.fen-quiz-step').eq(1).removeClass('active');
					$(this).parents(".final-action").parent().find('.fen-quiz-steps').find('.fen-quiz-step').eq(2).addClass('active');
					$("html, body").scrollTop(0);
				}
			}
			else if(index == 2)
			{

				$('#aviva_sme_form').yiiActiveForm('validateAttribute', 'dynamicmodel-keypeople');

				var count3 = 0;
				var msg3 = "";
				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="remp"]').is(':checked')){
					$('.error_block_q10').text("Please select the number of on-roll employees");
				}else{
					count3 = count3 + 1;
				}

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="empCha"]').is(':checked')){
					$('.error_block_q12').text("Please select answer for Is retention of key employees a challenge for your business?");
				}else{
					count3 = count3 + 1;
				}

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('.wabi').is(':checked')){
					$('.error_block_q13').text("Please select your existing business insurance plans");
				}else{
					count3 = count3 + 1;
				}

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="gratuityemp"]').is(':checked')){
					$('.error_block_q14').text("Please select answer for Have you made provisions for gratuity for your employees?");
				}else{
					count3 = count3 + 1;
				}

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="edli"]').is(':checked')){
					$('.error_block_q15').text("Please select answer for Have you opted for an EDLI scheme?");
				}else{
					count3 = count3 + 1;
				}

				if(count3 == 5){
					$("html, body").scrollTop(0);
					$(this).parents(".final-action").parent().find('.fen-quiz-steps').find('.fen-quiz-step').eq(2).removeClass('active');
					$(this).parents(".final-action").parent().find('.fen-quiz-steps').find('.fen-quiz-step').eq(3).addClass('active');
					$(this).parent().hide();
					$(this).parent().next().addClass('tableCell');
				}
			}
			else if(index == 3){

				$('#aviva_sme_form').yiiActiveForm('validateAttribute', 'dynamicmodel-ins_cover');
				$('#aviva_sme_form').yiiActiveForm('validateAttribute', 'dynamicmodel-anual_income');

				var count4 = 0;
				var msg4 = "";

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="tiyfamily"]').is(':checked')){
					$('.error_block_q16').text("Please describe your immediate family/dependents.");
				}else{
					count4 = count4 + 1;
				}

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="hypa_insurance"]').is(':checked')){
					$('.error_block_q18').text("Please select anser for Have you purchased any Insurance Plan under MWP Act to protect your family?");
				}else{
					count4 = count4 + 1;
				}

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="variance_income"]').is(':checked')){
					$('.error_block_q20').text("Please select the approximate fluctuation in your annual income?");
				}else{
					count4 = count4 + 1;
				}

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="manageFmlexpance"]').is(':checked')){
					$('.error_block_q21').text("Please select answer for How do you manage family expenses?");
				}else{
					count4 = count4 + 1;
				}

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="spe_invest"]').is(':checked')){
					$('.error_block_q22').text("Please select answer  for Have you made any specific investments for your family?");
				}else{
					count4 = count4 + 1;
				}

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="manage_household"]').is(':checked')){
					$('.error_block_q23').text("Please select answer  for manage household expenses in case of any unfortunate event?");
				}else{
					count4 = count4 + 1;
				}

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="QualiEdu"]').is(':checked')){
					$('.error_block_q24').text("Please select answer  for Have you started planning for your child/children’s education?");
				}else{
					count4 = count4 + 1;
				}

				if(!$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').find('input[name="retirePlan"]').is(':checked')){
					$('.error_block_q26').text("Please select answer  for Have you planned for your retirement years?");
				}else{
					count4 = count4 + 1;
				}

				if(count4 == 8){
					$("html, body").scrollTop(0);
					$(this).parent().next().find('a').trigger('click');
					$("#aviva_sme_form").submit();
				}

			}

		});

		$("body").on("click", "input[name='aturn']", function(){
			$('.error_block_q5').text("");
			$('.error_block_q3').text("");
		});

		$("body").on("click", "input[name='aturn1']", function(){
			$('.error_block_q5').text("");
			$('.error_block_q3').text("");
		});

		$("body").on("click", "input[name^='share']", function(){
			$('.error_block_q1a').text("");
		});

		$("body").on("click", "input[name='tvasset']", function(){
			$('.error_block_q4').text("");
			$('.error_block_q6').text("");
		});

		$("body").on("click", "input[name='tvasset1']", function(){
			$('.error_block_q4').text("");
			$('.error_block_q6').text("");
		});

		$("body").on("click", "input[name='pbe']", function(){
			$('.error_block_q7').text("");
		});

		$("body").on("click", "input[name='taken_loan']", function(){
			$('.error_block_q8').text("");
			$("input[name='ulout']").val('');
		});

		$("body").on("click", "input[name='ulout']", function(){
			$('.error_block_q9').text("");
		});

		$("body").on("click", "input[name='remp']", function(){
			$('.error_block_q10').text("");
		});

		$("body").on("click", "input[name='empCha']", function(){
			$('.error_block_q12').text("");
		});

		$("body").on("click", "input[name^='bisSB']", function(){
			$('.error_block_q13').text("");
		});

		$("body").on("click", "input[name='gratuityemp']", function(){
			$('.error_block_q14').text("");
		});

		$("body").on("click", "input[name='edli']", function(){
			$('.error_block_q15').text("");
		});

		$("body").on("click", "input[name='tiyfamily']", function(){
			$('.error_block_q16').text("");
		});

		$("body").on("click", "input[name='hypa_insurance']", function(){
			$('.error_block_q18').text("");
		});

		$("body").on("click", "input[name='variance_income']", function(){
			$('.error_block_q20').text("");
		});

		$("body").on("click", "input[name='manageFmlexpance']", function(){
			$('.error_block_q21').text("");
		});

		$("body").on("click", "input[name='spe_invest']", function(){
			$('.error_block_q22').text("");
		});

		$("body").on("click", "input[name='manage_household']", function(){
			$('.error_block_q23').text("");
		});

		$("body").on("click", "input[name='QualiEdu']", function(){
			$('.error_block_q24').text("");
		});

		$("body").on("click", "input[name='retirePlan']", function(){
			$('.error_block_q26').text("");
		});

		$('#terms_condition').change(function() {
			if($(this).is(":checked")) {
				$(this.parentNode).addClass('active');
			} else {
				$(this.parentNode).removeClass('active');
			}
		});


		$(".numbersOnly").on("keypress keyup blur",function (event) {    
           $(this).val($(this).val().replace(/[^\d].+/, ""));
            if ((event.which < 48 || event.which > 57)) {
                event.preventDefault();
            }
        });
		
		
		$('.quiz-wrapper').on('click', '.validateSlides > a.prev-quiz', function(){
			$("html, body").scrollTop(0);
			var index = $(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').index();
			$(this).parents(".final-action").parent().children().find('.fen-quiz-step.active').removeClass('active').prev().addClass('active');
			//$(this).parents(".final-action").parent().find('.fen-quiz-steps').find('.fen-quiz-step.active').prev().addClass('active');
			if(index == 3){
						//$(this).parent().hide();
						$(this).parent().next().show();
						$(this).parent().next().next().removeClass('tableCell');
			}else if(index == 1){
				$(this).parent().addClass('firstPrev');
				$(this).hide();
			}else{
				$(this).parent().removeClass('firstPrev');
				$(this).show();
			}
		});
		$('body').on('change', '.answer .js-form-item', function(){
			$('body').find(".final-action").find('.quiz-error').css('opacity', '0');
		});
		
		$('body').on('change', '.check_radio_cmb', function(){
			
			if(!$(this).hasClass('radiocheck_radio_cmb')){
				$('.radiocheck_radio_cmb').prop('checked', false);
				
			}else{
				$('.check_radio_cmb').prop('checked', false);
				$(this).prop('checked', true);
			}
			
			if($(this).hasClass('form-radio')){
				$('.dependbefore').removeClass('active');
			}else{
				$('.dependbefore').addClass('active');
			}
		});
		
		$('body').on('click', '.wabi', function(){
			if(!$(this).hasClass('wabiRadio')){
				//$(this).prop('checked', true);
				$('.wabiRadio').prop('checked', false);
				$('.wabiRadio').parent().removeClass('backradio');
				
			}else{
				$('.wabi').prop('checked', false);
				$(this).prop('checked', true);
			}
			if (!$(this).is(':checked')) {
				$(this).parent().removeClass('backradio');
			}else{
				$(this).parent().addClass('backradio');
			}
		});
		
		$('body').on('click', '.bWorkwabi', function(){
			$('.radiocheck_radio_cmb').parent().removeClass('backradio');
			if (!$(this).is(':checked')) {
				$(this).parent().removeClass('backradio');
			}else{
				$(this).parent().addClass('backradio');
			}
			
		});
		
		var partnership = 1;
		$("body").on("click", "input[name='rating']", function(){
			  valrating = $(this).attr('value');
				$('.error_block_q1').text("");
				$('input[name^="share"]').val("");
				$("input[name='aturn']").val("");
				$("input[name='tvasset']").val("");
				$('.error_block_q1a').text("");
				$('.error_block_q3').text("");
				$('.error_block_q4').text("");
				$('.error_block_q5').text("");
				$('.error_block_q6').text("");
				if(valrating == "Proprietor"){
					$(this).parents('.answer').parent().find('.propritor').addClass('active');
					$(this).parents('.answer').parent().find('.partnership').removeClass('active');
					$(this).parents('.answer').parent().find('.partnershipShare').removeClass('active');
					partnership = 1;
				}
				else if(valrating == "partnership"){
					$(this).parents('.answer').parent().find('.partnership').addClass('active');
					$(this).parents('.answer').parent().find('.partnershipShare').addClass('active');
					$(this).parents('.answer').parent().find('.propritor').removeClass('active');
					partnership = 0;
					
				}else{
					$(this).parents('.answer').parent().find('.partnership').addClass('active');
					$(this).parents('.answer').parent().find('.propritor').removeClass('active');
					$(this).parents('.answer').parent().find('.partnershipShare').removeClass('active');
					partnership = 1;
				}
		});
		
		var partnerCount = 3;
		$("body").on("click", ".fen-quiz-step .addPartner", function(e){
			  var limit = 5;
			  if(limit > partnerCount){
				  $(this).parent().before('<div class="js-form-item"><input type="text" name="share[]"  placeholder="eg: Partner '+partnerCount+'(Share in %)" class="form-text partnerappend" id="partner'+partnerCount+'" onkeypress="return isNumberKey(event, this);"> <span class="removePartner"><span class="del-icon">X</span></span></div>');
				partnerCount = partnerCount + 1;
			  }
			  else if(limit == partnerCount){
				 // alert(123);
				  partnerCount = partnerCount + 1;
				  $(this).parent().before('<div class="js-form-item"><input type="text" name="share[]" placeholder="eg: Other Partners (Share in %)" class="form-text partnerappend" id="otherPartner" onkeypress="return isNumberKey(event, this);"> <span class="removePartner"><span class="del-icon">X</span></span></div>');
				  $(this).parent().hide();
			  }
			  
		});
  
		
		$("body").on("click", ".fen-quiz-step .removePartner", function(e){
				var part = 3;
			  $(this).parent().remove();
			 
			  var len = $('.js-form-item .partnerappend').length;
			  //alert(len);
			   if(len == 2){
					  for(var i = 0; i<len; i++ ){
						 // alert(i);
						  //var part = 3;
						  $('.js-form-item .partnerappend').eq(i).attr("id", "partner"+part).attr("Placeholder", "Partner" +part+ "(Share in %)");
						  part = part + 1;
						  
					  }
					  $('.addPartnerWrap').show(); 
			   }
			   if(len < 2){
					for(var i = 0; i<len; i++ ){
					 // alert(i);
					  //var part = 3;
					  $('.js-form-item .partnerappend').eq(i).attr("id", "partner"+part).attr("Placeholder", "Partner" +part+ "(Share in %)");
					  part = part + 1;
					  
				  }
				 
			  }
			    partnerCount--;
		});
		  
		$("#dialog").dialog({
			modal: true,
			autoOpen: false,
			title: "Term & Condition"
		});
		
   	   $("body").on("click", ".smeTermCondition", function(e){
		   //$('.smeTermCondition').click(function(){
			   e.preventDefault();
			  // alert(123);
				$('#dialog').dialog('open');
		});
		
		 $("body").on("change", ".form-group input[type=radio]", function(e){
			  $(this).parent().parent().parent().find('.form-group').removeClass('backradio');
			 $(this).parent().addClass('backradio');
		 });

		$("body").on("blur", "input[name^='share']", function(e){
			var count = 0;
			var flag = 0;
		$('input[name^="share"]').each(function(i){

							var alln = parseFloat($(this).val());
							count = count + alln;
							if($(this).val() > 100){
								//alert("input share");
								$(this).val("");
								$('.error_block_q1a').text('The sum of share between should not be greater than 100 ');
								count = 0;
							}else if($(this).val() == '') {
								alln = 0;
							}else if($(this).val() == 0){
								$('.error_block_q1a').text("partner's share value can't be 0");
								$(this).val("");
							}
							if(count > 100){
								flag = 1;
								$(this).val("");
							}
					});
					if(count > 100 || flag == 1){
						$('.error_block_q1a').text('The sum of share between should not be greater than 100');
						flag = 0;
					} else if (count < 100) {
						$('.error_block_q1a').text('The sum of share between partners should be 100');
					} else if (count == 100) {
						$('.error_block_q1a').text('');
					}
	   });
 	});
  
function isNumberKey(evt, obj)
{
  /*var charCode = (evt.which) ? evt.which : event.keyCode;
 ////console.log(charCode);
    if (charCode != 46 && charCode != 45 && charCode > 31
    && (charCode < 48 || charCode > 57))
     return false;

  return true;*/
  var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
}

function isNumberKeyMobile(evt){
	
    var charCode = (evt.which) ? evt.which : evt.keyCode
    return !(charCode > 31 && (charCode < 48 || charCode > 57));
}
  