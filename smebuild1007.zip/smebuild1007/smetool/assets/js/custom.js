function HideProgress(){
    $('#divajaxProgress').css('display','none');
}
function showForm() {
  $('#welcome').hide();
    $('#formdata').show();
}
function ShowProgress() {

    if($('#divajaxProgress').css('display') == "none"){
        $('#divajaxProgress').css('display','block');
    }
}

function smeTool() {
    $('#page-loader').show();
    $("#aviva_sme_form").submit();
    $.session.clear();
    $.removeCookie();
    document.getElementById('dl_now').click();
    return false;
}

function download(id) {
    var ClientID=id;
    var downArr={
        action: 'pdfgFiles',
        clientID: ClientID
    };
    $.ajax({
        url: "index1.php",
        type: "POST",
        data: downArr,
        dataType: "JSON",
        cache: false,
        async: true,

        success:function(data) {
            if(data.result!=''){
                window.location.href=data.result;
            }
        }
    });
}

$(function() {
    // choose target dropdown
    var select = $('#city');
    select.html(select.find('option').sort(function(x, y) {
        // to change to descending order switch "<" for ">"
        return $(x).val() > $(y).val() ? 1 : -1;
    }));

    // select default item after sorting (first item)
    //$('select').get(0).selectedIndex = 106;
    $("#city").val("106");
});
