function _possibleConstructorReturn(self, call) { if (call && (typeof call === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
  /***/
  "./$$_lazy_route_resource lazy recursive":
  /*!******************************************************!*\
    !*** ./$$_lazy_route_resource lazy namespace object ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function $$_lazy_route_resourceLazyRecursive(module, exports) {
    function webpackEmptyAsyncContext(req) {
      // Here Promise.resolve().then() is used instead of new Promise() to prevent
      // uncaught exception popping up in devtools
      return Promise.resolve().then(function () {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      });
    }

    webpackEmptyAsyncContext.keys = function () {
      return [];
    };

    webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
    module.exports = webpackEmptyAsyncContext;
    webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
  /*!**************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
    \**************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAppComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<router-outlet></router-outlet>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/employer/employer.component.html":
  /*!****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/employer/employer.component.html ***!
    \****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppEmployerEmployerComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- <form> -->\n<!--------------------Form Start--------------------------->\n<div class=\"layout-container showWithoutreport\" id=\"formdata\" style=\"\">\n  <app-navbar></app-navbar>\n  <div class=\"sme-path-quiz body-content\">\n    <div class=\"page clearfix\">\n      <section class=\"main-content clearfix\">\n        <div class=\"wrapper\">\n          <main>\n            <div class=\"region region-content\">\n              <div id=\"block-aviva-content\" class=\"block block-system block-system-main-block\">\n                <div class=\"aviva-quiz\" id=\"avivaQuiz\">\n                  <div class=\"quiz-left\">\n                    <div class=\"quiz-wrapper\" style=\"display: block;\">\n                      <div class=\"fen-quiz-steps\">\n                        <!--<form three start>-->\n\n                        <div class=\"fen-quiz-step active block-question choosen\">\n                          <div class=\"question\">\n                            <div class=\"test-division wrapper-services\">\n                              <div class=\"parent complete parent-assis active\">\n                                <div class=\"quiz-title role_emoloyer\">Your Role As An Employer</div>\n\n                              </div>\n                              <div class=\"parent complete parent-assis active\">\n                                <div class=\"new_tab\"\n                                     style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                  Register\n                                </div>\n                                <div class=\"new_tab\"\n                                     style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                  Business Owner\n                                </div>\n                                <div class=\"new_tab\"\n                                     style=\"background-color:#f39200; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                  Employer\n                                </div>\n                                <div class=\"new_tab\"\n                                     style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                  Head of the Family\n                                </div>\n                                <div class=\"new_tab\"\n                                     style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff;\">\n                                  Customized Report\n                                </div>\n                              </div>\n                            </div>\n                            <div class=\"category-selected\">\n\n                            </div>\n                            <span class=\"qn\">Q1</span>\n                            <div class=\"q-main-title\">\n                              <div class=\"q-title\">How many on roll employees do you have?\n                                <div class=\"form-group field-NoRollEmpolyees\">\n                                  <input type=\"hidden\" id=\"NoRollEmpolyees\" class=\"form-control\"\n                                         name=\"DynamicModel[q10]\" value=\"q10\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                            </div>\n                          </div>\n                          <div class=\"answer\">\n                            <div id=\"edit-answer-1\" class=\"answer-options border-group\">\n                              <div class=\"js-form-item radio-options\">\n                                <div [class]=\"Less_class\" (click)=\"selectedOptions(0)\">\n                                  <label class=\"option\" for=\"remp1\">Less than 10</label>\n                                  <input type=\"radio\" id=\"remp1\" class=\"form-radio\" name=\"remp\" value=\"10\" #q1_error>\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                              <div class=\"js-form-item radio-options\">\n                                <div [class]=\"Between_class\" (click)=\"selectedOptions(1)\">\n                                  <label class=\"option\" for=\"remp2\">Between 10-20</label>\n                                  <input type=\"radio\" id=\"remp2\" class=\"form-radio\" name=\"remp\" value=\"10-20\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                              <div class=\"js-form-item radio-options\">\n                                <div [class]=\"More_class\" (click)=\"selectedOptions(2)\">\n                                  <label class=\"option\" for=\"remp3\">More than 20</label>\n                                  <input type=\"radio\" id=\"remp3\" class=\"form-radio\" name=\"remp\" value=\"20\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                            </div>\n                            <div class=\"error_block_q10 answer-error\">\n                              <small *ngIf=\"q1_show_error\">Please select the number of on-roll employees</small>\n                            </div>\n                          </div>\n\n\n                          <div class=\"question\">\n                            <span class=\"qn\">Q2</span>\n                            <div class=\"q-main-title\">\n                              <div class=\"q-title\">How many of your current employees are critical to the business (key\n                                people)?\n                                <div class=\"form-group field-CurrEmpCritical\">\n                                  <input type=\"hidden\" [(ngModel)]=\"critical_employees\" id=\"CurrEmpCritical\"\n                                         class=\"form-control\" name=\"DynamicModel[q11]\" value=\"q11\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                            </div>\n                          </div>\n                          <div class=\"answer\">\n                            <div id=\"edit-answer-2\" class=\"answer-options\">\n                              <div class=\"js-form-item border-group\">\n                                <div class=\"form-group field-keyPeople required\">\n                                  <input type=\"number\" id=\"keyPeople\" class=\"form-text numbersOnly\"\n                                         [(ngModel)]=\"q2_CurrentEmployees\" name=\"DynamicModel[keyPeople]\" value=\"0\"\n                                         onkeypress=\"return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57\"\n                                         size=\"60\" maxlength=\"128\" placeholder=\"&nbsp;&nbsp;Input Number (eg:5)\"\n                                          aria-required=\"true\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                            </div>\n                            <div class=\"error_block_q11 answer-error\"></div>\n                          </div>\n\n\n                          <div class=\"question\">\n                            <span class=\"qn\">Q3</span>\n                            <div class=\"q-main-title\">\n                              <div class=\"q-title\">When Key Employees leave, is it a challenge for your business?\n                                <div class=\"form-group field-retentionEmpChallnges\">\n                                  <input type=\"hidden\" id=\"retentionEmpChallnges\" class=\"form-control\"\n                                         name=\"DynamicModel[q12]\" value=\"q12\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                            </div>\n                          </div>\n                          <div class=\"answer\">\n                            <div id=\"edit-answer-1\" class=\"answer-options border-group\">\n                              <div class=\"js-form-item radio-options\">\n                                <div [class]=\"No_class\" (click)=\"selectedOptionsQ3(0)\">\n                                  <label class=\"option\" for=\"empCha1\">None of these</label>\n                                  <input type=\"radio\" id=\"empCha1\" class=\"form-radio\" name=\"empCha\"\n                                         value=\"None of these\" #q3_error>\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                              <div class=\"js-form-item radio-options\">\n                                <div [class]=\"NoSignificant_class\" (click)=\"selectedOptionsQ3(1)\">\n                                  <label class=\"option\" for=\"empCha2\">No significant impact</label>\n                                  <input type=\"radio\" id=\"empCha2\" class=\"form-radio\" name=\"empCha\"\n                                         value=\"No significant impact\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                              <div class=\"js-form-item radio-options\">\n                                <div [class]=\"Significant_class\" (click)=\"selectedOptionsQ3(2)\">\n                                  <label class=\"option\" for=\"empCha3\">Significant impact/Business disruption</label>\n                                  <input type=\"radio\" id=\"empCha3\" class=\"form-radio\" name=\"empCha\"\n                                         value=\"Significant impact/Business disruption\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                            </div>\n                            <div class=\"error_block_q12 answer-error\">\n                              <small *ngIf=\"q3_show_error\">Please select answer for Is retention of key employees a\n                                challenge for your business?</small>\n                            </div>\n                          </div>\n\n\n                          <div class=\"question\">\n                            <span class=\"qn\">Q4</span>\n                            <div class=\"q-main-title\">\n                              <div class=\"q-title\">What business insurance solutions have you opted for?\n                                <div class=\"form-group field-busnssInsurnceSolu\">\n                                  <input type=\"hidden\" id=\"busnssInsurnceSolu\" class=\"form-control\"\n                                         name=\"DynamicModel[q13]\" value=\"q13\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                            </div>\n                          </div>\n                          <div class=\"answer\">\n                            <div id=\"edit-answer-1\" class=\"answer-options border-group\">\n                              <div class=\"js-form-item chkBox custom-checkbox\">\n                                <div [class]=\"Key_class\" (click)=\"selectedOptionsQ4(0)\">\n                                  <label class=\"checkboxoption\" for=\"checkkm\">Key Man Insurance</label>\n                                  <input type=\"checkbox\" id=\"checkkm\" class=\"wabi\" name=\"bisSB[0]\" value=\"Key Man\"\n                                         #q4_error>\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                              <div class=\"js-form-item chkBox custom-checkbox\">\n                                <div [class]=\"Partnership_class\" (click)=\"selectedOptionsQ4(1)\">\n                                  <label class=\"checkboxoption\" for=\"checkpi\">Partnership Insurance</label>\n                                  <input type=\"checkbox\" id=\"checkpi\" class=\"wabi\" name=\"bisSB[1]\"\n                                         value=\"Partnership Insurance\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                              <div class=\"js-form-item chkBox custom-checkbox\">\n                                <div [class]=\"Employer_class\" (click)=\"selectedOptionsQ4(2)\">\n                                  <label class=\"checkboxoption\" for=\"checkeep\">Employer Employee Policy</label>\n                                  <input type=\"checkbox\" id=\"checkeep\" class=\"wabi\" name=\"bisSB[2]\"\n                                         value=\"Employer Employee Policy\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                              <div class=\"js-form-item radio-options\">\n                                <div [class]=\"None_class\" (click)=\"selectedOptionsQ4(3)\">\n                                  <label class=\"option\" for=\"none_of_above\">None</label>\n                                  <input type=\"radio\" id=\"none_of_above\" class=\"form-radio wabi wabiRadio\" name=\"bisSB\"\n                                         value=\"No\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                            </div>\n                            <div class=\"error_block_q13 answer-error\">\n                              <small *ngIf=\"q4_show_error\">Please select your existing business insurance plans</small>\n                            </div>\n                          </div>\n\n\n                          <div class=\"question\">\n                            <span class=\"qn\">Q5</span>\n                            <div class=\"q-main-title\">\n                              <div class=\"q-title\">Have you made provisions for gratuity for your employees?\n                                <div class=\"form-group field-provisionGratuityEmp\">\n                                  <input type=\"hidden\" id=\"provisionGratuityEmp\" class=\"form-control\"\n                                         name=\"DynamicModel[q14]\" value=\"q14\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                            </div>\n                          </div>\n                          <div class=\"answer\">\n                            <div id=\"edit-answer-1\" class=\"answer-options border-group\">\n                              <div class=\"js-form-item radio-options\">\n                                <div [class]=\"NoGratuity_class\" (click)=\"selectedOptionsQ5(0)\">\n                                  <label class=\"option\" for=\"gratuityemp1\">My employees are not On Roll and do not need gratuity</label>\n                                  <input type=\"radio\" id=\"gratuityemp1\" class=\"form-radio\" name=\"gratuityemp\"\n                                         value=\"My employees are not On Roll and do not need gratuity\" #q5_error>\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                              <div class=\"js-form-item radio-options\">\n                                <div [class]=\"MyGratuity_class\" (click)=\"selectedOptionsQ5(1)\">\n                                  <label class=\"option\" for=\"gratuityemp2\">I manage my employees' gratuity myself</label>\n                                  <input type=\"radio\" id=\"gratuityemp2\" class=\"form-radio\" name=\"gratuityemp\"\n                                         value=\"I manage my Employees gratuity myself\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                              <div class=\"js-form-item radio-options\">\n                                <div [class]=\"HaveGratuity_class\" (click)=\"selectedOptionsQ5(2)\">\n                                  <label class=\"option\" for=\"gratuityemp3\">I already have a gratuity policy from an insurer</label>\n                                  <input type=\"radio\" id=\"gratuityemp3\" class=\"form-radio\" name=\"gratuityemp\"\n                                         value=\"I already have a gratuity policy from an insurer\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                            </div>\n                            <div class=\"error_block_q14 answer-error\">\n                              <small *ngIf=\"q5_show_error\">Please select answer for Have you made provisions for\n                                gratuity for your employees?</small>\n                            </div>\n                          </div>\n\n\n                          <div class=\"question\">\n                            <span class=\"qn\">Q6</span>\n                            <div class=\"q-main-title\">\n                              <div class=\"q-title\">Do your employees have a PF facility? If yes, have you opted for an\n                                EDLI scheme?\n                                <div class=\"form-group field-empPF\">\n                                  <input type=\"hidden\" id=\"empPF\" class=\"form-control\" name=\"DynamicModel[q15]\"\n                                         value=\"q15\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                            </div>\n                          </div>\n                          <div class=\"answer\">\n                            <div id=\"edit-answer-1\" class=\"answer-options border-group\">\n                              <div class=\"js-form-item radio-options\">\n                                <div [class]=\"NotEligible_class\" (click)=\"selectedOptionsQ6(0)\">\n                                  <label class=\"option\" for=\"edli1\">My employees are not eligible for PF</label>\n                                  <input type=\"radio\" id=\"edli1\" class=\"form-radio\" name=\"edli\"\n                                         value=\"My employees are not eligible for PF\" #q6_error>\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                              <div class=\"js-form-item radio-options\">\n                                <div [class]=\"HavePF_class\" (click)=\"selectedOptionsQ6(1)\">\n                                  <label class=\"option\" for=\"edli2\">My employees have PF but I do not have an EDLI policy</label>\n                                  <input type=\"radio\" id=\"edli2\" class=\"form-radio\" name=\"edli\"\n                                         value=\"My employees have EDLI policy\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                              <div class=\"js-form-item radio-options\">\n                                <div [class]=\"OptedEDLI_class\" (click)=\"selectedOptionsQ6(2)\">\n                                  <label class=\"option\" for=\"edli3\">I have opted for an EDLI policy from an insurer</label>\n                                  <input type=\"radio\" id=\"edli3\" class=\"form-radio\" name=\"edli\"\n                                         value=\"I have opted for an EDLI policy from an insurer\">\n                                  <div class=\"help-block\"></div>\n                                </div>\n                              </div>\n                            </div>\n                            <div class=\"error_block_q15 answer-error\">\n                              <small *ngIf=\"q6_show_error\">Please select answer for Have you opted for an EDLI\n                                scheme?</small>\n                            </div>\n                          </div>\n                        </div>\n\n\n                        <!--</form three end>-->\n\n\n                        <!--Prev and Next-->\n                        <div class=\"final-action\">\n                          <div class=\"done-msg\">Well done!</div>\n                          <div id=\"actionsWrap\">\n                            <div class=\"quiz-error\" style=\"opacity: 0;\">Please answer all the questions.</div>\n                            <div class=\"wrap-prev\">\n                              <div class=\"left-block validateSlides\">\n                                <a class=\"next-quiz\" routerLink=\"/owner\"><span class=\"arrow-size\">‹</span> Previous</a>\n                              </div>\n                              <div class=\"right-block validateSlides\">\n                                <a href=\"javascript:void(0)\" class=\"next-quiz\" (click)=\"next()\">Next <span class=\"arrow-size\">›</span></a>\n                              </div>\n\n                              <div class=\"right-block finalSubmit validateSlides\">\n                                <a href=\"javascript:void(0)\" class=\"next-quiz\">Submit <span class=\"arrow-size\">›</span></a>\n                              </div>\n                              <div class=\"right-block finalSubmit1\" style=\"display:none;\">\n                                <a href=\"javascript:void(0)\" class=\"submit-quiz\" onclick=\"smeTool();\">Submit <span\n                                  class=\"arrow-size\">›</span></a>\n                              </div>\n                            </div>\n                          </div>\n                        </div>\n\n\n                      </div>\n\n                    </div>\n\n\n                  </div>\n\n                </div>\n\n              </div>\n            </div>\n          </main>\n        </div>\n      </section>\n\n    </div>\n  </div>\n\n\n  <app-footer></app-footer>\n</div>\n<!-- </form>     -->\n<!------------------------Thank You Page----------------->\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/footer/footer.component.html":
  /*!************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/footer/footer.component.html ***!
    \************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppFooterFooterComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<footer class=\"clearfix showWithoutreport\">\n    <div class=\"wrapper\">\n        <div class=\"region region-footer\">\n            <div id=\"block-copyright\" class=\"block block-block-content block-block-content5551f077-5f29-4f7c-8561-40aeab49e803\">\n                <div><p>©2020 Aviva India. All Rights Reserved. | Aviva Global Website</p>\n                </div>\n\n            </div>\n            <div id=\"block-footermsg\" class=\"block block-block-content block-block-contentf9f2842c-438b-4ca5-8bbe-a203e27bb931\">\n\n                <div><p id=\"beaware\">BEWARE OF SUSPICIOUS PHONE CALLS AND FICTITIOUS/FRAUDULENT OFFERS. IRDAI clarifies to the public that IRDAI or its officials do not involve in activities like sale of any kind of insurance or financial products nor invest premiums. IRDAI does not announce any bonus. Public receiving such phone calls are requested to lodge a police complaint along with the details of the phone call, number.</p>\n\n                    <p id=\"fotter_msg2\">Aviva Trade logo displayed above belongs to Aviva Brands Limited and is used by Aviva Life Insurance Company India Limited under License. Aviva Life Insurance Company India Ltd. RDAI Registration No:122 For more details on risk factors, terms and conditions please read sales brochure carefully before concluding a sale. Tax benefits are as per exisitng tax laws which are subject to change .Registered Office: 2nd Floor, Prakashdeep Building, 7 Tolstoy Marg, New Delhi - 110030. Telephone Number: 0124-2709000; Telephone Number: 0124-2709046, Fax number: 0124-2571210, Email: customerservices@avivaindia.com, Helpline: 1800 103 7766, Website: www.avivaindia.com, CIN: U66010DL2000PLC107880, Advt No.: Feb 91/18</p>\n\n                    <p>&nbsp;</p>\n                </div>\n\n            </div>\n\n        </div>\n\n    </div>\n</footer>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/head-family/head-family.component.html":
  /*!**********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/head-family/head-family.component.html ***!
    \**********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHeadFamilyHeadFamilyComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- <form> -->\n<!--------------------Form Start--------------------------->\n<div class=\"layout-container showWithoutreport\" id=\"formdata\" style=\"\">\n    <app-navbar></app-navbar>\n    <div class=\"sme-path-quiz body-content\">\n        <div class=\"page clearfix\">\n            <section class=\"main-content clearfix\">\n                <div class=\"wrapper\">\n                    <main>\n                        <div class=\"region region-content\">\n                            <div id=\"block-aviva-content\" class=\"block block-system block-system-main-block\">\n                                <div class=\"aviva-quiz\" id=\"avivaQuiz\">\n                                    <div class=\"quiz-left\">\n                                        <div class=\"quiz-wrapper\" style=\"display: block;\">\n                                            <div class=\"fen-quiz-steps\">\n                                                <!--<form four start>-->\n                                                <div class=\"fen-quiz-step active block-question choosen\">\n                                                    <div class=\"question\">\n                                                        <div class=\"test-division wrapper-services\">\n                                                            <div class=\"parent complete parent-assis active\">\n                                                                <div class=\"quiz-title head_of_family\">Your Role As The\n                                                                    Head Of Family\n                                                                </div>\n\n                                                            </div>\n                                                            <div class=\"parent complete parent-assis active\">\n                                                                <div class=\"new_tab\"\n                                                                     style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                                                    Register\n                                                                </div>\n                                                                <div class=\"new_tab\"\n                                                                     style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                                                    Business Owner\n                                                                </div>\n                                                                <div class=\"new_tab\"\n                                                                     style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                                                    Employer\n                                                                </div>\n                                                                <div class=\"new_tab\"\n                                                                     style=\"background-color:#f39200; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                                                    Head of the Family\n                                                                </div>\n                                                                <div class=\"new_tab\"\n                                                                     style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff;\">\n                                                                    Customized Report\n                                                                </div>\n                                                            </div>\n                                                        </div>\n\n                                                        <div class=\"category-selected\"></div>\n                                                        <span class=\"qn\">Q1</span>\n                                                        <div class=\"q-main-title\">\n                                                            <div class=\"q-title\">Describe your immediate\n                                                                family/dependents.\n                                                                <div class=\"form-group field-family\">\n                                                                    <input type=\"hidden\" id=\"family\"\n                                                                           class=\"form-control\" name=\"DynamicModel[q16]\"\n                                                                           value=\"q16\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n                                                    <div class=\"answer\">\n                                                        <div id=\"edit-answer-1\" class=\"answer-options border-group\">\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"spouse_class\"\n                                                                     (click)=\"selectedOptionsQ1(0)\">\n                                                                    <label class=\"option\"\n                                                                           for=\"tiyfamily1\">Spouse</label>\n                                                                    <input type=\"radio\" id=\"tiyfamily1\"\n                                                                           class=\"form-radio\" name=\"tiyfamily\"\n                                                                           value=\"Spouse\" #q1_error>\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"spouseChil_class\"\n                                                                     (click)=\"selectedOptionsQ1(1)\">\n                                                                    <label class=\"option\" for=\"tiyfamily2\">Spouse &\n                                                                        Children</label>\n                                                                    <input type=\"radio\" id=\"tiyfamily2\"\n                                                                           class=\"form-radio\" name=\"tiyfamily\"\n                                                                           value=\"Spouse &amp; Children\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"spouseChildParent_class\"\n                                                                     (click)=\"selectedOptionsQ1(2)\">\n                                                                    <label class=\"option\" for=\"tiyfamily3\">Spouse,\n                                                                        Children & Parents</label>\n                                                                    <input type=\"radio\" id=\"tiyfamily3\"\n                                                                           class=\"form-radio\" name=\"tiyfamily\"\n                                                                           value=\"Spouse Children &amp; Parents\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q16 answer-error\">\n                                                            <small *ngIf=\"show_q1_error\">Please describe your immediate\n                                                                family/dependents.</small>\n                                                        </div>\n                                                    </div>\n\n\n                                                    <div class=\"question\">\n                                                        <span class=\"qn\">Q2</span>\n                                                        <div class=\"q-main-title\">\n                                                            <div class=\"q-title\">What is your current life insurance\n                                                                cover? (In Lacs)\n                                                                <div class=\"form-group field-lifeInscCovr\">\n                                                                    <input type=\"hidden\" id=\"lifeInscCovr\"\n                                                                           class=\"form-control\" name=\"DynamicModel[q17]\"\n                                                                           value=\"q17\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n                                                    <div class=\"answer\">\n                                                        <div id=\"edit-answer-2\" class=\"answer-options\">\n                                                            <div class=\"js-form-item border-group\">\n                                                                <div class=\"form-group field-ins_cover required\">\n                                                                    <input type=\"number\" id=\"ins_cover\"\n                                                                           [(ngModel)]=\"q2_CurrentInsurance\"\n                                                                           class=\"form-text\" value=\"\" size=\"60\"\n                                                                           maxlength=\"128\"\n                                                                           onkeypress=\"return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57\"\n                                                                           placeholder=\"&nbsp;&nbsp;In Lacs (eg. 40 or 0 for no insurance)\"\n                                                                           aria-required=\"true\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q17 answer-error\"></div>\n                                                    </div>\n\n\n                                                    <div class=\"question\">\n                                                        <span class=\"qn\">Q3</span>\n                                                        <div class=\"q-main-title\">\n                                                            <div class=\"q-title\"><span class=\"tooltip\">Have you purchased any Insurance Plan under <span\n                                                                    class=\"mwpHigh\">MWP Act</span>  to protect your family?<span\n                                                                    class=\"tooltiptext\"><em>Any insurance policy taken by the husband on his own life and endorsed under the Married Women's Property Act in favour of his wife or children or any of them, will always be their property. None of the husband's creditors will have any right over the policy.</em></span></span>\n                                                                <div class=\"form-group field-InsPlanMWP\">\n                                                                    <input type=\"hidden\" id=\"InsPlanMWP\"\n                                                                           class=\"form-control\" name=\"DynamicModel[q18]\"\n                                                                           value=\"q18\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n                                                    <div class=\"answer\">\n                                                        <div id=\"edit-answer-2\" class=\"answer-options border-group\">\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Yes_class\" (click)=\"selectedOptionsQ3(0)\">\n                                                                    <label class=\"option\"\n                                                                           for=\"hypa_insurance1\">Yes</label>\n                                                                    <input type=\"radio\" id=\"hypa_insurance1\"\n                                                                           class=\"form-radio\" name=\"hypa_insurance\"\n                                                                           value=\"Yes\" #q3_error>\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"No_class\" (click)=\"selectedOptionsQ3(1)\">\n                                                                    <label class=\"option\"\n                                                                           for=\"hypa_insurance2\">No</label>\n                                                                    <input type=\"radio\" id=\"hypa_insurance2\"\n                                                                           class=\"form-radio\" name=\"hypa_insurance\"\n                                                                           value=\"No\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q18 answer-error\">\n                                                            <small *ngIf=\"show_q3_error\">Please select anser for Have\n                                                                you purchased any Insurance Plan under MWP Act to\n                                                                protect your family?</small>\n                                                        </div>\n                                                    </div>\n\n\n                                                    <div class=\"question\">\n                                                        <span class=\"qn\">Q4</span>\n                                                        <div class=\"q-main-title\">\n                                                            <div class=\"q-title\">What is your annual income? (In lacs)\n                                                                <div class=\"form-group field-AnnualInc\">\n                                                                    <input type=\"hidden\" id=\"AnnualInc\"\n                                                                           class=\"form-control\" name=\"DynamicModel[q19]\"\n                                                                           value=\"q19\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n                                                    <div class=\"answer\">\n                                                        <div id=\"edit-answer-2\" class=\"answer-options border-group\">\n                                                            <div class=\"js-form-item\">\n                                                                <div class=\"form-group field-anual_income required\">\n                                                                    <input type=\"text\" id=\"anual_income\"\n                                                                           [(ngModel)]=\"q4_AnnualIncome\"\n                                                                           class=\"form-text\"\n                                                                           onkeypress=\"return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57\"\n                                                                           name=\"DynamicModel[anual_income]\" value=\"\"\n                                                                           size=\"60\" maxlength=\"128\"\n                                                                           placeholder=\"eg: In Rs. Lacs (eg. 3.1)\"\n                                                                           aria-required=\"true\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q19 answer-error\">\n                                                            <small *ngIf=\"show_q4_error\"></small>\n                                                        </div>\n                                                    </div>\n\n\n                                                    <div class=\"question\">\n                                                        <span class=\"qn\">Q5</span>\n                                                        <div class=\"q-main-title\">\n                                                            <div class=\"q-title\">What is the approximate fluctuation in\n                                                                your annual income?\n                                                                <div class=\"form-group field-varianInc\">\n                                                                    <input type=\"hidden\" id=\"varianInc\"\n                                                                           class=\"form-control\" name=\"DynamicModel[q20]\"\n                                                                           value=\"q20\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n                                                    <div class=\"answer\">\n                                                        <div id=\"edit-answer-2\" class=\"answer-options border-group\">\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Less_class\"\n                                                                     (click)=\"selectedOptionsQ5(0)\">\n                                                                    <label class=\"option\" for=\"variance_income1\">Less\n                                                                        than 10%</label>\n                                                                    <input type=\"radio\" id=\"variance_income1\"\n                                                                           class=\"form-radio\" name=\"variance_income\"\n                                                                           value=\"10%\" #q5_error>\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Between_class\"\n                                                                     (click)=\"selectedOptionsQ5(1)\">\n                                                                    <label class=\"option\" for=\"variance_income2\">Between\n                                                                        10-20%</label>\n                                                                    <input type=\"radio\" id=\"variance_income2\"\n                                                                           class=\"form-radio\" name=\"variance_income\"\n                                                                           value=\"10-20%\">\n\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"More_class\"\n                                                                     (click)=\"selectedOptionsQ5(2)\">\n                                                                    <label class=\"option\" for=\"variance_income3\">More\n                                                                        than 20%</label>\n                                                                    <input type=\"radio\" id=\"variance_income3\"\n                                                                           class=\"form-radio\" name=\"variance_income\"\n                                                                           value=\"20%\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q20 answer-error\">\n                                                            <small *ngIf=\"show_q5_error\">Please select the approximate\n                                                                fluctuation in your annual income?</small>\n                                                        </div>\n                                                    </div>\n\n\n                                                    <div class=\"question\">\n                                                        <span class=\"qn\">Q6</span>\n                                                        <div class=\"q-main-title\">\n                                                            <div class=\"q-title\">When your income is lower, how do you\n                                                                manage family expenses?\n                                                                <div class=\"form-group field-mngFmlyExp\">\n                                                                    <input type=\"hidden\" id=\"mngFmlyExp\"\n                                                                           class=\"form-control\" name=\"DynamicModel[q21]\"\n                                                                           value=\"q21\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n                                                    <div class=\"answer\">\n                                                        <div id=\"edit-answer-2\" class=\"answer-options border-group\">\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Dip_class\" (click)=\"selectedOptionsQ6(0)\">\n                                                                    <label class=\"option\" for=\"manageFmlexpance1\">Dip\n                                                                        into family savings</label>\n                                                                    <input type=\"radio\" id=\"manageFmlexpance1\"\n                                                                           class=\"form-radio\" name=\"manageFmlexpance\"\n                                                                           value=\"Dip into family savings\" #q6_error>\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Curtail_class\"\n                                                                     (click)=\"selectedOptionsQ6(1)\">\n                                                                    <label class=\"option\" for=\"manageFmlexpance2\">Curtail\n                                                                        discretionary expenditure</label>\n                                                                    <input type=\"radio\" id=\"manageFmlexpance2\"\n                                                                           class=\"form-radio\" name=\"manageFmlexpance\"\n                                                                           value=\"Curtail discretionary expenditure\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Borrow_class\"\n                                                                     (click)=\"selectedOptionsQ6(2)\">\n                                                                    <label class=\"option\" for=\"manageFmlexpance3\">Borrow\n                                                                        money</label>\n                                                                    <input type=\"radio\" id=\"manageFmlexpance3\"\n                                                                           class=\"form-radio\" name=\"manageFmlexpance\"\n                                                                           value=\"Borrow money to manage family expenses\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q21 answer-error\">\n                                                            <small *ngIf=\"show_q6_error\">Please select answer for How do\n                                                                you manage family expenses?</small>\n                                                        </div>\n                                                    </div>\n\n\n                                                    <div class=\"question\">\n                                                        <span class=\"qn\">Q7</span>\n                                                        <div class=\"q-main-title\">\n                                                            <div class=\"q-title\">Have you made any specific investments\n                                                                for your family?\n                                                                <div class=\"form-group field-speciInvest\">\n                                                                    <input type=\"hidden\" id=\"speciInvest\"\n                                                                           class=\"form-control\" name=\"DynamicModel[q22]\"\n                                                                           value=\"q22\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n                                                    <div class=\"answer\">\n                                                        <div id=\"edit-answer-2\" class=\"answer-options border-group\">\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Q7Yes_class\"\n                                                                     (click)=\"selectedOptionsQ7(0)\">\n                                                                    <label class=\"option\" for=\"spe_invest1\">Yes</label>\n                                                                    <input type=\"radio\" id=\"spe_invest1\"\n                                                                           class=\"form-radio\" name=\"spe_invest\"\n                                                                           value=\"Yes\" #q7_error>\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Q7No_class\"\n                                                                     (click)=\"selectedOptionsQ7(1)\">\n                                                                    <label class=\"option\" for=\"spe_invest2\">No</label>\n                                                                    <input type=\"radio\" id=\"spe_invest2\"\n                                                                           class=\"form-radio\" name=\"spe_invest\"\n                                                                           value=\"No\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q22 answer-error\">\n                                                            <small *ngIf=\"show_q7_error\">Please select answer for Have\n                                                                you made any specific investments for your\n                                                                family?</small>\n                                                        </div>\n                                                    </div>\n\n\n                                                    <div class=\"question\">\n                                                        <span class=\"qn\">Q8</span>\n                                                        <div class=\"q-main-title\">\n                                                            <div class=\"q-title\">How prepared is your family to manage\n                                                                household expenses in case of any unfortunate event?\n                                                                <div class=\"form-group field-householdExpense\">\n                                                                    <input type=\"hidden\" id=\"householdExpense\"\n                                                                           class=\"form-control\" name=\"DynamicModel[q23]\"\n                                                                           value=\"q23\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n                                                    <div class=\"answer\">\n                                                        <div id=\"edit-answer-2\" class=\"answer-options border-group\">\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Insured_class\"\n                                                                     (click)=\"selectedOptionsQ8(0)\">\n                                                                    <label class=\"option\" for=\"manage_household1\">I am\n                                                                        adequately insured</label>\n                                                                    <input type=\"radio\" id=\"manage_household1\"\n                                                                           class=\"form-radio\" name=\"manage_household\"\n                                                                           value=\"I am adequately insured; the family will not have significant financial issues\"\n                                                                           #q8_error>\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Extended_class\"\n                                                                     (click)=\"selectedOptionsQ8(1)\">\n                                                                    <label class=\"option\" for=\"manage_household2\">My\n                                                                        extended family will take care of them</label>\n                                                                    <input type=\"radio\" id=\"manage_household2\"\n                                                                           class=\"form-radio\" name=\"manage_household\"\n                                                                           value=\"My extended family will take care of them\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Lifestyle_class\"\n                                                                     (click)=\"selectedOptionsQ8(2)\">\n                                                                    <label class=\"option\" for=\"manage_household3\">My\n                                                                        family will have to make significant lifestyle\n                                                                        changes</label>\n                                                                    <input type=\"radio\" id=\"manage_household3\"\n                                                                           class=\"form-radio\" name=\"manage_household\"\n                                                                           value=\"The family will have to make significant lifestyle changes to manage\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Liquidate_class\"\n                                                                     (click)=\"selectedOptionsQ8(3)\">\n                                                                    <label class=\"option\" for=\"manage_household4\">My\n                                                                        family will have to liquidate fixed\n                                                                        assets</label>\n                                                                    <input type=\"radio\" id=\"manage_household4\"\n                                                                           class=\"form-radio\" name=\"manage_household\"\n                                                                           value=\"My family will have to liquidate fixed assets\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q23 answer-error\">\n                                                            <small *ngIf=\"show_q8_error\">Please select answer for manage\n                                                                household expenses in case of any unfortunate\n                                                                event?</small>\n                                                        </div>\n                                                    </div>\n\n\n                                                    <div class=\"question\">\n                                                        <span class=\"qn\">Q9</span>\n                                                        <div class=\"q-main-title\">\n                                                            <div class=\"q-title\">Quality education is very expensive.\n                                                                Have you started planning for your child/children’s\n                                                                education?\n                                                                <div class=\"form-group field-qualityEdu\">\n                                                                    <input type=\"hidden\" id=\"qualityEdu\"\n                                                                           class=\"form-control\" name=\"DynamicModel[q24]\"\n                                                                           value=\"q24\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n                                                    <div class=\"answer\">\n                                                        <div id=\"edit-answer-2\" class=\"answer-options border-group\">\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Q9Yes_class\"\n                                                                     (click)=\"selectedOptionsQ9(0)\">\n                                                                    <label class=\"option\" for=\"child_edu1\">Yes</label>\n                                                                    <input type=\"radio\" id=\"child_edu1\"\n                                                                           class=\"form-radio\" name=\"QualiEdu\"\n                                                                           value=\"Yes\" #q9_error>\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Q9No_class\"\n                                                                     (click)=\"selectedOptionsQ9(1)\">\n                                                                    <label class=\"option\" for=\"child_edu2\">No</label>\n                                                                    <input type=\"radio\" id=\"child_edu2\"\n                                                                           class=\"form-radio\" name=\"QualiEdu\"\n                                                                           value=\"No\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q24 answer-error\">\n                                                            <small *ngIf=\"show_q9_error\">Please select answer for Have\n                                                                you started planning for your child/children’s\n                                                                education?</small>\n                                                        </div>\n                                                    </div>\n\n\n                                                    <div class=\"question\">\n                                                        <span class=\"qn\">Q10</span>\n                                                        <div class=\"q-main-title\">\n                                                            <div class=\"q-title\">Have you planned for your retirement\n                                                                years?\n                                                                <div class=\"form-group field-retiremntPlan\">\n                                                                    <input type=\"hidden\" id=\"retiremntPlan\"\n                                                                           class=\"form-control\" name=\"DynamicModel[q26]\"\n                                                                           value=\"q26\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n                                                    <div class=\"answer\">\n                                                        <div id=\"edit-answer-2\" class=\"answer-options border-group\">\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Continue_class\"\n                                                                     (click)=\"selectedOptionsQ10(0)\">\n                                                                    <label class=\"option\" for=\"retirePlan1\">I will\n                                                                        continue to work</label>\n                                                                    <input type=\"radio\" id=\"retirePlan1\"\n                                                                           class=\"form-radio\" name=\"retirePlan\"\n                                                                           value=\"I will continue to work\" #q10_error>\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Dependent_class\"\n                                                                     (click)=\"selectedOptionsQ10(1)\">\n                                                                    <label class=\"option\" for=\"retirePlan2\">I will be\n                                                                        dependant on my child/children</label>\n                                                                    <input type=\"radio\" id=\"retirePlan2\"\n                                                                           class=\"form-radio\" name=\"retirePlan\"\n                                                                           value=\"I will be dependant on my child/children\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Rental_class\"\n                                                                     (click)=\"selectedOptionsQ10(2)\">\n                                                                    <label class=\"option\" for=\"retirePlan3\">I will get\n                                                                        rental income from my property</label>\n                                                                    <input type=\"radio\" id=\"retirePlan3\"\n                                                                           class=\"form-radio\" name=\"retirePlan\"\n                                                                           value=\"I will get rental income from my property\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Yet_class\"\n                                                                     (click)=\"selectedOptionsQ10(3)\">\n                                                                    <label class=\"option\" for=\"retirePlan4\">I am yet to\n                                                                        start planning</label>\n                                                                    <input type=\"radio\" id=\"retirePlan4\"\n                                                                           class=\"form-radio\" name=\"retirePlan\"\n                                                                           value=\"I am yet to start planning\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q26 answer-error\">\n                                                            <small *ngIf=\"show_q10_error\">Please select answer for Have\n                                                                you planned for your retirement years?</small>\n                                                        </div>\n                                                    </div>\n                                                </div>\n                                            </div>\n\n\n                                            <!--</form four end>-->\n\n\n                                            <!--Prev and Next-->\n                                            <div class=\"final-action\">\n                                                <div class=\"done-msg\">Well done!</div>\n                                                <div id=\"actionsWrap\">\n                                                    <div class=\"quiz-error\" style=\"opacity: 0;\">Please answer all the\n                                                        questions.\n                                                    </div>\n                                                    <div class=\"wrap-prev\">\n                                                        <div class=\"left-block validateSlides\">\n                                                            <a class=\"next-quiz\" routerLink=\"/employer\"><span\n                                                                    class=\"arrow-size\">‹</span> Previous</a>\n                                                        </div>\n                                                        <div class=\"right-block validateSlides\">\n                                                            <a href=\"javascript:void(0)\" class=\"next-quiz\" (click)=\"next()\">Submit <span\n                                                                    class=\"arrow-size\">›</span></a>\n                                                        </div>\n\n                                                        <div class=\"right-block finalSubmit validateSlides\">\n                                                            <a href=\"javascript:void(0)\" class=\"next-quiz\">Submit <span\n                                                                    class=\"arrow-size\">›</span></a>\n                                                        </div>\n                                                        <div class=\"right-block finalSubmit1\" style=\"display:none;\">\n                                                            <a href=\"javascript:void(0)\" class=\"submit-quiz\"\n                                                               onclick=\"smeTool();\">Submit <span\n                                                                    class=\"arrow-size\">›</span></a>\n                                                        </div>\n                                                    </div>\n                                                </div>\n                                            </div>\n\n\n                                        </div>\n\n                                    </div>\n\n\n                                </div>\n\n                            </div>\n\n\n                        </div>\n                    </main>\n                </div>\n            </section>\n\n        </div>\n    </div>\n\n\n    <app-footer></app-footer>\n</div>\n<!-- </form>     -->\n<!------------------------Thank You Page----------------->\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/navbar/navbar.component.html":
  /*!************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/navbar/navbar.component.html ***!
    \************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppNavbarNavbarComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<header class=\"clearfix\">\n    <div class=\"wrapper\">\n        <div class=\"region region-header\">\n            <div id=\"block-leftlogo\" class=\"block block-system block-system-branding-block\">\n                <img src=\"assets/images/logo.png\" width=\"125\" height=\"29\" alt=\"\" typeof=\"foaf:Image\">\n            </div>\n            <div id=\"block-rightlogo\" class=\"block block-block-content block-block-content18498b25-4102-4597-85c3-22a8dee4fbc8\">\n                <div>\n                    <h1 class=\"page-titleSME\">\n                        <img src=\"assets/images/Cover-Assist-logo-header.png\" width=\"200\" style=\"margin: auto\">\n                    </h1>\n                </div>\n            </div>\n        </div>\n    </div>\n</header>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/owner/owner.component.html":
  /*!**********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/owner/owner.component.html ***!
    \**********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppOwnerOwnerComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- <form #ownerForm=\"ngForm\"> -->\n<!--------------------Form Start--------------------------->\n<div class=\"layout-container showWithoutreport\" id=\"formdata\" style=\"\">\n    <app-navbar></app-navbar>\n    <div class=\"sme-path-quiz body-content\">\n        <div class=\"page clearfix\">\n            <section class=\"main-content clearfix\">\n                <div class=\"wrapper\">\n                    <main>\n                        <div class=\"region region-content\">\n                            <div id=\"block-aviva-content\" class=\"block block-system block-system-main-block\">\n                                <div class=\"aviva-quiz\" id=\"avivaQuiz\">\n                                    <div class=\"quiz-left\">\n                                        <div class=\"quiz-wrapper\" style=\"display: block;\">\n                                            <div class=\"fen-quiz-steps\">\n                                                <!--<form two start>-->\n                                                <div class=\"fen-quiz-step active block-question choosen\">\n                                                    <div class=\"question\">\n                                                        <div class=\"test-division wrapper-services\">\n                                                            <div class=\"parent complete parent-assis active\">\n                                                                <div class=\"quiz-title busines_owner\">Your Role As A\n                                                                    Business Owner\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"parent complete parent-assis active\">\n                                                                <div class=\"new_tab\"\n                                                                     style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                                                    Register\n                                                                </div>\n                                                                <div class=\"new_tab\"\n                                                                     style=\"background-color:#f39200; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                                                    Business Owner\n                                                                </div>\n                                                                <div class=\"new_tab\"\n                                                                     style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                                                    Employer\n                                                                </div>\n                                                                <div class=\"new_tab\"\n                                                                     style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                                                    Head of the Family\n                                                                </div>\n                                                                <div class=\"new_tab\"\n                                                                     style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff;\">\n                                                                    Customized Report\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"category-selected\">\n\n                                                        </div>\n                                                        <span class=\"qn\">Q1</span>\n                                                        <div class=\"q-main-title\">\n                                                            <div class=\"q-title\">How is your company structured?\n                                                                <div class=\"form-group field-natureOfBusiness\">\n                                                                    <input type=\"hidden\" id=\"natureOfBusiness\"\n                                                                           class=\"form-control\" name=\"DynamicModel[q1]\"\n                                                                           value=\"q1\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n                                                    <div class=\"form-group field-smsToolAction\">\n                                                        <input type=\"hidden\" id=\"smsToolAction\" class=\"form-control\"\n                                                               name=\"DynamicModel[action]\" value=\"smsToolAction\">\n                                                        <div class=\"help-block\"></div>\n                                                    </div>\n                                                    <div class=\"answer\">\n                                                        <div id=\"edit-answer-1\" class=\"border-group\"\n                                                             [ngSwitch]=\"structured\">\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Proprietor_class\"\n                                                                     (click)=\"selectOptionCS(0)\">\n                                                                    <label class=\"option\"\n                                                                           for=\"edit-rating2\">Proprietor</label>\n                                                                    <input type=\"radio\" id=\"edit-rating2\"\n                                                                           class=\"form-radio required\" name=\"Proprietor\"\n                                                                           #Proprietor=\"ngModel\" ngModel required\n                                                                           value=\"Proprietor\" #q1_error>\n                                                                    <div class=\"help-block\" *ngIf=\"Proprietor.errors\">\n                                                                        <small *ngIf=\"Proprietor.errors.required && Proprietor.touched\">Proprietor\n                                                                            cannot be blank.</small>\n                                                                    </div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Partnership_class\"\n                                                                     (click)=\"selectOptionCS(1)\">\n                                                                    <label class=\"option\"\n                                                                           for=\"edit-rating1\">Partnership</label>\n                                                                    <input type=\"radio\" id=\"edit-rating1\"\n                                                                           class=\"form-radio required\" name=\"rating\"\n                                                                           value=\"partnership\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options \">\n                                                                <div [class]=\"PVTLTD_class\" (click)=\"selectOptionCS(2)\">\n                                                                    <label class=\"option\" for=\"edit-rating3\">Pvt Ltd.\n                                                                        Company</label>\n                                                                    <input type=\"radio\" id=\"edit-rating3\"\n                                                                           class=\"form-radio required\" name=\"rating\"\n                                                                           value=\"Pvt\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q1 answer-error\">\n                                                            <small *ngIf=\"show_q1_error\">Please select your company\n                                                                structure (company-type)</small>\n                                                        </div>\n                                                    </div>\n\n\n                                                    <div *ngIf=\"showQ1a; then Q1Block\"></div>\n\n\n                                                    <ng-template #Q1Block>\n                                                        <div class=\"question partnershipShare active\">\n                                                            <span class=\"qn\">Q1a</span>\n                                                            <div class=\"q-main-title\">\n                                                                <div class=\"q-title\">What is the partnerwise\n                                                                    shareholding?\n                                                                    <div class=\"form-group field-partnerShareHolding\">\n                                                                        <input type=\"hidden\" id=\"partnerShareHolding\"\n                                                                               class=\"form-control\"\n                                                                               name=\"DynamicModel[q2]\" value=\"q2\">\n                                                                        <div class=\"help-block\"></div>\n                                                                    </div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"answer partnershipShare active\">\n                                                            <div id=\"partnerShareSect\" class=\"border-group\">\n                                                                <div class=\"js-form-item\">\n                                                                    <div class=\"form-group field-partner1\">\n                                                                        <input type=\"number\"\n                                                                               [(ngModel)]=\"q1a_selected_option\"\n                                                                               id=\"partner1\" class=\"form-text share\"\n                                                                               name=\"share[]\"\n                                                                               onkeypress=\"return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57\"\n                                                                               placeholder=\"eg: Partnership 1(Share in %)\"\n                                                                               #q1a_error>\n                                                                        <div class=\"help-block\"></div>\n                                                                    </div>\n                                                                </div>\n                                                                <div class=\"js-form-item\">\n                                                                    <div class=\"form-group field-partner1\">\n                                                                        <input type=\"number\"\n                                                                               [(ngModel)]=\"q1a2_selected_option\"\n                                                                               id=\"partner1\" class=\"form-text share\"\n                                                                               name=\"share[]\"\n                                                                               onkeypress=\"return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57\"\n                                                                               placeholder=\"eg: Partnership 2(Share in %)\">\n                                                                        <div class=\"help-block\"></div>\n                                                                    </div>\n                                                                </div>\n                                                                <div class=\"js-form-item\"\n                                                                     *ngFor=\"let partner of partners; let i=index\">\n                                                                    <div class=\"form-group field-partner2\">\n                                                                        <input type=\"number\" [(ngModel)]=\"partner.share\"\n                                                                               id=\"partner2\" class=\"form-text share\"\n                                                                               name=\"share[]\"\n                                                                               onkeypress=\"return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57\"\n                                                                               placeholder=\"eg: Partnership {{i+3}}(Share in %)\">\n                                                                        <span class=\"removePartner\"><span\n                                                                                class=\"del-icon\"\n                                                                                (click)=\"removePartner(i)\">X</span></span>\n                                                                        <div class=\"help-block\"></div>\n                                                                    </div>\n                                                                </div>\n                                                                <div class=\"js-form-item addPartnerWrap \">\n                                                                    <input type=\"button\" class=\"addPartner\"\n                                                                           (click)=\"addPartner()\" value=\"Add Partner\">\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"error_block_q1a answer-error\">\n                                                                <div class=\"error_block_q1 answer-error\">\n                                                                    <small *ngIf=\"show_q1a_error\">Please fill partner's\n                                                                        shares and total should be 100</small>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"error_block_q1a answer-error\">\n                                                                <div class=\"error_block_q1 answer-error\">\n                                                                    <small *ngIf=\"show_q1a2_error\">Please fill partner's\n                                                                        shares and total should be 100</small>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </ng-template>\n\n\n                                                    <div *ngIf=\"showLacs; then lacBlock else crBlock\"></div>\n\n\n                                                    <!-- this is for cr -->\n                                                    <ng-template #crBlock>\n                                                        <div>\n                                                            <div class=\"question partnership active\">\n                                                                <span class=\"qn\">Q2</span>\n                                                                <div class=\"q-main-title\">\n                                                                    <div class=\"q-title\">What is the annual turnover of\n                                                                        your company? (In Rs Cr)\n                                                                        <div class=\"form-group field-PARannualTurnOver\">\n                                                                            <input type=\"hidden\" id=\"PARannualTurnOver\"\n                                                                                   class=\"form-control\" min=\"0\"\n                                                                                   name=\"DynamicModel[q3]\" value=\"q3\">\n                                                                            <div class=\"help-block\"></div>\n                                                                        </div>\n                                                                    </div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"answer partnership active\">\n                                                                <div id=\"\">\n                                                                    <div class=\"js-form-item border-group \">\n                                                                        <div class=\"form-group field-PARturnoverAmount\">\n                                                                            <input type=\"number\"\n                                                                                   [(ngModel)]=\"q2_annual_turn_overCR\"\n                                                                                   id=\"PARturnoverAmount\"\n                                                                                   class=\"form-text partnership aturn active\"\n                                                                                   size=\"60\" maxlength=\"128\"\n                                                                                   placeholder=\"&nbsp;&nbsp;eg: In Rs Cr (eg. 3.1)\"\n                                                                                   #q2CR_error>\n                                                                            <div class=\"help-block\"></div>\n                                                                        </div>\n                                                                    </div>\n                                                                </div>\n                                                                <div class=\"error_block_q3 answer-error\">\n                                                                    <div class=\"error_block_q1 answer-error\">\n                                                                        <small *ngIf=\"show_q2CR_error\">Please enter your\n                                                                            company's annual turnover</small>\n                                                                    </div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"question partnership active\">\n                                                                <span class=\"qn\">Q3</span>\n                                                                <div class=\"q-main-title\">\n                                                                    <div class=\"q-title\">What is the total value of\n                                                                        assets of your company? (In Rs Cr)\n                                                                        <div class=\"form-group field-PARtotalAssets\">\n                                                                            <input type=\"hidden\" id=\"PARtotalAssets\"\n                                                                                   class=\"form-control\"\n                                                                                   name=\"DynamicModel[q4]\" value=\"q4\">\n                                                                            <div class=\"help-block\"></div>\n                                                                        </div>\n                                                                    </div>\n                                                                </div>\n                                                            </div>\n\n                                                            <div class=\"answer partnership active\">\n                                                                <div id=\"\">\n                                                                    <div class=\"js-form-item border-group \">\n                                                                        <div class=\"form-group field-PARtotalAssetAmt\">\n                                                                            <input type=\"number\"\n                                                                                   [(ngModel)]=\"q3_total_value_assetCR\"\n                                                                                   id=\"PARtotalAssetAmt\"\n                                                                                   class=\"form-text partnership assetval active\"\n                                                                                   name=\"tvasset\" size=\"60\"\n                                                                                   maxlength=\"128\"\n                                                                                   onkeypress=\"return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57\"\n                                                                                   placeholder=\"&nbsp;&nbsp;eg: In Rs Cr (eg. 3.1)\"\n                                                                                   #q3CR_error>\n                                                                            <div class=\"help-block\"></div>\n                                                                        </div>\n                                                                    </div>\n                                                                </div>\n                                                                <div class=\"error_block_q4 answer-error\">\n                                                                    <div class=\"error_block_q1 answer-error\">\n                                                                        <small *ngIf=\"show_q3CR_error\">Please enter your\n                                                                            total asset value of your company</small>\n                                                                    </div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </ng-template>\n\n                                                    <!-- end of cr -->\n\n\n                                                    <!-- this is for lacs -->\n                                                    <ng-template #lacBlock>\n                                                        <div>\n                                                            <div class=\"question partnership active\">\n                                                                <span class=\"qn\">Q2</span>\n                                                                <div class=\"q-main-title\">\n                                                                    <div class=\"q-title\">What111 is the annual turnover of\n                                                                        your company? (In Rs. Lacs)\n                                                                        <div class=\"form-group field-PARannualTurnOver\">\n                                                                            <input type=\"hidden\" id=\"PARannualTurnOver\"\n                                                                                   class=\"form-control\"\n                                                                                   name=\"DynamicModel[q3]\">\n                                                                            <div class=\"help-block\"></div>\n                                                                        </div>\n                                                                    </div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"answer partnership active\">\n                                                                <div id=\"\">\n                                                                    <div class=\"js-form-item border-group \">\n                                                                        <div class=\"form-group field-PARturnoverAmount\">\n                                                                            <input type=\"number\"\n                                                                                   [(ngModel)]=\"q2_annual_turn_overLACS\"\n                                                                                   id=\"PARturnoverAmount\"\n                                                                                   class=\"form-text partnership aturn active\"\n                                                                                   name=\"aturn\" size=\"60\"\n                                                                                   maxlength=\"128\"\n                                                                                   onkeypress=\"return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57\"\n                                                                                   placeholder=\"&nbsp;&nbsp;eg: In Rs lacs (eg. 3.1)\"\n                                                                                   #q2LACS_error>\n                                                                            <div class=\"help-block\"></div>\n                                                                        </div>\n                                                                    </div>\n                                                                </div>\n                                                                <div class=\"error_block_q3 answer-error\">\n                                                                    <small *ngIf=\"show_q2LACS_error\">Please enter your\n                                                                        company's annual turnover</small>\n                                                                </div>\n                                                            </div>\n\n                                                            <div class=\"question partnership active\">\n                                                                <span class=\"qn\">Q3</span>\n                                                                <div class=\"q-main-title\">\n                                                                    <div class=\"q-title\">What is the total value of\n                                                                        assets of your company? (In Rs. Lacs)\n                                                                        <div class=\"form-group field-PARtotalAssets\">\n                                                                            <input type=\"hidden\" id=\"PARtotalAssets\"\n                                                                                   class=\"form-control\"\n                                                                                   name=\"DynamicModel[q4]\" value=\"q4\">\n                                                                            <div class=\"help-block\"></div>\n                                                                        </div>\n                                                                    </div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"answer partnership active\">\n                                                                <div id=\"\">\n                                                                    <div class=\"js-form-item border-group \">\n                                                                        <div class=\"form-group field-PARtotalAssetAmt\">\n                                                                            <input type=\"number\"\n                                                                                   [(ngModel)]=\"q3_total_value_assetLACS\"\n                                                                                   id=\"PARtotalAssetAmt\"\n                                                                                   class=\"form-text partnership assetval active\"\n                                                                                   name=\"tvasset\" size=\"60\"\n                                                                                   maxlength=\"128\"\n                                                                                   onkeypress=\"return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57\"\n                                                                                   placeholder=\"&nbsp;&nbsp;eg: In Rs Lacs (eg. 3.1)\"\n                                                                                   #q3LACS_error>\n                                                                            <div class=\"help-block\"></div>\n                                                                        </div>\n                                                                    </div>\n                                                                </div>\n                                                                <div class=\"error_block_q4 answer-error\">\n                                                                    <small *ngIf=\"show_q3LACS_error\">Please enter your\n                                                                        total asset value of your company</small>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </ng-template>\n\n\n                                                    <!-- end of lacs questions -->\n\n\n                                                    <div class=\"question\">\n                                                        <span class=\"qn\">Q4</span>\n                                                        <div class=\"q-main-title\">\n                                                            <div class=\"q-title\">Are you planning any business expansion\n                                                                in the next 5 years?\n                                                                <div class=\"form-group field-PlanBusinessExpansion\">\n                                                                    <input type=\"hidden\" id=\"PlanBusinessExpansion\"\n                                                                           class=\"form-control\" name=\"DynamicModel[q7]\"\n                                                                           value=\"q7\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n                                                    <div class=\"answer\">\n                                                        <div id=\"edit-answer-1\" class=\"answer-options border-group\">\n                                                            <div class=\"js-form-item radio-options \">\n                                                                <div [class]=\"Yes_class\" (click)=\"selectOptionQ4(0)\">\n                                                                    <label class=\"option\" for=\"pbe1\">Yes</label>\n                                                                    <input type=\"radio\" id=\"pbe1\"\n                                                                           class=\"form-radio required\" name=\"pbe\"\n                                                                           value=\"Yes\" #q4_error>\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"No_class\" (click)=\"selectOptionQ4(1)\">\n                                                                    <label class=\"option\" for=\"pbe2\">No</label>\n                                                                    <input type=\"radio\" id=\"pbe2\"\n                                                                           class=\"form-radio required\" name=\"pbe\"\n                                                                           value=\"No\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Have_class\" (click)=\"selectOptionQ4(2)\">\n                                                                    <label class=\"option\" for=\"pbe3\">Have not thought\n                                                                        about it</label>\n                                                                    <input type=\"radio\" id=\"pbe3\"\n                                                                           class=\"form-radio required\" name=\"pbe\"\n                                                                           value=\"HaveNotThoughtAboutIt\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q7 answer-error\">\n                                                            <small *ngIf=\"show_q4_error\">Please answer if your are\n                                                                planing for business expansion</small>\n                                                        </div>\n                                                    </div>\n\n\n                                                    <!-- <div class=\"answer\">\n                                                        <div id=\"\" class=\" border-group\">\n                                                            <div class=\"js-form-item radio-options \">\n                                                                <div class=\" field-pbe1\">\n<label class=\"option\" for=\"pbe1\">Yes</label>\n<input type=\"radio\" id=\"pbe1\" class=\"form-radio required\" name=\"pbe\" value=\"Yes\">\n<div class=\"help-block\"></div>\n</div>                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div class=\"form-group field-pbe2\">\n<label class=\"option\" for=\"pbe2\">No</label>\n<input type=\"radio\" id=\"pbe2\" class=\"form-radio required\" name=\"pbe\" value=\"No\">\n<div class=\"help-block\"></div>\n</div>                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div class=\"form-group field-pbe3\">\n<label class=\"option\" for=\"pbe3\">Have not thought about it</label>\n<input type=\"radio\" id=\"pbe3\" class=\"form-radio required\" name=\"pbe\" value=\"HaveNotThoughtAboutIt\">\n<div class=\"help-block\"></div>\n</div>                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q7 answer-error\"></div>\n                                                    </div> -->\n\n\n                                                    <div class=\"question\">\n                                                        <span class=\"qn\">Q5</span>\n                                                        <div class=\"q-main-title\">\n                                                            <div class=\"q-title\">Have you taken any loans for your\n                                                                business? If yes, for what purpose?\n                                                                <div class=\"form-group field-takingLoanBusiness\">\n                                                                    <input type=\"hidden\" id=\"takingLoanBusiness\"\n                                                                           class=\"form-control\" name=\"DynamicModel[q8]\"\n                                                                           value=\"q8\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n\n                                                    <div class=\"answer\">\n                                                        <div id=\"\" class=\"border-group\">\n                                                            <div class=\"js-form-item chkBox custom-checkbox cus-pad\">\n                                                                <div [class]=\"Working_class\"\n                                                                     (click)=\"selectedOptionsQ5(0)\">\n                                                                    <label class=\"checkboxoption\" for=\"check_wc\">Working\n                                                                        Capital</label>\n                                                                    <input type=\"checkbox\" id=\"check_wc\"\n                                                                           class=\"check_radio_cmb bWorkwabi\"\n                                                                           name=\"taken_loan\" value=\"Working Capital\"\n                                                                           #q5_error>\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item chkBox custom-checkbox cus-pad\">\n                                                                <div [class]=\"Business_class\"\n                                                                     (click)=\"selectedOptionsQ5(1)\">\n                                                                    <label class=\"checkboxoption\" for=\"check_be\">Business\n                                                                        Expansion</label>\n                                                                    <input type=\"checkbox\" id=\"check_be\"\n                                                                           class=\"check_radio_cmb bWorkwabi\"\n                                                                           name=\"taken_loan\" value=\"Business Expansion\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"js-form-item radio-options\">\n                                                                <div [class]=\"Q5No_class\"\n                                                                     (click)=\"selectedOptionsQ5(2)\">\n                                                                    <label class=\"option\" for=\"NoLoan\">No</label>\n                                                                    <input type=\"radio\" id=\"NoLoan\"\n                                                                           class=\"form-radio check_radio_cmb radiocheck_radio_cmb\"\n                                                                           name=\"taken_loan\" value=\"No\">\n                                                                    <div class=\"help-block\"></div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"error_block_q8 answer-error\">\n                                                            <small *ngIf=\"show_q5_error\">Please answer if you have taken\n                                                                any loans</small>\n                                                        </div>\n                                                    </div>\n\n\n                                                    <div *ngIf=\"showQ5a then Q5Block\"></div>\n\n                                                    <ng-template #Q5Block>\n                                                        <div class=\"question dependbefore active\">\n                                                            <span class=\"qn\">Q5a</span>\n                                                            <div class=\"q-main-title\">\n                                                                <div class=\"q-title\">What is your current unsecured loan\n                                                                    outstanding? (In Rs. Lacs)\n                                                                    <div class=\"form-group field-CurrentUnsecOutLoan\">\n\n                                                                        <input type=\"hidden\" id=\"CurrentUnsecOutLoan\"\n                                                                               class=\"form-control\"\n                                                                               name=\"DynamicModel[q9]\" value=\"q9\"\n                                                                               #q5a_error>\n\n                                                                        <div class=\"help-block\"></div>\n                                                                    </div>\n                                                                </div>\n                                                            </div>\n                                                        </div>\n                                                        <div class=\"answer dependbefore active\">\n                                                            <div id=\"\">\n                                                                <div class=\"js-form-item border-group\">\n                                                                    <div class=\"form-group field-currOutLoanAmt\">\n\n                                                                        <input type=\"text\" id=\"currOutLoanAmt\"\n                                                                               class=\"form-text dependbefore active\"\n                                                                               [(ngModel)]=\"q5a_selected_option\"\n                                                                               name=\"ulout\" size=\"60\" maxlength=\"128\"\n                                                                               onkeypress=\"return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57\"\n                                                                               placeholder=\"eg: In Rs. Lacs (eg. 3.1)\">\n\n                                                                        <div class=\"help-block\"></div>\n                                                                    </div>\n                                                                </div>\n                                                            </div>\n                                                            <div class=\"error_block_q9 answer-error\">\n                                                                <small *ngIf=\"show_q5a_error\">Please input unsecured\n                                                                    loan amount</small>\n                                                            </div>\n                                                        </div>\n                                                    </ng-template>\n\n                                                </div>\n\n                                                <!--</form two end>-->\n\n\n                                                <!--Prev and Next-->\n                                                <div class=\"final-action\">\n                                                    <div class=\"done-msg\">Well done!</div>\n                                                    <div id=\"actionsWrap\">\n                                                        <div class=\"quiz-error\" style=\"opacity: 0;\">Please answer all\n                                                            the questions.\n                                                        </div>\n                                                        <div class=\"wrap-prev\">\n                                                            <div class=\"left-block validateSlides\">\n                                                                <a class=\"next-quiz\" routerLink=\"/register\"><span\n                                                                        class=\"arrow-size\">‹</span> Previous</a>\n                                                            </div>\n                                                            <div class=\"right-block validateSlides\">\n                                                                <a href=\"javascript:void(0)\" class=\"next-quiz\" (click)=\"next()\">Next <span\n                                                                        class=\"arrow-size\">›</span></a>\n                                                            </div>\n\n                                                            <div class=\"right-block finalSubmit validateSlides\">\n                                                                <a href=\"javascript:void(0)\" class=\"next-quiz\">Submit\n                                                                    <span class=\"arrow-size\">›</span></a>\n                                                            </div>\n                                                            <div class=\"right-block finalSubmit1\" style=\"display:none;\">\n                                                                <a href=\"javascript:void(0)\" class=\"submit-quiz\"\n                                                                   onclick=\"smeTool();\">Submit <span class=\"arrow-size\">›</span></a>\n                                                            </div>\n                                                        </div>\n                                                    </div>\n                                                </div>\n\n\n                                            </div>\n\n                                        </div>\n\n\n                                    </div>\n\n                                </div>\n\n                            </div>\n                        </div>\n                    </main>\n                </div>\n            </section>\n\n        </div>\n    </div>\n\n    <app-footer></app-footer>\n</div>\n<!-- </form>    -->\n<!------------------------Thank You Page----------------->";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/page-not-found/page-not-found.component.html":
  /*!****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/page-not-found/page-not-found.component.html ***!
    \****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPageNotFoundPageNotFoundComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- <p>page-not-found works!</p> -->\n\n<mat-card>\n    <img src=\"assets/preview.jpg\" alt=\"\" style=\"width: 70%; display:block; height: auto; margin-left: 12%;\">\n</mat-card>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html":
  /*!****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html ***!
    \****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRegisterRegisterComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<app-navbar></app-navbar>\n\n\n<!-- <form name=\"form\" [formGroup]=\"form\"> -->\n<!-- ------------------Form Start------------------------- -->\n<div class=\"sme-path-quiz body-content\">\n<div class=\"layout-container\">\n  <div class=\"sme-path-quiz body-content\">\n    <div class=\"clearfix\">\n      <div class=\"page clearfix\">\n        <section class=\"main-content clearfix\">\n          <div class=\"wrapper\">\n            <main>\n              <div class=\"region region-content\">\n                <div id=\"block-aviva-content\" class=\"block block-system block-system-main-block\">\n                  <div class=\"aviva-quiz\" id=\"avivaQuiz\">\n                    <div class=\"quiz-left\">\n                      <div class=\"quiz-wrapper\" style=\"display: block;\">\n                        <div class=\"fen-quiz-steps\">\n                          <!--<form one start>-->\n                          <div class=\"fen-quiz-step active block-question choosen\">\n                            <div class=\"question\">\n                              <div class=\"test-division wrapper-services\">\n                                <div class=\"parent complete parent-assis active\">\n                                  <div class=\"quiz-title tell_about_ys\">Welcome! Let's get you started</div>\n                                </div>\n                                <div class=\"parent complete parent-assis active\">\n                                  <div class=\"new_tab\"\n                                       style=\"background-color:#f39200; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                    Register\n                                  </div>\n                                  <div class=\"new_tab\"\n                                       style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                    Business Owner\n                                  </div>\n                                  <div class=\"new_tab\"\n                                       style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                    Employer\n                                  </div>\n                                  <div class=\"new_tab\"\n                                       style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff; border-right-color:#ffffff; border-right-style:solid; border-right-width:1px;\">\n                                    Head of the Family\n                                  </div>\n                                  <div class=\"new_tab\"\n                                       style=\"background-color:#004fb6; text-align:center; float:left; width:20%; color:#ffffff;\">\n                                    Customized Report\n                                  </div>\n                                </div>\n                              </div>\n                              <div class=\"category-selected\">Please fill in your details to get a customized report.\n                              </div>\n\n                            </div>\n                            <div class=\"answer answer_user_entry\">\n                              <div class=\"field_wrap_start\">\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\">\n                                  <label>Name</label>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-1\">\n                                  <div class=\"form-group field-nameTitle required\">\n\n                                    <select id=\"nameTitle\" matNativeControl class=\"form-select\" [(ngModel)]=\"Salutation\"\n                                            required aria-required=\"true\">\n                                      <!-- <option value=\"\">Mr.</option> -->\n                                      <!-- <option *ngFor=\"let status of martialStatus\" [value]=\"status.value\">{{status.value}}</option> -->\n                                      <option value=\"\" disabled>Select</option>\n                                      <option value=\"Mr.\">Mr.</option>\n                                      <option value=\"Miss\">Miss</option>\n                                      <option value=\"Mrs.\">Mrs.</option>\n                                    </select>\n\n                                    <div class=\"help-block\"></div>\n                                  </div>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-3\">\n                                  <div class=\"form-group field-name required\">\n\n                                    <input type=\"text\" id=\"name\" class=\"form-text required\" [(ngModel)]=\"Name\" value=\"\"\n                                           size=\"60\" maxlength=\"128\" placeholder=\"Your Full Name\" autocomplete=\"off\"\n                                           aria-required=\"true\" #Name_error>\n\n                                    <div class=\"help-block\"></div>\n                                  </div>\n                                  <div class=\"error_block_q16 answer-error\">\n                                    <small *ngIf=\"show_Name_error\">Name cannot be blank.</small>\n                                  </div>\n                                </div>\n                              </div>\n                            </div>\n\n\n                            <div class=\"answer answer_user_entry\">\n                              <div class=\"field_wrap_start\">\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\">\n                                  <label>Date of Birth</label>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2 form-item-dob \">\n                                  <div class=\"form-group field-BirthDate required\">\n                                    <input type=\"text\" id=\"date\" class=\"form-control\" [(ngModel)]=\"date\"\n                                           placeholder=\"DD-MM-YYYY\" aria-required=\"true\" matInput\n                                           [matDatepicker]=\"picker\" (focus)=\"_openCalendar(picker)\"\n                                           (click)=\"_openCalendar(picker)\" #Date_error>\n                                    <!-- <mat-datepicker-toggle [for]=\"picker\"></mat-datepicker-toggle> -->\n                                    <mat-datepicker #picker=\"matDatepicker\"></mat-datepicker>\n                                    <div class=\"help-block\"></div>\n                                  </div>\n                                  <div class=\"error_block_q16 answer-error\">\n                                    <small *ngIf=\"show_Date_error\">DOB cannot be blank.</small>\n                                  </div>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\"></div>\n                              </div>\n                            </div>\n\n\n                            <div class=\"answer answer_user_entry\">\n                              <div class=\"field_wrap_start\">\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\">\n                                  <label>Mobile Number</label>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2 form-item-dob\">\n                                  <div class=\"form-group field-mobile required\">\n                                    <input type=\"number\" pattern=\"^\\d{10}$\" id=\"mobile\" class=\"form-text required\"\n                                           [(ngModel)]=\"Mobile\" value=\"\" maxlength=\"10\"\n                                           placeholder=\"Your 10 Digit Mobile Number\" autocomplete=\"off\"\n                                           aria-required=\"true\" onKeyPress=\"if(this.value.length==10) return false;\"\n                                            #Mobile_error>\n                                    <div class=\"help-block\"></div>\n                                  </div>\n                                  <div class=\"error_block_q16 answer-error\">\n                                    <small *ngIf=\"show_Mobile_error\">Mobile cannot be blank.</small>\n                                  </div>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\"></div>\n                              </div>\n                            </div>\n\n\n                            <div class=\"answer answer_user_entry\">\n                              <div class=\"field_wrap_start\">\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\">\n                                  <label>Email ID</label>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\">\n                                  <div class=\"form-group field-email required\">\n                                    <input type=\"email\" id=\"email\" class=\"form-email required\" [(ngModel)]=\"Email\"\n                                           value=\"\" size=\"60\" maxlength=\"254\" placeholder=\"eg: aanya@gmail.com\"\n                                           autocomplete=\"off\" aria-required=\"true\" #Email_error>\n                                    <div class=\"help-block\"></div>\n                                  </div>\n                                  <div class=\"error_block_q16 answer-error\">\n                                    <small *ngIf=\"show_Email_error\">{{email_error}}</small>\n                                  </div>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\"></div>\n                              </div>\n                            </div>\n\n\n                            <div class=\"answer answer_user_entry\">\n                              <div class=\"field_wrap_start\">\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\">\n                                  <label>Company Name</label>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\">\n                                  <div class=\"form-group field-companyName required\">\n                                    <input type=\"text\" id=\"companyName\" class=\"form-text required\"\n                                           [(ngModel)]=\"Company_Name\" value=\"\" size=\"60\" maxlength=\"128\"\n                                           placeholder=\"eg: XYZ Pvt. Ltd.\" aria-required=\"true\" #Company_error>\n                                    <div class=\"help-block\"></div>\n                                  </div>\n                                  <div class=\"error_block_q16 answer-error\">\n                                    <small *ngIf=\"show_CompanyName_error\">Company cannot be blank.</small>\n                                  </div>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\"></div>\n                              </div>\n                            </div>\n\n\n                            <div class=\"answer answer_user_entry\">\n                              <div class=\"field_wrap_start\">\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\">\n                                  <label>City</label>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\">\n                                  <div class=\"form-group field-city required\">\n                                    <select id=\"Location\" class=\"form-select location\" [(ngModel)]=\"Location\"\n                                            aria-required=\"true\" #City_error>\n                                      <option value=\"\">Select City</option>\n                                      <option value=\"Agartala\">Agartala</option>\n                                      <option value=\"Ahmedabad\">Ahmedabad</option>\n                                      <option value=\"Ahmednagar\">Ahmednagar</option>\n                                      <option value=\"Aizawal\">Aizawal</option>\n                                      <option value=\"Ajmer\">Ajmer</option>\n                                      <option value=\"Ambala\">Ambala</option>\n                                      <option value=\"Amritsar\">Amritsar</option>\n                                      <option value=\"Anantapur\">Anantapur</option>\n                                      <option value=\"Ankleshwar\">Ankleshwar</option>\n                                      <option value=\"Aurangabad\">Aurangabad</option>\n                                      <option value=\"Bathinda\">Bathinda</option>\n                                      <option value=\"Belgaum\">Belgaum</option>\n                                      <option value=\"Bellary\">Bellary</option>\n                                      <option value=\"Bengaluru/Bangalore\">Bengaluru/Bangalore</option>\n                                      <option value=\"Bharuch\">Bharuch</option>\n                                      <option value=\"Bhavnagar\">Bhavnagar</option>\n                                      <option value=\"Bhillai\">Bhillai</option>\n                                      <option value=\"Bhopal\">Bhopal</option>\n                                      <option value=\"Bhubaneshwar\">Bhubaneshwar</option>\n                                      <option value=\"Bhuj\">Bhuj</option>\n                                      <option value=\"Bilaspur\">Bilaspur</option>\n                                      <option value=\"Bokaro\">Bokaro</option>\n                                      <option value=\"Calicut\">Calicut</option>\n                                      <option value=\"Chandigarh\">Chandigarh</option>\n                                      <option value=\"Chennai\">Chennai</option>\n                                      <option value=\"Cochin\">Cochin</option>\n                                      <option value=\"Coimbatore\">Coimbatore</option>\n                                      <option value=\"Cuddalore\">Cuddalore</option>\n                                      <option value=\"Cuttak\">Cuttak</option>\n                                      <option value=\"Dalhousie\">Dalhousie</option>\n                                      <option value=\"Delhi\">Delhi</option>\n                                      <option value=\"Dhanbad\">Dhanbad</option>\n                                      <option value=\"Dharmasala\">Dharmasala</option>\n                                      <option value=\"Dimapur\">Dimapur</option>\n                                      <option value=\"Ernakulam\">Ernakulam</option>\n                                      <option value=\"Faridabad\">Faridabad</option>\n                                      <option value=\"Gandhinagar\">Gandhinagar</option>\n                                      <option value=\"Gangtok\">Gangtok</option>\n                                      <option value=\"Ghaziabad\">Ghaziabad</option>\n                                      <option value=\"Goa\">Goa</option>\n                                      <option value=\"Gorakhpur\">Gorakhpur</option>\n                                      <option value=\"Gulbarga\">Gulbarga</option>\n                                      <option value=\"Guntakal\">Guntakal</option>\n                                      <option value=\"Guntur\">Guntur</option>\n                                      <option value=\"Gurugram\">Gurugram</option>\n                                      <option value=\"Guwahati\">Guwahati</option>\n                                      <option value=\"Gwalior\">Gwalior</option>\n                                      <option value=\"Hisar\">Hisar</option>\n                                      <option value=\"Hubli\">Hubli</option>\n                                      <option value=\"Hyderabad\">Hyderabad</option>\n                                      <option value=\"Imphal\">Imphal</option>\n                                      <option value=\"Indore\">Indore</option>\n                                      <option value=\"Itanagar\">Itanagar</option>\n                                      <option value=\"Jabalpur\">Jabalpur</option>\n                                      <option value=\"Jaipur\">Jaipur</option>\n                                      <option value=\"Jaisalmer\">Jaisalmer</option>\n                                      <option value=\"Jalandhar\">Jalandhar</option>\n                                      <option value=\"Jalgaon\">Jalgaon</option>\n                                      <option value=\"Jammu\">Jammu</option>\n                                      <option value=\"Jamnagar\">Jamnagar</option>\n                                      <option value=\"Jamshedpur\">Jamshedpur</option>\n                                      <option value=\"Jodhpur\">Jodhpur</option>\n                                      <option value=\"Kandla\">Kandla</option>\n                                      <option value=\"Kannur\">Kannur</option>\n                                      <option value=\"Kanpur\">Kanpur</option>\n                                      <option value=\"Karnal\">Karnal</option>\n                                      <option value=\"Kochi\">Kochi</option>\n                                      <option value=\"Kolar\">Kolar</option>\n                                      <option value=\"Kolhapur\">Kolhapur</option>\n                                      <option value=\"Kolkata\">Kolkata</option>\n                                      <option value=\"Kollam\">Kollam</option>\n                                      <option value=\"Kota\">Kota</option>\n                                      <option value=\"Kottayam\">Kottayam</option>\n                                      <option value=\"Kozhikode\">Kozhikode</option>\n                                      <option value=\"Kulu/Manali\">Kulu/Manali</option>\n                                      <option value=\"Kurukshetra\">Kurukshetra</option>\n                                      <option value=\"Lucknow\">Lucknow</option>\n                                      <option value=\"Ludhiana\">Ludhiana</option>\n                                      <option value=\"Madurai\">Madurai</option>\n                                      <option value=\"Mangalore\">Mangalore</option>\n                                      <option value=\"Mathura\">Mathura</option>\n                                      <option value=\"Meerut\">Meerut</option>\n                                      <option value=\"Mohali\">Mohali</option>\n                                      <option value=\"Moradabad\">Moradabad</option>\n                                      <option value=\"Mumbai\">Mumbai</option>\n                                      <option value=\"Mysore\">Mysore</option>\n                                      <option value=\"Nagerkoil\">Nagerkoil</option>\n                                      <option value=\"Nagpur\">Nagpur</option>\n                                      <option value=\"Nasik\">Nasik</option>\n                                      <option value=\"Noida\">Noida</option>\n                                      <option value=\"Ooty\">Ooty</option>\n                                      <option value=\"Panaji\">Panaji</option>\n                                      <option value=\"Panipat\">Panipat</option>\n                                      <option value=\"Paradeep\">Paradeep</option>\n                                      <option value=\"Pathankot\">Pathankot</option>\n                                      <option value=\"Patiala\">Patiala</option>\n                                      <option value=\"Patna\">Patna</option>\n                                      <option value=\"Porbandar\">Porbandar</option>\n                                      <option value=\"Pune\">Pune</option>\n                                      <option value=\"Puri\">Puri</option>\n                                      <option value=\"Raipur\">Raipur</option>\n                                      <option value=\"Rajkot\">Rajkot</option>\n                                      <option value=\"Ranchi\">Ranchi</option>\n                                      <option value=\"Rohtak\">Rohtak</option>\n                                      <option value=\"Rourkela\">Rourkela</option>\n                                      <option value=\"Salem\">Salem</option>\n                                      <option value=\"Shillong\">Shillong</option>\n                                      <option value=\"Shimla\">Shimla</option>\n                                      <option value=\"Silchar\">Silchar</option>\n                                      <option value=\"Solapur\">Solapur</option>\n                                      <option value=\"Srinagar\">Srinagar</option>\n                                      <option value=\"Surat\">Surat</option>\n                                      <option value=\"Thanjavur\">Thanjavur</option>\n                                      <option value=\"Tirunalveli\">Tirunalveli</option>\n                                      <option value=\"Tirupati\">Tirupati</option>\n                                      <option value=\"Trichy\">Trichy</option>\n                                      <option value=\"Trivandrum\">Trivandrum</option>\n                                      <option value=\"Tuticorin\">Tuticorin</option>\n                                      <option value=\"Udaipur\">Udaipur</option>\n                                      <option value=\"Ujjain\">Ujjain</option>\n                                      <option value=\"Vadodara/Baroda\">Vadodara/Baroda</option>\n                                      <option value=\"Valsad\">Valsad</option>\n                                      <option value=\"Vapi\">Vapi</option>\n                                      <option value=\"Vasco Da Gama\">Vasco Da Gama</option>\n                                      <option value=\"Vellore\">Vellore</option>\n                                      <option value=\"Vijayawada\">Vijayawada</option>\n                                      <option value=\"Visakhapatnam\">Visakhapatnam</option>\n                                      <option value=\"Warangal\">Warangal</option>\n                                      <option value=\"other\">other</option>\n                                    </select>\n                                    <div class=\"help-block\"></div>\n                                  </div>\n                                  <div class=\"error_block_q16 answer-error\">\n                                    <small *ngIf=\"show_City_error\">City cannot be blank.</small>\n                                  </div>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\"></div>\n                              </div>\n                            </div>\n\n\n                            <div class=\"answer answer_user_entry\">\n                              <div class=\"field_wrap_start\">\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\">\n                                  <label>Aviva Employee Id</label>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2 empDescription\">\n                                  <div class=\"form-group field-employeeID\">\n                                    <input type=\"text\" id=\"employeeID\" class=\"form-text required\"\n                                           [(ngModel)]=\"Aviva_Emp_Id\" value=\"\" size=\"60\" maxlength=\"128\"\n                                           placeholder=\"If refered by an Aviva Employee\">\n                                    <div class=\"help-block\"></div>\n                                  </div>\n                                </div>\n                                <div class=\"js-form-item-Inline js-form-item-Inline-2\"></div>\n                              </div>\n\n\n                              <div class=\"term_condition tandc-checkbox\" style=\"margin-top:50px;\">\n                                <div class=\"form-group field-terms_condition required\">\n                                  <input type=\"checkbox\" [(ngModel)]=\"Terms_Condition\" id=\"Terms_Condition\"\n                                         name=\"Terms_Condition\" value=\"Terms_Condition\" #TC_error>\n                                  <label for=\"Terms_Condition\">I have read and accept the <a (click)=\"openDialog()\"\n                                                                                             style=\"text-decoration: underline; color: blue;\">\n                                    TERMS and CONDITIONS*</a> and agree to be contacted by Aviva for any policy related,\n                                    regulatory or product related information through Email / SMS / Phone / Letter.\n                                    I authorize Aviva to contact any third party for providing such detail(s) as may\n                                    be considered relevant, in order to assess / underwrite the risk under my proposal.</label>\n                                  <!-- <div class=\"help-block\">\n                                      <small>Please Select Our Terms and Conditions</small>\n                                  </div> -->\n                                </div>\n                                <div class=\"error_block_q16 answer-error\">\n                                  <small *ngIf=\"show_TC_error\">Please select Our Terms & Condition</small>\n                                </div>\n                              </div>\n                            </div>\n\n\n                          </div>\n                          <!--</form one end>-->\n\n\n                          <!--Prev and Next-->\n                          <div class=\"final-action\">\n                            <div class=\"done-msg\">Well done!</div>\n                            <div id=\"actionsWrap\">\n                              <div class=\"quiz-error\" style=\"opacity: 0;\">Please answer all the questions.</div>\n                              <div class=\"wrap-prev\">\n                                <div class=\"left-block validateSlides firstPrev\">\n                                  <a href=\"javascript:void(0)\" class=\"prev-quiz\" style=\"\"><span\n                                    class=\"arrow-size\">‹</span> Previous</a>\n                                </div>\n                                <div class=\"right-block\">\n                                  <!-- <button class=\"next-quiz\" type=\"submit\">Next <span class=\"arrow-size\">›</span></button> -->\n                                  <a href=\"javascript:void(0)\" class=\"next-quiz\" (click)=\"sub()\">Next <span class=\"arrow-size\">›</span></a>\n                                </div>\n                                <div class=\"right-block finalSubmit validateSlides\">\n                                  <a href=\"javascript:void(0)\" class=\"next-quiz\">Submit <span\n                                    class=\"arrow-size\">›</span></a>\n                                </div>\n                                <div class=\"right-block finalSubmit1\" style=\"display:none;\">\n                                  <a href=\"javascript:void(0)\" class=\"submit-quiz\" onclick=\"smeTool();\">Submit <span\n                                    class=\"arrow-size\">›</span></a>\n                                </div>\n                              </div>\n                            </div>\n                          </div>\n\n\n                        </div>\n\n                      </div>\n\n\n                    </div>\n\n                  </div>\n\n                </div>\n              </div>\n            </main>\n          </div>\n        </section>\n\n      </div>\n\n    </div>\n  </div>\n\n  <!-- dialog terms and conditions here -->\n  <!-- end of dialog terms and conditions here -->\n\n\n</div>\n</div>\n<!-- </form>    -->\n<!------------------------Thank You Page----------------->\n\n\n<app-footer></app-footer>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/report/report.component.html":
  /*!************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/report/report.component.html ***!
    \************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppReportReportComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<form id=\"aviva_sme_form\" name=\"aviva_sme_form\" action=\"/sme?r=site/create\" method=\"post\">\n    <input type=\"hidden\" name=\"_csrf-frontend\" value=\"RZGpjD-4V8oWAx7lMn0Jfag07eRF1KfaGN7LSfJqHWYD4-PvXPRno0liaKxWSDkQz3Gqgxa287hxl4YHkxt5Vg==\">    <!--------------------Form Start--------------------------->\n    <div class=\"sme-path-quiz body-content\">\n    <div class=\"layout-container showWithoutreport\" id=\"formdata\">\n            <app-navbar></app-navbar>\n\n\n            <img src=\"assets/images/end.png\" alt=\"\" style=\"display: block;\n            margin-left: auto;\n            margin-right: auto;\n            margin-top: 110px;\n            width: 10%;\">\n            <h1 style=\"text-align: center; font-size: 30px;\"><b> Thank You! </b></h1>\n            <p style=\"text-align: center; margin-top: 20px;\">We have assessed your insurance needs and a detailed reports is availabel for download.</p>\n\n            <!-- <button class=\"\">Download Now</button> -->\n            <div class=\"final-action\" style=\"width: 50%; text-align: center; margin-left: 38%; margin-top: 5%;\">\n                <div id=\"actionsWrap\" style=\"width: 50%; text-align: center;\">\n                    <div class=\"wrap-prev\">\n                        <div class=\"right-block validateSlides\" style=\"width: 50%; text-align: center;\">\n                            <a (click)=\"downloadReport()\" class=\"next-quiz\" >Download <span class=\"arrow-size\">›</span></a>\n                        </div>\n                    </div>\n                </div>\n            </div>\n\n        </div>\n    </div>\n        </form>    <!------------------------Thank You Page----------------->\n\n\n\n\n\n<!--        <div>-->\n<!--            <button class=\"btn btn-primay\" (click)=\"onFocus()\">onFocus</button>-->\n<!--        </div>-->\n        <div>\n                <input type=\"text\" name=\"name\" #focusContent>\n        </div>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/start/start.component.html":
  /*!**********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/start/start.component.html ***!
    \**********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppStartStartComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!--------------------Wllcome Page--------------------->\n<div class=\"layout-container\" id=\"welcome\">\n\n    <div class=\"flex-class-center\" style=\"background:#ffffff;\">\n        <app-navbar></app-navbar>\n\n        <div class=\"flex-container\">\n            <div class=\"container\">\n                <div class=\"row\">\n                    <div class=\"wrapper\">\n                        <div class=\"region region-header\">\n                            <div class=\"start_page_wrap\">\n                                <div class=\"start_head\">\n                                    <img src=\"assets/images/Cover-Assist-logo-header.png\" width=\"300\" style=\"margin: auto\">\n                                </div>\n                                <div class=\"start_middle\">\n                                    <p><br>As a businessman, you juggle between multiple roles and responsibilities</p>\n                                </div>\n                                 <div class=\"start_head\">\n                                    <img src=\"assets/images/combo-image-of-3.png\" width=\"460\" style=\"margin: auto\">\n                                </div>\n                                <div class=\"start_middle\">\n                                    <p>Are you financially prepared to fulfill these multiple responsibilities?</p>\n                                </div>\n                                <div class=\"start_middle\">\n                                    <p>SME Assist, a tool which conducts your need assessment for all the roles and helps in bridging the financial gaps.</p>\n                                </div>\n                                <div class=\"start_middle\">\n                                    <img src=\"assets/images/second-combo-image-of-3.png\" width=\"430\" style=\"margin: auto\">\n                                </div>\n                                <div class=\"start_last\">\n                                    <input type=\"button\" id=\"edit-button\" name=\"button\" value=\"Get Started\" class=\"form-submit-sme\" routerLink=\"/register\">\n                                </div>\n\n                            </div>\n                        </div>\n\n                    </div>\n                </div>\n\n\n            </div>\n\n        </div>\n    </div>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/t-c/t-c.component.html":
  /*!******************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/t-c/t-c.component.html ***!
    \******************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTCTCComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- <div title=\"Basic dialog\">\r\n    <div class=\"content\" id=\"contentDiv\">\r\n        <div class=\"divTermsCondition mCustomScrollbar _mCS_1 _mCS_2\">\r\n            <div id=\"mCSB_2\" class=\"mCustomScrollBox mCS-rounded mCSB_vertical mCSB_inside\" tabindex=\"0\">\r\n                <div id=\"mCSB_2_container\" class=\"mCSB_container\" style=\"position:relative; top:0; left:0;\" dir=\"ltr\"><div id=\"mCSB_1\" class=\"mCustomScrollBox mCS-light mCSB_vertical mCSB_inside\" tabindex=\"0\">\r\n                        <div id=\"mCSB_1_container\" class=\"mCSB_container mCS_y_hidden mCS_no_scrollbar_y\" style=\"position:relative; top:0; left:0;\" dir=\"ltr\">\r\n                            <h3> General Terms &amp; Conditions</h3>\r\n                            <ul class=\"lower-alpha\">\r\n                                <li>You have voluntarily provided your information (personal and personal sensitive) to us for understanding you insurance needs.</li><br>\r\n                                <li>You agree that we may contact you through email, SMS, telephone or a letter for your insurance needs including but not limited to any policy related, regulatory or product related information. You also agree that a third party authorised by us may also contact you through email, SMS or the telephone for sharing product related information.</li>\r\n                                <br><li>You understand that the need analysis of this tool may not be 100% accurate and that it only compares the products of Aviva India in accordance with your requirements basis the information provided by you.</li>\r\n                                <br><li>You understand that by submitting this information, an insurance policy is not being issued to you.</li>\r\n                            </ul>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div> -->\r\n\r\n<div style=\"margin: -20px;\" class=\"TC\">\r\n  <h1 mat-dialog-title style=\"background-color: #004fb6;\">  &nbsp;&nbsp; Term &amp; Condition\r\n    <span style=\"float: right; margin: -2px 10px 0px 0px;\">\r\n            <button mat-dialog-close>X</button>\r\n        </span>\r\n  </h1>\r\n  <div mat-dialog-content>\r\n    <h3 style=\"padding-left: 15px; margin-top: -1px;\">General Terms &amp; Conditions</h3>\r\n    <ul style=\"padding-right: 20px;\">\r\n      <li>You have voluntarily provided your information (personal and personal sensitive) to us for understanding you insurance needs.</li>\r\n      <br>\r\n      <li>You agree that we may contact you through email, SMS, telephone or a letter for your insurance needs including but not limited to any policy related, regulatory or product related information. You also agree that a third party authorised by us may also contact you through email, SMS or the telephone for sharing product related information.</li>\r\n      <br>\r\n      <li>You understand that the need analysis of this tool may not be 100% accurate and that it only compares the products of Aviva India in accordance with your requirements basis the information provided by you.</li>\r\n      <br>\r\n      <li>You understand that by submitting this information, an insurance policy is not being issued to you.</li>\r\n    </ul>\r\n  </div>\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/tslib/tslib.es6.js":
  /*!*****************************************!*\
    !*** ./node_modules/tslib/tslib.es6.js ***!
    \*****************************************/

  /*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault */

  /***/
  function node_modulesTslibTslibEs6Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__extends", function () {
      return __extends;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__assign", function () {
      return _assign;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__rest", function () {
      return __rest;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__decorate", function () {
      return __decorate;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__param", function () {
      return __param;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__metadata", function () {
      return __metadata;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__awaiter", function () {
      return __awaiter;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__generator", function () {
      return __generator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__exportStar", function () {
      return __exportStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__values", function () {
      return __values;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__read", function () {
      return __read;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spread", function () {
      return __spread;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spreadArrays", function () {
      return __spreadArrays;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__await", function () {
      return __await;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function () {
      return __asyncGenerator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function () {
      return __asyncDelegator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncValues", function () {
      return __asyncValues;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function () {
      return __makeTemplateObject;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importStar", function () {
      return __importStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importDefault", function () {
      return __importDefault;
    });
    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0
    
    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.
    
    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */

    /* global Reflect, Promise */


    var _extendStatics = function extendStatics(d, b) {
      _extendStatics = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function (d, b) {
        d.__proto__ = b;
      } || function (d, b) {
        for (var p in b) {
          if (b.hasOwnProperty(p)) d[p] = b[p];
        }
      };

      return _extendStatics(d, b);
    };

    function __extends(d, b) {
      _extendStatics(d, b);

      function __() {
        this.constructor = d;
      }

      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var _assign = function __assign() {
      _assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];

          for (var p in s) {
            if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
          }
        }

        return t;
      };

      return _assign.apply(this, arguments);
    };

    function __rest(s, e) {
      var t = {};

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
      }

      if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
      }
      return t;
    }

    function __decorate(decorators, target, key, desc) {
      var c = arguments.length,
          r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
          d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      }
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
      return function (target, key) {
        decorator(target, key, paramIndex);
      };
    }

    function __metadata(metadataKey, metadataValue) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
      return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }

        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }

        function step(result) {
          result.done ? resolve(result.value) : new P(function (resolve) {
            resolve(result.value);
          }).then(fulfilled, rejected);
        }

        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    }

    function __generator(thisArg, body) {
      var _ = {
        label: 0,
        sent: function sent() {
          if (t[0] & 1) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      },
          f,
          y,
          t,
          g;
      return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
      }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
        return this;
      }), g;

      function verb(n) {
        return function (v) {
          return step([n, v]);
        };
      }

      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");

        while (_) {
          try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];

            switch (op[0]) {
              case 0:
              case 1:
                t = op;
                break;

              case 4:
                _.label++;
                return {
                  value: op[1],
                  done: false
                };

              case 5:
                _.label++;
                y = op[1];
                op = [0];
                continue;

              case 7:
                op = _.ops.pop();

                _.trys.pop();

                continue;

              default:
                if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                  _ = 0;
                  continue;
                }

                if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                  _.label = op[1];
                  break;
                }

                if (op[0] === 6 && _.label < t[1]) {
                  _.label = t[1];
                  t = op;
                  break;
                }

                if (t && _.label < t[2]) {
                  _.label = t[2];

                  _.ops.push(op);

                  break;
                }

                if (t[2]) _.ops.pop();

                _.trys.pop();

                continue;
            }

            op = body.call(thisArg, _);
          } catch (e) {
            op = [6, e];
            y = 0;
          } finally {
            f = t = 0;
          }
        }

        if (op[0] & 5) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    }

    function __exportStar(m, exports) {
      for (var p in m) {
        if (!exports.hasOwnProperty(p)) exports[p] = m[p];
      }
    }

    function __values(o) {
      var m = typeof Symbol === "function" && o[Symbol.iterator],
          i = 0;
      if (m) return m.call(o);
      return {
        next: function next() {
          if (o && i >= o.length) o = void 0;
          return {
            value: o && o[i++],
            done: !o
          };
        }
      };
    }

    function __read(o, n) {
      var m = typeof Symbol === "function" && o[Symbol.iterator];
      if (!m) return o;
      var i = m.call(o),
          r,
          ar = [],
          e;

      try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) {
          ar.push(r.value);
        }
      } catch (error) {
        e = {
          error: error
        };
      } finally {
        try {
          if (r && !r.done && (m = i["return"])) m.call(i);
        } finally {
          if (e) throw e.error;
        }
      }

      return ar;
    }

    function __spread() {
      for (var ar = [], i = 0; i < arguments.length; i++) {
        ar = ar.concat(__read(arguments[i]));
      }

      return ar;
    }

    function __spreadArrays() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++) {
        s += arguments[i].length;
      }

      for (var r = Array(s), k = 0, i = 0; i < il; i++) {
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) {
          r[k] = a[j];
        }
      }

      return r;
    }

    ;

    function __await(v) {
      return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var g = generator.apply(thisArg, _arguments || []),
          i,
          q = [];
      return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i;

      function verb(n) {
        if (g[n]) i[n] = function (v) {
          return new Promise(function (a, b) {
            q.push([n, v, a, b]) > 1 || resume(n, v);
          });
        };
      }

      function resume(n, v) {
        try {
          step(g[n](v));
        } catch (e) {
          settle(q[0][3], e);
        }
      }

      function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
      }

      function fulfill(value) {
        resume("next", value);
      }

      function reject(value) {
        resume("throw", value);
      }

      function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
      }
    }

    function __asyncDelegator(o) {
      var i, p;
      return i = {}, verb("next"), verb("throw", function (e) {
        throw e;
      }), verb("return"), i[Symbol.iterator] = function () {
        return this;
      }, i;

      function verb(n, f) {
        i[n] = o[n] ? function (v) {
          return (p = !p) ? {
            value: __await(o[n](v)),
            done: n === "return"
          } : f ? f(v) : v;
        } : f;
      }
    }

    function __asyncValues(o) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var m = o[Symbol.asyncIterator],
          i;
      return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i);

      function verb(n) {
        i[n] = o[n] && function (v) {
          return new Promise(function (resolve, reject) {
            v = o[n](v), settle(resolve, reject, v.done, v.value);
          });
        };
      }

      function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function (v) {
          resolve({
            value: v,
            done: d
          });
        }, reject);
      }
    }

    function __makeTemplateObject(cooked, raw) {
      if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", {
          value: raw
        });
      } else {
        cooked.raw = raw;
      }

      return cooked;
    }

    ;

    function __importStar(mod) {
      if (mod && mod.__esModule) return mod;
      var result = {};
      if (mod != null) for (var k in mod) {
        if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
      }
      result.default = mod;
      return result;
    }

    function __importDefault(mod) {
      return mod && mod.__esModule ? mod : {
        default: mod
      };
    }
    /***/

  },

  /***/
  "./src/app/aesencryption-decryption.service.ts":
  /*!*****************************************************!*\
    !*** ./src/app/aesencryption-decryption.service.ts ***!
    \*****************************************************/

  /*! exports provided: AESEncryptionDecryptionService */

  /***/
  function srcAppAesencryptionDecryptionServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AESEncryptionDecryptionService", function () {
      return AESEncryptionDecryptionService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var crypto_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! crypto-js */
    "./node_modules/crypto-js/index.js");
    /* harmony import */


    var crypto_js__WEBPACK_IMPORTED_MODULE_2___default =
    /*#__PURE__*/
    __webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_2__);

    var AESEncryptionDecryptionService =
    /*#__PURE__*/
    function () {
      function AESEncryptionDecryptionService() {
        _classCallCheck(this, AESEncryptionDecryptionService);

        this.secretKey = "AVIVASME#2020";
      }

      _createClass(AESEncryptionDecryptionService, [{
        key: "encrypt",
        value: function encrypt(value) {
          return crypto_js__WEBPACK_IMPORTED_MODULE_2__["AES"].encrypt(value, this.secretKey.trim()).toString();
        }
      }, {
        key: "decrypt",
        value: function decrypt(textToDecrypt) {
          return crypto_js__WEBPACK_IMPORTED_MODULE_2__["AES"].decrypt(textToDecrypt, this.secretKey.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Utf8);
        }
      }, {
        key: "encryptRequestTest",
        value: function encryptRequestTest(str) {
          var iv = "2b61bb1c405a3d1a6479f31b849c372a";
          var s = "87d25e5d94d46fd5";
          var CryptoJSAesJson = {
            stringify: function stringify(cipherParams) {
              var j = {
                ct: cipherParams.ciphertext.toString(crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Base64)
              };
              if (cipherParams.iv) j.iv = iv;
              if (cipherParams.salt) j.s = s; //console.log("params:-"+JSON.stringify(j));

              return JSON.stringify(j);
            },
            parse: function parse(jsonStr) {
              var j = JSON.parse(jsonStr); //console.log("j.iv:-"+j.iv);
              //console.log("j.s:-"+j.s);

              var cipherParams = crypto_js__WEBPACK_IMPORTED_MODULE_2__["lib"].CipherParams.create({
                ciphertext: crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Base64.parse(j.ct)
              });
              if (j.iv) cipherParams.iv = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Hex.parse(iv);
              if (j.s) cipherParams.salt = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Hex.parse(s);
              return cipherParams;
            }
          };
          var encryption = crypto_js__WEBPACK_IMPORTED_MODULE_2__["AES"].encrypt(str, this.secretKey, {
            format: CryptoJSAesJson
          });
          var encrypted = encryption.toString();
          var encryptedString = JSON.parse(encryption).ct + "," + JSON.parse(encryption).iv + "," + JSON.parse(encryption).s; //console.log("encryptedString:-" + encryptedString);

          return JSON.parse(encryption).ct;
        }
      }, {
        key: "encryptRequest",
        value: function encryptRequest(str) {
          var CryptoJSAesJson = {
            stringify: function stringify(cipherParams) {
              var j = {
                ct: cipherParams.ciphertext.toString(crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Base64)
              };
              if (cipherParams.iv) j.iv = cipherParams.iv.toString();
              if (cipherParams.salt) j.s = cipherParams.salt.toString();
              return JSON.stringify(j);
            },
            parse: function parse(jsonStr) {
              var j = JSON.parse(jsonStr);
              var cipherParams = crypto_js__WEBPACK_IMPORTED_MODULE_2__["lib"].CipherParams.create({
                ciphertext: crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Base64.parse(j.ct)
              });
              if (j.iv) cipherParams.iv = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Hex.parse(j.iv);
              if (j.s) cipherParams.salt = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Hex.parse(j.s);
              return cipherParams;
            }
          };
          var encryption = crypto_js__WEBPACK_IMPORTED_MODULE_2__["AES"].encrypt(str, this.secretKey, {
            format: CryptoJSAesJson
          });
          var encrypted = encryption.toString();
          var encryptedString = JSON.parse(encryption).ct + "%A%T" + JSON.parse(encryption).iv + "%A%T" + JSON.parse(encryption).s; // //console.log("encryptedString:-" + encryptedString);

          return encryptedString;
        }
      }, {
        key: "parseEncryptedResponse",
        value: function parseEncryptedResponse(responseData) {
          //console.log("responsedata:-" + responseData);
          var ct = responseData.split("%A%T")[0];
          var iv = responseData.split("%A%T")[1];
          var s = responseData.split("%A%T")[2]; //console.log("ct:-" + ct);
          //console.log("iv:-" + iv);
          //console.log("s:-" + s);

          var encrypted1 = {
            ct: ct,
            iv: iv,
            s: s
          };
          var CryptoJSAesJson = {
            stringify: function stringify(cipherParams) {
              var j = {
                ct: cipherParams.ciphertext.toString(crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Base64)
              };
              if (cipherParams.iv) j.iv = cipherParams.iv.toString();
              if (cipherParams.salt) j.s = cipherParams.salt.toString();
              return JSON.stringify(j);
            },
            parse: function parse(jsonStr) {
              var j = JSON.parse(jsonStr);
              var cipherParams = crypto_js__WEBPACK_IMPORTED_MODULE_2__["lib"].CipherParams.create({
                ciphertext: crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Base64.parse(j.ct)
              });
              if (j.iv) cipherParams.iv = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Hex.parse(j.iv);
              if (j.s) cipherParams.salt = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Hex.parse(j.s);
              return cipherParams;
            }
          };
          var decrypted = JSON.parse(crypto_js__WEBPACK_IMPORTED_MODULE_2__["AES"].decrypt(JSON.stringify(encrypted1), this.secretKey, {
            format: CryptoJSAesJson
          }).toString(crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Utf8));
          return decrypted;
        }
      }]);

      return AESEncryptionDecryptionService;
    }();

    AESEncryptionDecryptionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], AESEncryptionDecryptionService);
    /***/
  },

  /***/
  "./src/app/app-routing.module.ts":
  /*!***************************************!*\
    !*** ./src/app/app-routing.module.ts ***!
    \***************************************/

  /*! exports provided: AppRoutingModule */

  /***/
  function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
      return AppRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _register_register_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./register/register.component */
    "./src/app/register/register.component.ts");
    /* harmony import */


    var _owner_owner_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./owner/owner.component */
    "./src/app/owner/owner.component.ts");
    /* harmony import */


    var _start_start_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./start/start.component */
    "./src/app/start/start.component.ts");
    /* harmony import */


    var _head_family_head_family_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./head-family/head-family.component */
    "./src/app/head-family/head-family.component.ts");
    /* harmony import */


    var _employer_employer_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./employer/employer.component */
    "./src/app/employer/employer.component.ts");
    /* harmony import */


    var _report_report_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./report/report.component */
    "./src/app/report/report.component.ts");
    /* harmony import */


    var _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./page-not-found/page-not-found.component */
    "./src/app/page-not-found/page-not-found.component.ts");

    var routes = [{
      path: 'register',
      component: _register_register_component__WEBPACK_IMPORTED_MODULE_3__["RegisterComponent"]
    }, {
      path: 'owner',
      component: _owner_owner_component__WEBPACK_IMPORTED_MODULE_4__["OwnerComponent"]
    }, {
      path: '',
      component: _start_start_component__WEBPACK_IMPORTED_MODULE_5__["StartComponent"]
    }, {
      path: 'head-family',
      component: _head_family_head_family_component__WEBPACK_IMPORTED_MODULE_6__["HeadFamilyComponent"]
    }, {
      path: 'employer',
      component: _employer_employer_component__WEBPACK_IMPORTED_MODULE_7__["EmployerComponent"]
    }, {
      path: 'report',
      component: _report_report_component__WEBPACK_IMPORTED_MODULE_8__["ReportComponent"]
    }, {
      path: '**',
      component: _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_9__["PageNotFoundComponent"]
    }];

    var AppRoutingModule = function AppRoutingModule() {
      _classCallCheck(this, AppRoutingModule);
    };

    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, {
        scrollPositionRestoration: 'enabled',
        useHash: true
      })],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AppRoutingModule);
    /***/
  },

  /***/
  "./src/app/app.component.css":
  /*!***********************************!*\
    !*** ./src/app/app.component.css ***!
    \***********************************/

  /*! exports provided: default */

  /***/
  function srcAppAppComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/app.component.ts":
  /*!**********************************!*\
    !*** ./src/app/app.component.ts ***!
    \**********************************/

  /*! exports provided: AppComponent */

  /***/
  function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
      return AppComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var AppComponent = function AppComponent() {
      _classCallCheck(this, AppComponent);

      this.title = 'sme1';
    };

    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-root',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./app.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./app.component.css */
      "./src/app/app.component.css")).default]
    })], AppComponent);
    /***/
  },

  /***/
  "./src/app/app.module.ts":
  /*!*******************************!*\
    !*** ./src/app/app.module.ts ***!
    \*******************************/

  /*! exports provided: AppModule */

  /***/
  function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppModule", function () {
      return AppModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./app-routing.module */
    "./src/app/app-routing.module.ts");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./app.component */
    "./src/app/app.component.ts");
    /* harmony import */


    var _start_start_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./start/start.component */
    "./src/app/start/start.component.ts");
    /* harmony import */


    var _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./navbar/navbar.component */
    "./src/app/navbar/navbar.component.ts");
    /* harmony import */


    var _footer_footer_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./footer/footer.component */
    "./src/app/footer/footer.component.ts");
    /* harmony import */


    var _employer_employer_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./employer/employer.component */
    "./src/app/employer/employer.component.ts");
    /* harmony import */


    var _head_family_head_family_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./head-family/head-family.component */
    "./src/app/head-family/head-family.component.ts");
    /* harmony import */


    var _owner_owner_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./owner/owner.component */
    "./src/app/owner/owner.component.ts");
    /* harmony import */


    var _register_register_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./register/register.component */
    "./src/app/register/register.component.ts");
    /* harmony import */


    var _report_report_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./report/report.component */
    "./src/app/report/report.component.ts");
    /* harmony import */


    var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! @angular/platform-browser/animations */
    "./node_modules/@angular/platform-browser/fesm2015/animations.js");
    /* harmony import */


    var _material__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! ./material */
    "./src/app/material.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _t_c_t_c_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! ./t-c/t-c.component */
    "./src/app/t-c/t-c.component.ts");
    /* harmony import */


    var _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! ./page-not-found/page-not-found.component */
    "./src/app/page-not-found/page-not-found.component.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
    /*! ./aesencryption-decryption.service */
    "./src/app/aesencryption-decryption.service.ts");

    var AppModule = function AppModule() {
      _classCallCheck(this, AppModule);
    };

    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
      declarations: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"], _start_start_component__WEBPACK_IMPORTED_MODULE_5__["StartComponent"], _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_6__["NavbarComponent"], _footer_footer_component__WEBPACK_IMPORTED_MODULE_7__["FooterComponent"], _employer_employer_component__WEBPACK_IMPORTED_MODULE_8__["EmployerComponent"], _head_family_head_family_component__WEBPACK_IMPORTED_MODULE_9__["HeadFamilyComponent"], _owner_owner_component__WEBPACK_IMPORTED_MODULE_10__["OwnerComponent"], _register_register_component__WEBPACK_IMPORTED_MODULE_11__["RegisterComponent"], _report_report_component__WEBPACK_IMPORTED_MODULE_12__["ReportComponent"], _t_c_t_c_component__WEBPACK_IMPORTED_MODULE_16__["TCComponent"], _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_17__["PageNotFoundComponent"]],
      entryComponents: [_t_c_t_c_component__WEBPACK_IMPORTED_MODULE_16__["TCComponent"]],
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__["BrowserAnimationsModule"], _material__WEBPACK_IMPORTED_MODULE_14__["MaterialModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_15__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_15__["ReactiveFormsModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_18__["HttpClientModule"]],
      providers: [_aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_19__["AESEncryptionDecryptionService"]],
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]]
    })], AppModule);
    /***/
  },

  /***/
  "./src/app/employer/employer.component.css":
  /*!*************************************************!*\
    !*** ./src/app/employer/employer.component.css ***!
    \*************************************************/

  /*! exports provided: default */

  /***/
  function srcAppEmployerEmployerComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2VtcGxveWVyL2VtcGxveWVyLmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/employer/employer.component.ts":
  /*!************************************************!*\
    !*** ./src/app/employer/employer.component.ts ***!
    \************************************************/

  /*! exports provided: EmployerComponent */

  /***/
  function srcAppEmployerEmployerComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EmployerComponent", function () {
      return EmployerComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _utils_BaseComp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../utils/BaseComp */
    "./src/app/utils/BaseComp.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../aesencryption-decryption.service */
    "./src/app/aesencryption-decryption.service.ts");

    var EmployerComponent =
    /*#__PURE__*/
    function (_utils_BaseComp__WEBP) {
      _inherits(EmployerComponent, _utils_BaseComp__WEBP);

      function EmployerComponent(route, http, aesEncryptionDecryptionService) {
        var _this;

        _classCallCheck(this, EmployerComponent);

        _this = _possibleConstructorReturn(this, _getPrototypeOf(EmployerComponent).call(this));
        _this.route = route;
        _this.http = http;
        _this.aesEncryptionDecryptionService = aesEncryptionDecryptionService;
        _this.unselected_option_class = 'form-group field-remp1 field-empCha1 field-gratuityemp1 field-edli1 field-checkkm';
        _this.selected_option_class = 'form-group field-remp2 field-empCha2 field-gratuityemp2 field-edli2 field-checkpi backradio';
        _this.critical_employees = '';
        _this.Less_class = '';
        _this.Between_class = '';
        _this.More_class = '';
        _this.q1_Less = 'q1_Less';
        _this.q1_Between = 'q1_Between';
        _this.q1_More = 'q1_More';
        _this.q1_selected_option = '';
        _this.q1_show_error = false;
        _this.q2_CurrentEmployees = '';
        _this.No_class = '';
        _this.NoSignificant_class = '';
        _this.Significant_class = '';
        _this.q3_No = 'q3_No';
        _this.q3_NoSiginificant = 'q3_NoSiginificant';
        _this.q3_Significant = 'q3_Significant';
        _this.q3_selected_option = '';
        _this.q3_show_error = false;
        _this.q4_KeyMan = 'q4_KeyMan';
        _this.q4_Partnership = 'q4_Partnership';
        _this.q4_employeePolicy = 'q4_employeePolicy';
        _this.q4_None = 'q4_None';
        _this.q4_selected_option = '';
        _this.q4_show_error = false;
        _this.NoGratuity_class = '';
        _this.MyGratuity_class = '';
        _this.HaveGratuity_class = '';
        _this.q5_NoGratuity = 'q5_NoGratuity';
        _this.q5_MyGratuity = 'q5_MyGratuity';
        _this.q5_HaveGratuity = 'q5_HaveGratuity';
        _this.q5_selected_option = '';
        _this.q5_show_error = false;
        _this.NotEligible_class = '';
        _this.HavePF_class = '';
        _this.OptedEDLI_class = '';
        _this.q6_NotEligible = 'q6_NotEligible';
        _this.q6_HavePF = 'q6_HavePF';
        _this.q6_OptedEDLI = 'q6_OptedEDLI';
        _this.q6_selected_option = '';
        _this.q6_show_error = false;
        _this.Key_class = '';
        _this.Partnership_class = '';
        _this.Employer_class = '';
        _this.None_class = '';
        return _this;
      }

      _createClass(EmployerComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.Less_class = this.unselected_option_class;
          this.Between_class = this.unselected_option_class;
          this.More_class = this.unselected_option_class;
          this.No_class = this.unselected_option_class;
          this.NoSignificant_class = this.unselected_option_class;
          this.NoGratuity_class = this.unselected_option_class;
          this.MyGratuity_class = this.unselected_option_class;
          this.HaveGratuity_class = this.unselected_option_class;
          this.NotEligible_class = this.unselected_option_class;
          this.HavePF_class = this.unselected_option_class;
          this.OptedEDLI_class = this.unselected_option_class;
          this.Key_class = this.unselected_option_class;
          this.Partnership_class = this.unselected_option_class;
          this.Employer_class = this.unselected_option_class;
          this.None_class = this.unselected_option_class; //console.log('register data:-' + this.getSessionStoredItem(this.REGISTER_DATA));

          if (this.getSessionStoredItem(this.REGISTER_DATA) == null || this.getSessionStoredItem(this.REGISTER_DATA) == '' || this.getSessionStoredItem(this.REGISTER_DATA) == 'null') {
            this.route.navigate(['/register']);
          } else if (this.getSessionStoredItem(this.OWNER_DATA) == null && this.getSessionStoredItem(this.OWNER_DATA) == '' && this.getSessionStoredItem(this.OWNER_DATA) == 'null') {
            this.route.navigate(['/owner']);
          } //console.log('p1_q1:-' + window.sessionStorage.getItem('p1_q1'));


          if (window.sessionStorage.getItem('p1_q1') != '') {
            switch (window.sessionStorage.getItem('p1_q1')) {
              case 'Less than 10':
                this.selectedOptions(0);
                break;

              case 'Between 10-20':
                this.selectedOptions(1);
                break;

              case 'More than 20':
                this.selectedOptions(2);
                break;
            }
          }

          this.q2_CurrentEmployees = window.sessionStorage.getItem('p1_q2') == null ? '' : window.sessionStorage.getItem('p1_q2'); //console.log('p1_q3:-' + window.sessionStorage.getItem('p1_q3'));

          if (window.sessionStorage.getItem('p1_q3') != '') {
            switch (window.sessionStorage.getItem('p1_q3')) {
              case 'No significant impact':
                this.selectedOptionsQ3(0);
                break;

              case 'Significant impact/Business disruption':
                this.selectedOptionsQ3(1);
                break;

              case 'None of these':
                this.selectedOptionsQ3(2);
                break;
            }
          } // ,Partnership Insurance
          //console.log('p1_q4:-' + window.sessionStorage.getItem('p1_q4'));


          if (window.sessionStorage.getItem('p1_q4') != '') {
            var q4 = window.sessionStorage.getItem('p1_q4');

            if (q4 != null && q4 != undefined && q4.includes('Key Man Insurance')) {
              this.selectedOptionsQ4(0);
            }

            if (q4 != null && q4 != undefined && q4.includes('Partnership Insurance')) {
              this.selectedOptionsQ4(1);
            }

            if (q4 != null && q4 != undefined && q4.includes('Employer Employee Policy')) {
              this.selectedOptionsQ4(2);
            }

            if (q4 != null && q4 != undefined && q4.includes('None')) {
              this.selectedOptionsQ4(3);
            }
          } //console.log('p1_q5:-' + window.sessionStorage.getItem('p1_q5'));


          if (window.sessionStorage.getItem('p1_q5') != '') {
            switch (window.sessionStorage.getItem('p1_q5')) {
              case "My employees are not On Roll and do not need gratuity":
                this.selectedOptionsQ5(0);
                break;

              case "I manage my employees' gratuity myself":
                this.selectedOptionsQ5(1);
                break;

              case "I already have a gratuity policy from an insurer":
                this.selectedOptionsQ5(2);
                break;
            }
          } //console.log('p1_q6:-' + window.sessionStorage.getItem('p1_q6'));


          if (window.sessionStorage.getItem('p1_q6') != '') {
            switch (window.sessionStorage.getItem('p1_q6')) {
              case "My employees are not eligible for PF":
                this.selectedOptionsQ6(0);
                break;

              case "My employees have PF but I do not have an EDLI policy":
                this.selectedOptionsQ6(1);
                break;

              case "I have opted for an EDLI policy from an insurer":
                this.selectedOptionsQ6(2);
                break;
            }
          }
        }
      }, {
        key: "selectedOptions",
        value: function selectedOptions(index) {
          switch (index) {
            case 0:
              this.Less_class = this.selected_option_class;
              this.Between_class = this.unselected_option_class;
              this.More_class = this.unselected_option_class;
              this.q1_selected_option = this.q1_Less; // for error remove

              this.q1_show_error = false;
              break;

            case 1:
              this.Less_class = this.unselected_option_class;
              this.Between_class = this.selected_option_class;
              this.More_class = this.unselected_option_class;
              this.q1_selected_option = this.q1_Between; // for error remove

              this.q1_show_error = false;
              break;

            case 2:
              this.Less_class = this.unselected_option_class;
              this.Between_class = this.unselected_option_class;
              this.More_class = this.selected_option_class;
              this.q1_selected_option = this.q1_More; // for error remove

              this.q1_show_error = false;
              break;
          }
        }
      }, {
        key: "selectedOptionsQ3",
        value: function selectedOptionsQ3(index) {
          switch (index) {
            case 0:
              this.No_class = this.selected_option_class;
              this.NoSignificant_class = this.unselected_option_class;
              this.Significant_class = this.unselected_option_class;
              this.q3_selected_option = this.q3_No; // for error remove

              this.q3_show_error = false;
              break;

            case 1:
              this.No_class = this.unselected_option_class;
              this.NoSignificant_class = this.selected_option_class;
              this.Significant_class = this.unselected_option_class;
              this.q3_selected_option = this.q3_NoSiginificant; // for error remove

              this.q3_show_error = false;
              break;

            case 2:
              this.No_class = this.unselected_option_class;
              this.NoSignificant_class = this.unselected_option_class;
              this.Significant_class = this.selected_option_class;
              this.q3_selected_option = this.q3_Significant; // for error remove

              this.q3_show_error = false;
              break;
          }
        }
      }, {
        key: "selectedOptionsQ5",
        value: function selectedOptionsQ5(index) {
          switch (index) {
            case 0:
              this.NoGratuity_class = this.selected_option_class;
              this.MyGratuity_class = this.unselected_option_class;
              this.HaveGratuity_class = this.unselected_option_class;
              this.q5_selected_option = this.q5_NoGratuity; // for error remove

              this.q5_show_error = false;
              break;

            case 1:
              this.NoGratuity_class = this.unselected_option_class;
              this.MyGratuity_class = this.selected_option_class;
              this.HaveGratuity_class = this.unselected_option_class;
              this.q5_selected_option = this.q5_MyGratuity; // for error remove

              this.q5_show_error = false;
              break;

            case 2:
              this.NoGratuity_class = this.unselected_option_class;
              this.MyGratuity_class = this.unselected_option_class;
              this.HaveGratuity_class = this.selected_option_class;
              this.q5_selected_option = this.q5_HaveGratuity; // for error remove

              this.q5_show_error = false;
              break;
          }
        }
      }, {
        key: "selectedOptionsQ6",
        value: function selectedOptionsQ6(index) {
          switch (index) {
            case 0:
              this.NotEligible_class = this.selected_option_class;
              this.HavePF_class = this.unselected_option_class;
              this.OptedEDLI_class = this.unselected_option_class;
              this.q6_selected_option = this.q6_HavePF; // for error remove

              this.q6_show_error = false;
              break;

            case 1:
              this.NotEligible_class = this.unselected_option_class;
              this.HavePF_class = this.selected_option_class;
              this.OptedEDLI_class = this.unselected_option_class;
              this.q6_selected_option = this.q6_NotEligible; // for error remove

              this.q6_show_error = false;
              break;

            case 2:
              this.NotEligible_class = this.unselected_option_class;
              this.HavePF_class = this.unselected_option_class;
              this.OptedEDLI_class = this.selected_option_class;
              this.q6_selected_option = this.q6_OptedEDLI; // for error remove

              this.q6_show_error = false;
              break;
          }
        }
      }, {
        key: "selectedOptionsQ4",
        value: function selectedOptionsQ4(index) {
          switch (index) {
            case 0:
              if (this.Key_class != this.selected_option_class) {
                this.Key_class = this.selected_option_class;
              } else {
                this.Key_class = this.unselected_option_class;
              }

              this.None_class = this.unselected_option_class;
              this.q4_selected_option = this.q4_KeyMan; // for error remove

              this.q4_show_error = false;
              break;

            case 1:
              if (this.Partnership_class != this.selected_option_class) {
                this.Partnership_class = this.selected_option_class;
              } else {
                this.Partnership_class = this.unselected_option_class;
              }

              this.None_class = this.unselected_option_class;
              this.q4_selected_option = this.q4_Partnership; // for error remove

              this.q4_show_error = false;
              break;

            case 2:
              if (this.Employer_class != this.selected_option_class) {
                this.Employer_class = this.selected_option_class;
              } else {
                this.Employer_class = this.unselected_option_class;
              }

              this.None_class = this.unselected_option_class;
              this.q4_selected_option = this.q4_employeePolicy; // for error remove

              this.q4_show_error = false;
              break;

            case 3:
              this.None_class = this.selected_option_class;
              this.Key_class = this.unselected_option_class;
              this.Partnership_class = this.unselected_option_class;
              this.Employer_class = this.unselected_option_class;
              this.q4_selected_option = this.q4_None; // for error remove

              this.q4_show_error = false;
              break;
          } // window.sessionStorage.setItem("name",);
          // window.sessionStorage.getItem("name");

        }
      }, {
        key: "next",
        value: function next() {
          var _this2 = this;

          //console.log('On Roll Employees:-' + this.q1_selected_option);
          //console.log('Current Employees:-' + this.q2_CurrentEmployees);
          //console.log('Your Business:-' + this.q3_selected_option);
          //console.log('Business Solutions:-' + this.q4_selected_option);
          //console.log('Business Insurance:-' + this.q5_selected_option);
          //console.log('PF Facility:-' + this.q6_selected_option);
          // if(this.q1_selected_option=="" || this.q3_selected_option=="" && this.q5_selected_option=="" ||
          //   this.q6_selected_option==""){
          //   // alert("Please select the number of on-roll employees");
          //   this.q1_show_error = true;
          //   this.q3_show_error = true;
          //   this.q5_show_error = true;
          //   this.q6_show_error = true;
          //   return;
          // }
          if (this.q1_selected_option == '') {
            this.q1_show_error = true;
            this.q1_error.nativeElement.focus();
            return;
          }

          if (this.q3_selected_option == '') {
            this.q3_show_error = true;
            this.q3_error.nativeElement.focus();
            return;
          }

          if (this.q4_selected_option == '') {
            this.q4_show_error = true;
            this.q4_error.nativeElement.focus();
            return;
          }

          if (this.q5_selected_option == '') {
            this.q5_show_error = true;
            this.q5_error.nativeElement.focus();
            return;
          }

          if (this.q6_selected_option == '') {
            this.q6_show_error = true;
            this.q6_error.nativeElement.focus();
            return;
          }

          var q1 = '';
          var q2 = this.q2_CurrentEmployees;
          var q3 = '';
          var q4 = '';
          var q5 = '';
          var q6 = '';

          if (this.q1_selected_option == this.q1_Less) {
            q1 = 'Less than 10';
          } else if (this.q1_selected_option == this.q1_Between) {
            q1 = 'Between 10-20';
          } else if (this.q1_selected_option == this.q1_More) {
            q1 = 'More than 20';
          }

          if (this.q3_selected_option == this.q3_NoSiginificant) {
            q3 = 'No significant impact';
          } else if (this.q3_selected_option == this.q3_Significant) {
            q3 = 'Significant impact/Business disruption';
          } else if (this.q3_selected_option == this.q3_No) {
            q3 = 'None of these';
          }

          if (this.q4_selected_option == this.q4_None) {
            q4 = 'None';
          } else {
            q4 = '';

            if (this.Key_class == this.selected_option_class) {
              q4 += 'Key Man Insurance';
            }

            if (this.Partnership_class == this.selected_option_class) {
              if (q4 != '') {
                q4 += ',Partnership Insurance';
              } else {
                q4 += 'Partnership Insurance';
              }
            }

            if (this.Employer_class == this.selected_option_class) {
              if (q4 != '') {
                q4 += ',Employer Employee Policy';
              } else {
                q4 += 'Employer Employee Policy';
              }
            }
          }

          if (this.q5_selected_option == this.q5_NoGratuity) {
            q5 = 'My employees are not On Roll and do not need gratuity';
          } else if (this.q5_selected_option == this.q5_MyGratuity) {
            q5 = 'I manage my employees\' gratuity myself';
          } else if (this.q5_selected_option == this.q5_HaveGratuity) {
            q5 = 'I already have a gratuity policy from an insurer';
          }

          if (this.q6_selected_option == this.q6_HavePF) {
            q6 = 'My employees are not eligible for PF';
          } else if (this.q6_selected_option == this.q6_NotEligible) {
            q6 = 'My employees have PF but I do not have an EDLI policy';
          } else if (this.q6_selected_option == this.q6_OptedEDLI) {
            q6 = 'I have opted for an EDLI policy from an insurer';
          } //console.log('q1:-' + q1);
          //console.log('q2:-' + q2);
          //console.log('q3:-' + q3);
          //console.log('q4:-' + q4);
          //console.log('q5:-' + q5);
          //console.log('q6:-' + q6);


          window.sessionStorage.setItem('p1_q1', q1);
          window.sessionStorage.setItem('p1_q2', q2);
          window.sessionStorage.setItem('p1_q3', q3);
          window.sessionStorage.setItem('p1_q4', q4);
          window.sessionStorage.setItem('p1_q5', q5);
          window.sessionStorage.setItem('p1_q6', q6);
          var postData = {
            user_id: this.getUser().user_id,
            q1: q1,
            q2: q2,
            q3: q3,
            q4: q4,
            q5: q5,
            q6: q6
          };
          var formData = {
            request: this.aesEncryptionDecryptionService.encryptRequest(JSON.stringify(postData))
          }; //console.log("formdata:-" + JSON.stringify(formData));

          this.http.post(this.getSessionStoredItem(this.BASE_URL) + this.SAVE_EMPLOYER_URL, JSON.stringify(formData), {
            responseType: 'text'
          }).subscribe(function (data) {
            try {
              //console.log('data received:-' + data);
              var parsedData = JSON.parse(data);

              var parsedJSON = _this2.aesEncryptionDecryptionService.parseEncryptedResponse(parsedData.response);

              if (parsedJSON.status) {
                _this2.setSessionStoredItem(_this2.SAVE_EMPLOYER, JSON.stringify(parsedJSON.data));

                _this2.route.navigate(['/head-family']);
              } else {
                alert(parsedJSON.message);
              }
            } catch (e) {//console.log(e);
            }
          }); //console.log('onroll:-' + window.sessionStorage.getItem('on_roll_employees'));
          //console.log('current:-' + window.sessionStorage.getItem('current_employees'));
          // alert("all good please go ahead");
          //   this.route.navigate(['/head-family']);
        }
      }]);

      return EmployerComponent;
    }(_utils_BaseComp__WEBPACK_IMPORTED_MODULE_3__["BaseComp"]);

    EmployerComponent.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
      }, {
        type: _aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_5__["AESEncryptionDecryptionService"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q1_error', {
      static: false
    })], EmployerComponent.prototype, "q1_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q3_error', {
      static: false
    })], EmployerComponent.prototype, "q3_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q4_error', {
      static: false
    })], EmployerComponent.prototype, "q4_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q5_error', {
      static: false
    })], EmployerComponent.prototype, "q5_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q6_error', {
      static: false
    })], EmployerComponent.prototype, "q6_error", void 0);
    EmployerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-employer',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./employer.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/employer/employer.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./employer.component.css */
      "./src/app/employer/employer.component.css")).default]
    })], EmployerComponent);
    /***/
  },

  /***/
  "./src/app/footer/footer.component.css":
  /*!*********************************************!*\
    !*** ./src/app/footer/footer.component.css ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppFooterFooterComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50LmNzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/footer/footer.component.ts":
  /*!********************************************!*\
    !*** ./src/app/footer/footer.component.ts ***!
    \********************************************/

  /*! exports provided: FooterComponent */

  /***/
  function srcAppFooterFooterComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FooterComponent", function () {
      return FooterComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var FooterComponent =
    /*#__PURE__*/
    function () {
      function FooterComponent() {
        _classCallCheck(this, FooterComponent);
      }

      _createClass(FooterComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return FooterComponent;
    }();

    FooterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-footer',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./footer.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/footer/footer.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./footer.component.css */
      "./src/app/footer/footer.component.css")).default]
    })], FooterComponent);
    /***/
  },

  /***/
  "./src/app/head-family/head-family.component.css":
  /*!*******************************************************!*\
    !*** ./src/app/head-family/head-family.component.css ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppHeadFamilyHeadFamilyComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2hlYWQtZmFtaWx5L2hlYWQtZmFtaWx5LmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/head-family/head-family.component.ts":
  /*!******************************************************!*\
    !*** ./src/app/head-family/head-family.component.ts ***!
    \******************************************************/

  /*! exports provided: HeadFamilyComponent */

  /***/
  function srcAppHeadFamilyHeadFamilyComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HeadFamilyComponent", function () {
      return HeadFamilyComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _utils_BaseComp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../utils/BaseComp */
    "./src/app/utils/BaseComp.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../aesencryption-decryption.service */
    "./src/app/aesencryption-decryption.service.ts");

    var HeadFamilyComponent =
    /*#__PURE__*/
    function (_utils_BaseComp__WEBP2) {
      _inherits(HeadFamilyComponent, _utils_BaseComp__WEBP2);

      function HeadFamilyComponent(route, renderer, http, aesEncryptionDecryptionService) {
        var _this3;

        _classCallCheck(this, HeadFamilyComponent);

        _this3 = _possibleConstructorReturn(this, _getPrototypeOf(HeadFamilyComponent).call(this));
        _this3.route = route;
        _this3.renderer = renderer;
        _this3.http = http;
        _this3.aesEncryptionDecryptionService = aesEncryptionDecryptionService;
        _this3.unselected_option_class = "form-group field-hypa_insurance1 field-variance_income1 field-manageFmlexpance1 field-spe_invest1 field-manage_household1 field-child_edu1 field-retirePlan1";
        _this3.selected_option_class = "form-group field-hypa_insurance2 field-variance_income2 field-manageFmlexpance2 field-spe_invest2 field-manage_household2 field-child_edu2 field-retirePlan2 backradio";
        _this3.spouse_class = "";
        _this3.spouseChil_class = "";
        _this3.spouseChildParent_class = "";
        _this3.q1_Spouse = "q1_Spouse";
        _this3.q1_SChildren = "q1_SChildren";
        _this3.q1_SCParents = "q1_SCParents";
        _this3.q1_selected_option = "";
        _this3.show_q1_error = false;
        _this3.q2_CurrentInsurance = "";
        _this3.Yes_class = "";
        _this3.No_class = "";
        _this3.q3_Yes = "q3_Yes";
        _this3.q3_No = "q3_No";
        _this3.q3_selected_option = "";
        _this3.show_q3_error = false;
        _this3.q4_AnnualIncome = "";
        _this3.Less_class = "";
        _this3.Between_class = "";
        _this3.More_class = "";
        _this3.q5_Less = "q5_Less";
        _this3.q5_between = "q5_between";
        _this3.q5_More = "q5_More";
        _this3.q5_selected_option = "";
        _this3.show_q5_error = false;
        _this3.Dip_class = "";
        _this3.Curtail_class = "";
        _this3.Borrow_class = "";
        _this3.q6_Dip = "q6_Dip";
        _this3.q6_Curtail = "q6_Curtail";
        _this3.q6_Borrow = "q6_Borrow";
        _this3.q6_selected_option = "";
        _this3.show_q6_error = false;
        _this3.Q7Yes_class = "";
        _this3.Q7No_class = "";
        _this3.q7_Yes = "q7_Yes";
        _this3.q7_No = "q7_No";
        _this3.q7_selected_option = "";
        _this3.show_q7_error = false;
        _this3.Insured_class = "";
        _this3.Extended_class = "";
        _this3.Lifestyle_class = "";
        _this3.Liquidate_class = "";
        _this3.q8_Insured = "q8_Insured";
        _this3.q8_Extended = "q8_Extended";
        _this3.q8_Lifestyle = "q8_Lifestyle";
        _this3.q8_Liquidate = "q8_Liquidate";
        _this3.q8_selected_option = "";
        _this3.show_q8_error = false;
        _this3.Q9Yes_class = "";
        _this3.Q9No_class = "";
        _this3.q9_Yes = "q9_Yes";
        _this3.q9_No = "q9_No";
        _this3.q9_selected_option = "";
        _this3.show_q9_error = false;
        _this3.Continue_class = "";
        _this3.Dependent_class = "";
        _this3.Rental_class = "";
        _this3.Yet_class = "";
        _this3.q10_Continue = "q10_Continue";
        _this3.q10_Dependent = "q10_Dependent";
        _this3.q10_Rental = "q10_Rental";
        _this3.q10_Yet = "q10_Yet";
        _this3.q10_selected_option = "";
        _this3.show_q10_error = false; // for session storage array

        _this3.session = [];
        return _this3;
      }

      _createClass(HeadFamilyComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.spouse_class = this.unselected_option_class;
          this.spouseChil_class = this.unselected_option_class;
          this.spouseChildParent_class = this.unselected_option_class;
          this.Yes_class = this.unselected_option_class;
          this.No_class = this.unselected_option_class;
          this.Less_class = this.unselected_option_class;
          this.Between_class = this.unselected_option_class;
          this.More_class = this.unselected_option_class;
          this.Dip_class = this.unselected_option_class;
          this.Curtail_class = this.unselected_option_class;
          this.Borrow_class = this.unselected_option_class;
          this.Q7Yes_class = this.unselected_option_class;
          this.Q7No_class = this.unselected_option_class;
          this.Insured_class = this.unselected_option_class;
          this.Extended_class = this.unselected_option_class;
          this.Lifestyle_class = this.unselected_option_class;
          this.Liquidate_class = this.unselected_option_class;
          this.Q9Yes_class = this.unselected_option_class;
          this.Q9No_class = this.unselected_option_class;
          this.Continue_class = this.unselected_option_class;
          this.Dependent_class = this.unselected_option_class;
          this.Rental_class = this.unselected_option_class;
          this.Yet_class = this.unselected_option_class; //console.log("register data:-" + this.getSessionStoredItem(this.REGISTER_DATA));

          if (this.getSessionStoredItem(this.REGISTER_DATA) == null || this.getSessionStoredItem(this.REGISTER_DATA) == '' || this.getSessionStoredItem(this.REGISTER_DATA) == 'null') {
            this.route.navigate(['/register']);
          } else if (this.getSessionStoredItem(this.OWNER_DATA) == null && this.getSessionStoredItem(this.OWNER_DATA) == '' && this.getSessionStoredItem(this.OWNER_DATA) == 'null') {
            this.route.navigate(['/owner']);
          } else if (this.getSessionStoredItem(this.SAVE_EMPLOYER) == null && this.getSessionStoredItem(this.SAVE_EMPLOYER) == '' && this.getSessionStoredItem(this.SAVE_EMPLOYER) == 'null') {
            this.route.navigate(['/employer']);
          } // ,Partnership Insurance
          //console.log('q1:-' + window.sessionStorage.getItem('p3_q1'));


          if (window.sessionStorage.getItem('p3_q1') != '') {
            switch (window.sessionStorage.getItem('p3_q1')) {
              case 'Spouse':
                this.selectedOptionsQ1(0);
                break;

              case 'Spouse & Children':
                this.selectedOptionsQ1(1);
                break;

              case 'Spouse, Children & Parents':
                this.selectedOptionsQ1(2);
                break;
            }
          }

          this.q2_CurrentInsurance = window.sessionStorage.getItem("p3_q2") == null ? "" : window.sessionStorage.getItem("p3_q2"); //console.log('q3:-' + window.sessionStorage.getItem('p3_q3'));

          if (window.sessionStorage.getItem('p3_q3') != '') {
            switch (window.sessionStorage.getItem('p3_q3')) {
              case 'Yes':
                this.selectedOptionsQ3(0);
                break;

              case 'No':
                this.selectedOptionsQ3(1);
                break;
            }
          }

          this.q4_AnnualIncome = window.sessionStorage.getItem("p3_q4") == null ? "" : window.sessionStorage.getItem("p3_q4"); //console.log('q5:-' + window.sessionStorage.getItem('p3_q5'));

          if (window.sessionStorage.getItem('p3_q5') != '') {
            switch (window.sessionStorage.getItem('p3_q5')) {
              case 'Less than 10%':
                this.selectedOptionsQ5(0);
                break;

              case 'Between 10-20%':
                this.selectedOptionsQ5(1);
                break;

              case 'More than 20%':
                this.selectedOptionsQ5(1);
                break;
            }
          } //console.log('q6:-' + window.sessionStorage.getItem('p3_q6'));


          if (window.sessionStorage.getItem('p3_q6') != '') {
            switch (window.sessionStorage.getItem('p3_q6')) {
              case 'Dip into family savings':
                this.selectedOptionsQ6(0);
                break;

              case 'Curtail discretionary expenditure':
                this.selectedOptionsQ6(1);
                break;

              case 'Borrow money':
                this.selectedOptionsQ6(1);
                break;
            }
          } //console.log('q7:-' + window.sessionStorage.getItem('p3_q7'));


          if (window.sessionStorage.getItem('p3_q7') != '') {
            switch (window.sessionStorage.getItem('p3_q7')) {
              case 'Yes':
                this.selectedOptionsQ7(0);
                break;

              case 'No':
                this.selectedOptionsQ7(1);
                break;
            }
          } //console.log('q8:-' + window.sessionStorage.getItem('p3_q8'));


          if (window.sessionStorage.getItem('p3_q8') != '') {
            switch (window.sessionStorage.getItem('p3_q8')) {
              case 'I am adequately insured':
                this.selectedOptionsQ8(0);
                break;

              case 'My extended family will take care of them':
                this.selectedOptionsQ8(1);
                break;

              case 'My family will have to make significant lifestyle changes':
                this.selectedOptionsQ8(1);
                break;
            }
          } //console.log('q9:-' + window.sessionStorage.getItem('p3_q9'));


          if (window.sessionStorage.getItem('p3_q9') != '') {
            switch (window.sessionStorage.getItem('p3_q9')) {
              case 'Yes':
                this.selectedOptionsQ9(0);
                break;

              case 'No':
                this.selectedOptionsQ9(1);
                break;
            }
          } //console.log('q10:-' + window.sessionStorage.getItem('p3_q10'));


          if (window.sessionStorage.getItem('p3_q10') != '') {
            switch (window.sessionStorage.getItem('p3_q10')) {
              case 'I will continue to work':
                this.selectedOptionsQ10(0);
                break;

              case 'I will be dependant on my child/children':
                this.selectedOptionsQ10(1);
                break;

              case 'I will get rental income from my property':
                this.selectedOptionsQ10(2);
                break;

              case 'I am yet to start planning':
                this.selectedOptionsQ10(3);
                break;
            }
          }
        }
      }, {
        key: "selectedOptionsQ1",
        value: function selectedOptionsQ1(index) {
          switch (index) {
            case 0:
              this.spouse_class = this.selected_option_class;
              this.spouseChil_class = this.unselected_option_class;
              this.spouseChildParent_class = this.unselected_option_class;
              this.q1_selected_option = this.q1_Spouse; // for error remove

              this.show_q1_error = false;
              break;

            case 1:
              this.spouse_class = this.unselected_option_class;
              this.spouseChil_class = this.selected_option_class;
              this.spouseChildParent_class = this.unselected_option_class;
              this.q1_selected_option = this.q1_SChildren; // for error remove

              this.show_q1_error = false;
              break;

            case 2:
              this.spouse_class = this.unselected_option_class;
              this.spouseChil_class = this.unselected_option_class;
              this.spouseChildParent_class = this.selected_option_class;
              this.q1_selected_option = this.q1_SCParents; // for error remove

              this.show_q1_error = false;
              break;
          }
        }
      }, {
        key: "selectedOptionsQ3",
        value: function selectedOptionsQ3(index) {
          switch (index) {
            case 0:
              this.Yes_class = this.selected_option_class;
              this.No_class = this.unselected_option_class;
              this.q3_selected_option = this.q3_Yes; // for error remove

              this.show_q3_error = false;
              break;

            case 1:
              this.Yes_class = this.unselected_option_class;
              this.No_class = this.selected_option_class;
              this.q3_selected_option = this.q3_No; // for error remove

              this.show_q3_error = false;
              break;
          }
        }
      }, {
        key: "selectedOptionsQ5",
        value: function selectedOptionsQ5(index) {
          switch (index) {
            case 0:
              this.Less_class = this.selected_option_class;
              this.Between_class = this.unselected_option_class;
              this.More_class = this.unselected_option_class;
              this.q5_selected_option = this.q5_Less; // for error remove

              this.show_q5_error = false;
              break;

            case 1:
              this.Less_class = this.unselected_option_class;
              this.Between_class = this.selected_option_class;
              this.More_class = this.unselected_option_class;
              this.q5_selected_option = this.q5_between; // for error remove

              this.show_q5_error = false;
              break;

            case 2:
              this.Less_class = this.unselected_option_class;
              this.Between_class = this.unselected_option_class;
              this.More_class = this.selected_option_class;
              this.q5_selected_option = this.q5_More; // for error remove

              this.show_q5_error = false;
              break;
          }
        }
      }, {
        key: "selectedOptionsQ6",
        value: function selectedOptionsQ6(index) {
          switch (index) {
            case 0:
              this.Dip_class = this.selected_option_class;
              this.Curtail_class = this.unselected_option_class;
              this.Borrow_class = this.unselected_option_class;
              this.q6_selected_option = this.q6_Dip; // for error remove

              this.show_q6_error = false;
              break;

            case 1:
              this.Dip_class = this.unselected_option_class;
              this.Curtail_class = this.selected_option_class;
              this.Borrow_class = this.unselected_option_class;
              this.q6_selected_option = this.q6_Curtail; // for error remove

              this.show_q6_error = false;
              break;

            case 2:
              this.Dip_class = this.unselected_option_class;
              this.Curtail_class = this.unselected_option_class;
              this.Borrow_class = this.selected_option_class;
              this.q6_selected_option = this.q6_Borrow; // for error remove

              this.show_q6_error = false;
              break;
          }
        }
      }, {
        key: "selectedOptionsQ7",
        value: function selectedOptionsQ7(index) {
          switch (index) {
            case 0:
              this.Q7Yes_class = this.selected_option_class;
              this.Q7No_class = this.unselected_option_class;
              this.q7_selected_option = this.q7_Yes; // for error remove

              this.show_q7_error = false;
              break;

            case 1:
              this.Q7Yes_class = this.unselected_option_class;
              this.Q7No_class = this.selected_option_class;
              this.q7_selected_option = this.q7_No; // for error remove

              this.show_q7_error = false;
              break;
          }
        }
      }, {
        key: "selectedOptionsQ8",
        value: function selectedOptionsQ8(index) {
          switch (index) {
            case 0:
              this.Insured_class = this.selected_option_class;
              this.Extended_class = this.unselected_option_class;
              this.Lifestyle_class = this.unselected_option_class;
              this.Liquidate_class = this.unselected_option_class;
              this.q8_selected_option = this.q8_Insured; // for error remove

              this.show_q8_error = false;
              break;

            case 1:
              this.Insured_class = this.unselected_option_class;
              this.Extended_class = this.selected_option_class;
              this.Lifestyle_class = this.unselected_option_class;
              this.Liquidate_class = this.unselected_option_class;
              this.q8_selected_option = this.q8_Extended; // for error remove

              this.show_q8_error = false;
              break;

            case 2:
              this.Insured_class = this.unselected_option_class;
              this.Extended_class = this.unselected_option_class;
              this.Lifestyle_class = this.selected_option_class;
              this.Liquidate_class = this.unselected_option_class;
              this.q8_selected_option = this.q8_Lifestyle; // for error remove

              this.show_q8_error = false;
              break;

            case 3:
              this.Insured_class = this.unselected_option_class;
              this.Extended_class = this.unselected_option_class;
              this.Lifestyle_class = this.unselected_option_class;
              this.Liquidate_class = this.selected_option_class;
              this.q8_selected_option = this.q8_Liquidate; // for error remove

              this.show_q8_error = false;
              break;
          }
        }
      }, {
        key: "selectedOptionsQ9",
        value: function selectedOptionsQ9(index) {
          switch (index) {
            case 0:
              this.Q9Yes_class = this.selected_option_class;
              this.Q9No_class = this.unselected_option_class;
              this.q9_selected_option = this.q9_Yes; // for error remove

              this.show_q9_error = false;
              break;

            case 1:
              this.Q9Yes_class = this.unselected_option_class;
              this.Q9No_class = this.selected_option_class;
              this.q9_selected_option = this.q9_No; // for error remove

              this.show_q9_error = false;
              break;
          }
        }
      }, {
        key: "selectedOptionsQ10",
        value: function selectedOptionsQ10(index) {
          switch (index) {
            case 0:
              this.Continue_class = this.selected_option_class;
              this.Dependent_class = this.unselected_option_class;
              this.Rental_class = this.unselected_option_class;
              this.Yet_class = this.unselected_option_class;
              this.q10_selected_option = this.q10_Continue; // for error remove

              this.show_q10_error = false;
              break;

            case 1:
              this.Continue_class = this.unselected_option_class;
              this.Dependent_class = this.selected_option_class;
              this.Rental_class = this.unselected_option_class;
              this.Yet_class = this.unselected_option_class;
              this.q10_selected_option = this.q10_Dependent; // for error remove

              this.show_q10_error = false;
              break;

            case 2:
              this.Continue_class = this.unselected_option_class;
              this.Dependent_class = this.unselected_option_class;
              this.Rental_class = this.selected_option_class;
              this.Yet_class = this.unselected_option_class;
              this.q10_selected_option = this.q10_Rental; // for error remove

              this.show_q10_error = false;
              break;

            case 3:
              this.Continue_class = this.unselected_option_class;
              this.Dependent_class = this.unselected_option_class;
              this.Rental_class = this.unselected_option_class;
              this.Yet_class = this.selected_option_class;
              this.q10_selected_option = this.q10_Yet; // for error remove

              this.show_q10_error = false;
              break;
          }
        }
      }, {
        key: "next",
        value: function next() {
          var _this4 = this;

          //console.log("Family Dependent:-" + this.q1_selected_option);
          //console.log("Current Life Insurance:-" + this.q2_CurrentInsurance);
          //console.log("purchased Plans:-" + this.q3_selected_option);
          //console.log("Annual Income:-" + this.q4_AnnualIncome);
          //console.log("Fluctuation in Income:-" + this.q5_selected_option);
          //console.log("Manage:-" + this.q6_selected_option);
          //console.log("Specific Investment:-" + this.q7_selected_option);
          //console.log("Unfortunate Events:-" + this.q8_selected_option);
          //console.log("Planning:-" + this.q9_selected_option);
          //console.log("Retirement:-" + this.q10_selected_option);
          // if(this.q1_selected_option=="" || this.q3_selected_option=="" || this.q5_selected_option=="" ||
          //     this.q6_selected_option=="" || this.q7_selected_option=="" || this.q8_selected_option=="" ||
          //     this.q9_selected_option=="" || this.q10_selected_option=="" || this.q10_selected_option==""){
          //   // alert("Please describe your immediate family/dependents.");
          //   this.show_q1_error=true;
          //   this.show_q3_error = true;
          //   this.show_q5_error = true;
          //   this.show_q6_error = true;
          //   this.show_q7_error = true;
          //   this.show_q8_error = true;
          //   this.show_q9_error = true;
          //   this.show_q10_error = true;
          //   return;
          // }
          if (this.q1_selected_option == "") {
            this.show_q1_error = true; // this.el.nativeElement.focus();
            // document.getElementById("focusContent").focus();
            // this.renderer.selectRootElement('#focusContent').focus();

            this.q1_error.nativeElement.focus(); // alert("asdjh");

            return;
          }

          if (this.q3_selected_option == "") {
            this.show_q3_error = true; // this.el.nativeElement.focus();
            // document.getElementById("focusContent1").focus();

            this.q3_error.nativeElement.focus();
            return;
          }

          if (this.q5_selected_option == "") {
            this.show_q5_error = true;
            this.q5_error.nativeElement.focus();
            return;
          }

          if (this.q6_selected_option == "") {
            this.show_q6_error = true;
            this.q6_error.nativeElement.focus();
            return;
          }

          if (this.q7_selected_option == "") {
            this.show_q7_error = true;
            this.q7_error.nativeElement.focus();
            return;
          }

          if (this.q8_selected_option == "") {
            this.show_q8_error = true;
            this.q8_error.nativeElement.focus();
            return;
          }

          if (this.q9_selected_option == "") {
            this.show_q9_error = true;
            this.q9_error.nativeElement.focus();
            return;
          }

          if (this.q10_selected_option == "") {
            this.show_q10_error = true;
            this.q10_error.nativeElement.focus();
            return; // alert("all good please go ahead");
          }

          var q1 = "";
          var q2 = "";
          var q3 = "";
          var q4 = "";
          var q5 = "";
          var q6 = "";
          var q7 = "";
          var q8 = "";
          var q9 = "";
          var q10 = "";

          if (this.q1_selected_option == this.q1_Spouse) {
            q1 = "Spouse";
          } else if (this.q1_selected_option == this.q1_SChildren) {
            q1 = "Spouse & Children";
          } else if (this.q1_selected_option == this.q1_SCParents) {
            q1 = "Spouse, Children & Parents";
          }

          q2 = this.q2_CurrentInsurance;

          if (this.q3_selected_option == this.q3_Yes) {
            q3 = "Yes";
          } else if (this.q3_selected_option == this.q3_No) {
            q3 = "No";
          }

          q4 = this.q4_AnnualIncome;

          if (this.q5_selected_option == this.q5_Less) {
            q5 = "Less than 10%";
          } else if (this.q5_selected_option == this.q5_between) {
            q5 = "Between 10-20%";
          } else if (this.q5_selected_option == this.q5_More) {
            q5 = "More than 20%";
          }

          if (this.q6_selected_option == this.q6_Dip) {
            q6 = "Dip into family savings";
          } else if (this.q6_selected_option == this.q6_Curtail) {
            q6 = "Curtail discretionary expenditure";
          } else if (this.q6_selected_option == this.q6_Borrow) {
            q6 = "Borrow money";
          }

          if (this.q7_selected_option == this.q7_Yes) {
            q7 = "Yes";
          } else if (this.q7_selected_option == this.q7_No) {
            q7 = "No";
          }

          if (this.q8_selected_option == this.q8_Insured) {
            q8 = "I am adequately insured";
          } else if (this.q8_selected_option == this.q8_Extended) {
            q8 = "My extended family will take care of them";
          } else if (this.q8_selected_option == this.q8_Lifestyle) {
            q8 = "My family will have to make significant lifestyle changes";
          } else if (this.q8_selected_option == this.q8_Liquidate) {
            q8 = "My family will have to liquidate fixed assets";
          }

          if (this.q9_selected_option == this.q9_Yes) {
            q9 = "Yes";
          } else if (this.q9_selected_option == this.q9_No) {
            q9 = "No";
          }

          if (this.q10_selected_option == this.q10_Continue) {
            q10 = "I will continue to work";
          } else if (this.q10_selected_option == this.q10_Dependent) {
            q10 = "I will be dependant on my child/children";
          } else if (this.q10_selected_option == this.q10_Rental) {
            q10 = "I will get rental income from my property";
          } else if (this.q10_selected_option == this.q10_Yet) {
            q10 = "I am yet to start planning";
          }

          window.sessionStorage.setItem("p3_q1", q1);
          window.sessionStorage.setItem("p3_q2", q2);
          window.sessionStorage.setItem("p3_q3", q3);
          window.sessionStorage.setItem("p3_q4", q4);
          window.sessionStorage.setItem("p3_q5", q5);
          window.sessionStorage.setItem("p3_q6", q6);
          window.sessionStorage.setItem("p3_q7", q7);
          window.sessionStorage.setItem("p3_q8", q8);
          window.sessionStorage.setItem("p3_q9", q9);
          window.sessionStorage.setItem("p3_q10", q10); // let formData=new FormData();
          // formData.append("user_id",this.getUser().user_id);
          // formData.append("q1",q1);
          // formData.append("q2",q2);
          // formData.append("q3",q3);
          // formData.append("q4",q4);
          // formData.append("q5",q5);
          // formData.append("q6",q6);
          // formData.append("q7",q7);
          // formData.append("q8",q8);
          // formData.append("q9",q9);
          // formData.append("q10",q10);

          var postData = {
            user_id: this.getUser().user_id,
            q1: q1,
            q2: q2,
            q3: q3,
            q4: q4,
            q5: q5,
            q6: q6,
            q7: q7,
            q8: q8,
            q9: q9,
            q10: q10
          };
          var formData = {
            request: this.aesEncryptionDecryptionService.encryptRequest(JSON.stringify(postData))
          };
          this.http.post(this.getSessionStoredItem(this.BASE_URL) + this.SAVE_HOF_URL, JSON.stringify(formData), {
            responseType: 'text'
          }).subscribe(function (data) {
            try {
              //console.log('data received:-' + data);
              var parsedData = JSON.parse(data);

              var parsedJSON = _this4.aesEncryptionDecryptionService.parseEncryptedResponse(parsedData.response);

              if (parsedJSON.status) {
                _this4.setSessionStoredItem(_this4.SAVE_HOF, JSON.stringify(parsedJSON.data));

                _this4.route.navigate(['/report']);
              } else {
                alert(parsedJSON.message);
              }
            } catch (e) {//console.log(e);
            }
          }); // //console.log("Family_Dependent:-"+window.sessionStorage.getItem("Family_Dependent"));
          // alert("all good please go ahead");
          // this.route.navigate(['/report']);
        }
      }]);

      return HeadFamilyComponent;
    }(_utils_BaseComp__WEBPACK_IMPORTED_MODULE_3__["BaseComp"]);

    HeadFamilyComponent.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
      }, {
        type: _aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_5__["AESEncryptionDecryptionService"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("q1_error", {
      static: false
    })], HeadFamilyComponent.prototype, "q1_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("q3_error", {
      static: false
    })], HeadFamilyComponent.prototype, "q3_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("q5_error", {
      static: false
    })], HeadFamilyComponent.prototype, "q5_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("q6_error", {
      static: false
    })], HeadFamilyComponent.prototype, "q6_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("q7_error", {
      static: false
    })], HeadFamilyComponent.prototype, "q7_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("q8_error", {
      static: false
    })], HeadFamilyComponent.prototype, "q8_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("q9_error", {
      static: false
    })], HeadFamilyComponent.prototype, "q9_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("q10_error", {
      static: false
    })], HeadFamilyComponent.prototype, "q10_error", void 0);
    HeadFamilyComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-head-family',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./head-family.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/head-family/head-family.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./head-family.component.css */
      "./src/app/head-family/head-family.component.css")).default]
    })], HeadFamilyComponent);
    /***/
  },

  /***/
  "./src/app/material.ts":
  /*!*****************************!*\
    !*** ./src/app/material.ts ***!
    \*****************************/

  /*! exports provided: MaterialModule */

  /***/
  function srcAppMaterialTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MaterialModule", function () {
      return MaterialModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/material/tabs */
    "./node_modules/@angular/material/esm2015/tabs.js");
    /* harmony import */


    var _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/material/bottom-sheet */
    "./node_modules/@angular/material/esm2015/bottom-sheet.js");
    /* harmony import */


    var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/material/checkbox */
    "./node_modules/@angular/material/esm2015/checkbox.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_sort__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/material/sort */
    "./node_modules/@angular/material/esm2015/sort.js");
    /* harmony import */


    var _angular_material_table__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/material/table */
    "./node_modules/@angular/material/esm2015/table.js");
    /* harmony import */


    var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/material/form-field */
    "./node_modules/@angular/material/esm2015/form-field.js");
    /* harmony import */


    var _angular_material_icon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/material/icon */
    "./node_modules/@angular/material/esm2015/icon.js");
    /* harmony import */


    var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @angular/material/datepicker */
    "./node_modules/@angular/material/esm2015/datepicker.js");
    /* harmony import */


    var _angular_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @angular/material */
    "./node_modules/@angular/material/esm2015/material.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! @angular/material/sidenav */
    "./node_modules/@angular/material/esm2015/sidenav.js");
    /* harmony import */


    var _angular_material_select__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! @angular/material/select */
    "./node_modules/@angular/material/esm2015/select.js");

    var MaterialModule = function MaterialModule() {
      _classCallCheck(this, MaterialModule);
    };

    MaterialModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_material_tabs__WEBPACK_IMPORTED_MODULE_2__["MatTabsModule"], _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_3__["MatBottomSheetModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_4__["MatCheckboxModule"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_5__["MatPaginatorModule"], _angular_material_sort__WEBPACK_IMPORTED_MODULE_6__["MatSortModule"], _angular_material_table__WEBPACK_IMPORTED_MODULE_7__["MatTableModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__["MatFormFieldModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_9__["MatIconModule"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_10__["MatDatepickerModule"], _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatNativeDateModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_12__["MatDialogModule"], _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatInputModule"], _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatCardModule"], _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatButtonModule"], _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_13__["MatSidenavModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_14__["MatSelectModule"]],
      exports: [_angular_material_tabs__WEBPACK_IMPORTED_MODULE_2__["MatTabsModule"], _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_3__["MatBottomSheetModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_4__["MatCheckboxModule"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_5__["MatPaginatorModule"], _angular_material_sort__WEBPACK_IMPORTED_MODULE_6__["MatSortModule"], _angular_material_table__WEBPACK_IMPORTED_MODULE_7__["MatTableModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__["MatFormFieldModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_9__["MatIconModule"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_10__["MatDatepickerModule"], _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatNativeDateModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_12__["MatDialogModule"], _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatInputModule"], _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatCardModule"], _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatButtonModule"], _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_13__["MatSidenavModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_14__["MatSelectModule"]]
    })], MaterialModule);
    /***/
  },

  /***/
  "./src/app/navbar/navbar.component.css":
  /*!*********************************************!*\
    !*** ./src/app/navbar/navbar.component.css ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppNavbarNavbarComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL25hdmJhci9uYXZiYXIuY29tcG9uZW50LmNzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/navbar/navbar.component.ts":
  /*!********************************************!*\
    !*** ./src/app/navbar/navbar.component.ts ***!
    \********************************************/

  /*! exports provided: NavbarComponent */

  /***/
  function srcAppNavbarNavbarComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NavbarComponent", function () {
      return NavbarComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var NavbarComponent =
    /*#__PURE__*/
    function () {
      function NavbarComponent() {
        _classCallCheck(this, NavbarComponent);
      }

      _createClass(NavbarComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return NavbarComponent;
    }();

    NavbarComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-navbar',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./navbar.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/navbar/navbar.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./navbar.component.css */
      "./src/app/navbar/navbar.component.css")).default]
    })], NavbarComponent);
    /***/
  },

  /***/
  "./src/app/owner/owner.component.css":
  /*!*******************************************!*\
    !*** ./src/app/owner/owner.component.css ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppOwnerOwnerComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL293bmVyL293bmVyLmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/owner/owner.component.ts":
  /*!******************************************!*\
    !*** ./src/app/owner/owner.component.ts ***!
    \******************************************/

  /*! exports provided: OwnerComponent */

  /***/
  function srcAppOwnerOwnerComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OwnerComponent", function () {
      return OwnerComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _utils_BaseComp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../utils/BaseComp */
    "./src/app/utils/BaseComp.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../aesencryption-decryption.service */
    "./src/app/aesencryption-decryption.service.ts");

    var OwnerComponent =
    /*#__PURE__*/
    function (_utils_BaseComp__WEBP3) {
      _inherits(OwnerComponent, _utils_BaseComp__WEBP3);

      function OwnerComponent(route, http, aesEncryptionDecryptionService) {
        var _this5;

        _classCallCheck(this, OwnerComponent);

        _this5 = _possibleConstructorReturn(this, _getPrototypeOf(OwnerComponent).call(this));
        _this5.route = route;
        _this5.http = http;
        _this5.aesEncryptionDecryptionService = aesEncryptionDecryptionService;
        _this5.showLacs = false;
        _this5.showQ1a = false;
        _this5.showQ5a = false;
        _this5.partners = [{
          share: ''
        }];
        _this5.unselected_option_class = 'form-group field-edit-rating2 field-pbe1 field-check_wc';
        _this5.selected_option_class = 'form-group field-edit-rating1  field-pbe2 field-check_be backradio';
        _this5.Proprietor_class = '';
        _this5.Partnership_class = '';
        _this5.PVTLTD_class = '';
        _this5.Yes_class = '';
        _this5.No_class = '';
        _this5.Have_class = '';
        _this5.q1_propertier = 'q1_propertier';
        _this5.q1_partnership = 'q1_partnership';
        _this5.q1_pvt_ltd = 'q1_pvt_ltd';
        _this5.q1_selected_option = '';
        _this5.q1a_selected_option = '';
        _this5.q1a2_selected_option = '';
        _this5.q2_annual_turn_overCR = '';
        _this5.q3_total_value_assetCR = '';
        _this5.q2_annual_turn_overLACS = '';
        _this5.q3_total_value_assetLACS = '';
        _this5.q4_Yes_Selected = 'q4_Yes_Selected';
        _this5.q4_No_Selected = 'q4_No_Selected';
        _this5.q4_Have_Selected = 'q4_Have_Selected';
        _this5.q4_selected_option = '';
        _this5.Working_class = '';
        _this5.Business_class = '';
        _this5.Q5No_class = '';
        _this5.q5_working = 'q5_working';
        _this5.q5_Business = 'q5_Business';
        _this5.q5_No = 'q5_No';
        _this5.q5_selected_option = '';
        _this5.q5a_selected_option = ''; // for show errors

        _this5.show_q1_error = false;
        _this5.show_q1a_error = false;
        _this5.show_q1a2_error = false;
        _this5.show_q2CR_error = false;
        _this5.show_q3CR_error = false;
        _this5.show_q2LACS_error = false;
        _this5.show_q3LACS_error = false;
        _this5.show_q4_error = false;
        _this5.show_q5_error = false;
        _this5.show_q5a_error = false;
        return _this5;
      }

      _createClass(OwnerComponent, [{
        key: "removePartner",
        value: function removePartner(i) {
          this.partners.splice(i, 1);
        }
      }, {
        key: "addPartner",
        value: function addPartner() {
          // //console.log("partner length:-"+this.partners.length);
          if (this.partners.length != 3) {
            this.partners.push({
              share: ''
            });
          }
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          // window.sessionStorage.setItem('q1a', this.q1a_selected_option);
          // window.sessionStorage.setItem('q1a2', this.q1a2_selected_option);
          this.Proprietor_class = this.unselected_option_class;
          this.Partnership_class = this.unselected_option_class;
          this.PVTLTD_class = this.unselected_option_class;
          this.Yes_class = this.unselected_option_class;
          this.No_class = this.unselected_option_class;
          this.Have_class = this.unselected_option_class;
          this.Working_class = this.unselected_option_class;
          this.Business_class = this.unselected_option_class;
          this.Q5No_class = this.unselected_option_class; //console.log('register data:-' + this.getSessionStoredItem(this.REGISTER_DATA));

          if (this.getSessionStoredItem(this.REGISTER_DATA) != null && this.getSessionStoredItem(this.REGISTER_DATA) != '' && this.getSessionStoredItem(this.REGISTER_DATA) != 'null') {//console.log('in if');
          } else {
            this.route.navigate(['/register']);
          }

          this.q1_selected_option = window.sessionStorage.getItem('p2_q1') == null ? '' : window.sessionStorage.getItem('p2_q1');
          this.q2_annual_turn_overCR = window.sessionStorage.getItem('p2_q2CR') == null ? '' : window.sessionStorage.getItem('p2_q2CR');
          this.q3_total_value_assetCR = window.sessionStorage.getItem('p2_q3CR') == null ? '' : window.sessionStorage.getItem('p2_q3CR'); // this.q1a_selected_option = window.sessionStorage.getItem('q1a') == null ? '' : window.sessionStorage.getItem('q1a');
          // this.q1a2_selected_option = window.sessionStorage.getItem('q1a2') == null ? '' : window.sessionStorage.getItem('q1a2');

          this.q2_annual_turn_overLACS = window.sessionStorage.getItem('p2_q2LACS') == null ? '' : window.sessionStorage.getItem('p2_q2LACS');
          this.q3_total_value_assetLACS = window.sessionStorage.getItem('p2_q3LACS') == null ? '' : window.sessionStorage.getItem('p2_q3LACS');
          this.q4_selected_option = window.sessionStorage.getItem('p2_q4') == null ? '' : window.sessionStorage.getItem('p2_q4');
          this.q5a_selected_option = window.sessionStorage.getItem('p2_q5a') == null ? '' : window.sessionStorage.getItem('p2_q5a');
          this.q2_annual_turn_overLACS = window.sessionStorage.getItem('p2_q2LACS') == null ? '' : window.sessionStorage.getItem('p2_q2LACS');
          this.q3_total_value_assetLACS = window.sessionStorage.getItem('p2_q3LACS') == null ? '' : window.sessionStorage.getItem('p2_q2LACS');
          this.q2_annual_turn_overCR = window.sessionStorage.getItem('p2_q2CR') == null ? '' : window.sessionStorage.getItem('p2_q2CR');
          this.q3_total_value_assetCR = window.sessionStorage.getItem('p2_q3CR') == null ? '' : window.sessionStorage.getItem('p2_q3CR');
          this.partners = [];
          var q1a = window.sessionStorage.getItem('p2_q1a'); //console.log('p2_q1a:-' + q1a);

          if (q1a != null && q1a != undefined && q1a.includes(',')) {
            var q1asplit = q1a.split(',');

            if (q1asplit.length > 2) {
              this.q1a_selected_option = q1asplit[0];
              this.q1a2_selected_option = q1asplit[1];

              for (var i = 2; i < q1asplit.length; i++) {
                this.partners.push({
                  share: q1asplit[i]
                });
              }
            } else {
              this.q1a_selected_option = q1asplit[0];
              this.q1a2_selected_option = q1asplit[1];
            }
          }

          var p2_q5 = window.sessionStorage.getItem('p2_q5'); //console.log("p2_q5:-" + p2_q5);

          if (p2_q5 == "No") {
            this.selectedOptionsQ5(2);
          } else {
            if (p2_q5 != null && p2_q5 != undefined && p2_q5.includes("Working Capital")) {
              this.selectedOptionsQ5(1);
            }

            if (p2_q5 != null && p2_q5 != undefined && p2_q5.includes("Business Expansion")) {
              this.selectedOptionsQ5(0);
            }
          } //console.log('q1:-' + window.sessionStorage.getItem('p2_q1'));


          if (window.sessionStorage.getItem('p2_q1') != '') {
            switch (window.sessionStorage.getItem('p2_q1')) {
              case this.q1_propertier:
                this.selectOptionCS(0);
                break;

              case this.q1_partnership:
                this.selectOptionCS(1);
                break;

              case this.q1_pvt_ltd:
                this.selectOptionCS(2);
                break;
            }
          } //console.log('q4:-' + window.sessionStorage.getItem('p2_q4'));


          if (window.sessionStorage.getItem('p2_q4') != '') {
            switch (window.sessionStorage.getItem('p2_q4')) {
              case this.q4_Yes_Selected:
                this.selectOptionQ4(0);
                break;

              case this.q4_No_Selected:
                this.selectOptionQ4(1);
                break;

              case this.q4_Have_Selected:
                this.selectOptionQ4(2);
                break;
            }
          } //console.log('q5:-' + window.sessionStorage.getItem('p2_q5'));


          if (window.sessionStorage.getItem('p2_q5') != '') {
            switch (window.sessionStorage.getItem('p2_q5')) {
              case this.q5_working:
                this.selectedOptionsQ5(0);
                break;

              case this.q5_Business:
                this.selectedOptionsQ5(1);
                break;

              case this.q5_No:
                this.selectedOptionsQ5(2);
                break;
            }
          }
        }
      }, {
        key: "selectOptionCS",
        value: function selectOptionCS(index) {
          switch (index) {
            case 0:
              this.Proprietor_class = this.selected_option_class;
              this.Partnership_class = this.unselected_option_class;
              this.PVTLTD_class = this.unselected_option_class;
              this.showLacs = true;
              this.showQ1a = false;
              this.q1_selected_option = this.q1_propertier; // for error

              this.show_q1_error = false; //console.log('1st choosed');

              break;

            case 1:
              this.Proprietor_class = this.unselected_option_class;
              this.Partnership_class = this.selected_option_class;
              this.PVTLTD_class = this.unselected_option_class;
              this.showLacs = false;
              this.showQ1a = true;
              this.q1_selected_option = this.q1_partnership; // for error

              this.show_q1_error = false; //console.log('2st choosed');

              break;

            case 2:
              this.Proprietor_class = this.unselected_option_class;
              this.Partnership_class = this.unselected_option_class;
              this.PVTLTD_class = this.selected_option_class;
              this.showLacs = false;
              this.showQ1a = false;
              this.q1_selected_option = this.q1_pvt_ltd; // for error

              this.show_q1_error = false; //console.log('3st choosed');

              break;
          }
        }
      }, {
        key: "selectOptionQ4",
        value: function selectOptionQ4(index) {
          switch (index) {
            case 0:
              this.Yes_class = this.selected_option_class;
              this.No_class = this.unselected_option_class;
              this.Have_class = this.unselected_option_class;
              this.q4_selected_option = this.q4_Yes_Selected; // for error

              this.show_q4_error = false;
              break;

            case 1:
              this.Yes_class = this.unselected_option_class;
              this.No_class = this.selected_option_class;
              this.Have_class = this.unselected_option_class;
              this.q4_selected_option = this.q4_No_Selected; // for error

              this.show_q4_error = false;
              break;

            case 2:
              this.Yes_class = this.unselected_option_class;
              this.No_class = this.unselected_option_class;
              this.Have_class = this.selected_option_class;
              ;
              this.q4_selected_option = this.q4_Have_Selected; // for error

              this.show_q4_error = false;
              break;
          }
        }
      }, {
        key: "selectedOptionsQ5",
        value: function selectedOptionsQ5(index) {
          switch (index) {
            case 0:
              if (this.Working_class != this.selected_option_class) {
                this.Working_class = this.selected_option_class;
                this.Q5No_class = this.unselected_option_class;
              } else {
                this.Working_class = this.unselected_option_class;
              }

              if (this.Working_class == this.selected_option_class || this.Business_class == this.selected_option_class) {
                this.showQ5a = true;
              } else {
                this.showQ5a = false;
              }

              this.q5_selected_option = this.q5_working;
              this.show_q5_error = false;
              break;

            case 1:
              if (this.Business_class != this.selected_option_class) {
                this.Business_class = this.selected_option_class;
                this.Q5No_class = this.unselected_option_class;
              } else {
                this.Business_class = this.unselected_option_class;
              }

              if (this.Working_class == this.selected_option_class || this.Business_class == this.selected_option_class) {
                this.showQ5a = true;
              } else {
                this.showQ5a = false;
              }

              this.q5_selected_option = this.q5_Business;
              this.show_q5_error = false;
              break;

            case 2:
              this.Working_class = this.unselected_option_class;
              this.Business_class = this.unselected_option_class;
              this.Q5No_class = this.selected_option_class;
              this.showQ5a = false;
              this.q5_selected_option = this.q5_No;
              break;
          }
        }
      }, {
        key: "next",
        value: function next() {
          var _this6 = this;

          var shares = [];

          if (this.q1_selected_option == '') {
            this.show_q1_error = true;
            this.q1_error.nativeElement.focus();
            return;
          }

          if (this.q1_selected_option == this.q1_propertier) {
            if (this.q2_annual_turn_overLACS == '') {
              this.show_q2LACS_error = true; // alert("please fill q2 lacs")

              this.q2LACS_error.nativeElement.focus();
              return;
            } else {
              this.show_q2LACS_error = false;
            }
          }

          if (this.q1_selected_option == this.q1_propertier) {
            if (this.q3_total_value_assetLACS == '') {
              this.show_q3LACS_error = true;
              this.q3LACS_error.nativeElement.focus();
              return;
            } else {
              this.show_q3LACS_error = false;
            }
          }

          if (this.q1_selected_option == this.q1_pvt_ltd) {
            if (this.q2_annual_turn_overCR == '') {
              this.show_q2CR_error = true;
              this.q2CR_error.nativeElement.focus();
              return;
            } else {
              this.show_q2CR_error = false;
            }
          }

          if (this.q1_selected_option == this.q1_pvt_ltd) {
            if (this.q3_total_value_assetCR == '') {
              this.show_q3CR_error = true;
              this.q3CR_error.nativeElement.focus();
              return;
            } else {
              this.show_q3CR_error = false;
            }
          }

          if (this.q1_selected_option == this.q1_partnership) {
            if (this.q1a_selected_option == '') {
              this.show_q1a_error = true;
              this.q1a_error.nativeElement.focus();
              return;
            } else {
              this.show_q1a_error = false;
            }
          }

          if (this.q1_selected_option == this.q1_partnership) {
            if (this.q1a2_selected_option == '') {
              this.show_q1a2_error = true;
              this.q1a_error.nativeElement.focus();
              return;
            } else {
              this.show_q1a2_error = false;
            }
          }

          if (this.q1_selected_option == this.q1_partnership) {
            // //console.log("q1a1:-"+ this.q1a_selected_option);
            if (this.q1a_selected_option != '') {
              shares.push(this.q1a_selected_option);
              this.show_q1a_error = false;
            } else {
              this.show_q1a_error = true;
              this.q1a_error.nativeElement.focus();
              return;
            }

            if (this.q1a2_selected_option != '') {
              shares.push(this.q1a2_selected_option);
              this.show_q1a_error = false;
            } else {
              this.show_q1a_error = true;
              this.q1a_error.nativeElement.focus();
              return;
            }

            for (var i = 0; i < this.partners.length; i++) {
              if (this.partners[i].share != '') {
                shares.push(this.partners[i].share);
                this.show_q1a_error = false;
              } else {
                this.show_q1a_error = true;
                this.q1a_error.nativeElement.focus();
                return;
              }
            }

            var count = 0;

            for (var _i = 0; _i < shares.length; _i++) {
              count += Number(shares[_i]);
            } //console.log('count:-' + count);


            if (count != 100) {
              this.show_q1a_error = true;
              this.q1a_error.nativeElement.focus();
              return;
            } else {
              this.show_q1a_error = false;
            }
          }

          if (this.q1_selected_option == this.q1_partnership) {
            if (this.q2_annual_turn_overCR == '') {
              this.show_q2CR_error = true;
              this.q2CR_error.nativeElement.focus();
              return;
            } else {
              this.show_q2CR_error = false;
            }
          }

          if (this.q1_selected_option == this.q1_partnership) {
            if (this.q3_total_value_assetCR == '') {
              this.show_q3CR_error = true;
              this.q3CR_error.nativeElement.focus();
              return;
            } else {
              this.show_q3CR_error = false;
            }
          }

          if (this.q4_selected_option == '') {
            this.show_q4_error = true;
            this.q4_error.nativeElement.focus();
            return;
          }

          if (this.q5_selected_option == '') {
            this.show_q5_error = true;
            this.q5_error.nativeElement.focus();
            return;
          }

          if (this.q5_selected_option == this.q5_working) {
            if (this.q5a_selected_option == '') {
              this.show_q5a_error = true;
              this.q5a_error.nativeElement.focus();
              return;
            } else {
              this.show_q5a_error = false;
            }
          }

          if (this.q5_selected_option == this.q5_Business) {
            if (this.q5a_selected_option == '') {
              this.show_q5a_error = true;
              this.q5a_error.nativeElement.focus();
              return;
            } else {
              this.show_q5a_error = false;
            }
          }

          var q1 = '';
          var q1a = '';
          var q2 = '';
          var q3 = '';
          var q4 = '';
          var q5 = '';
          var q5a = '';

          if (this.q1_selected_option == this.q1_propertier) {
            // //console.log("q2:-"+ this.q2_annual_turn_overLACS);
            // //console.log("q3:-"+ this.q3_total_value_assetLACS);
            q1 = 'Proprietor';
            q2 = this.q2_annual_turn_overLACS;
            q3 = this.q3_total_value_assetLACS;
          }

          if (this.q1_selected_option == this.q1_partnership) {
            var shares_string = '';

            for (var _i2 = 0; _i2 < shares.length; _i2++) {
              if (_i2 == shares.length - 1) {
                shares_string += shares[_i2];
              } else {
                shares_string += shares[_i2] + ',';
              }
            } // //console.log("q1a:-"+ shares_string);
            // //console.log("q2:-"+ this.q2_annual_turn_overCR);
            // //console.log("q3:-"+ this.q3_total_value_assetCR);


            q1 = 'Partnership';
            q1a = shares_string;
            q2 = this.q2_annual_turn_overCR;
            q3 = this.q3_total_value_assetCR;
          }

          if (this.q1_selected_option == this.q1_pvt_ltd) {
            // //console.log("q2:-"+ this.q2_annual_turn_overCR);
            // //console.log("q3:-"+ this.q3_total_value_assetCR);
            q1 = 'Pvt Ltd. Company';
            q2 = this.q2_annual_turn_overCR;
            q3 = this.q3_total_value_assetCR;
          }

          if (this.q4_selected_option == this.q4_Yes_Selected) {
            q4 = 'Yes';
          } else if (this.q4_selected_option == this.q4_No_Selected) {
            q4 = 'No';
          } else if (this.q4_selected_option == this.q4_Have_Selected) {
            q4 = 'Have not thought about it';
          } // //console.log("q4:-"+this.q4_selected_option);


          if (this.q5_selected_option == this.q5_No) {
            q5 = 'No';
          } else if (this.Working_class == this.selected_option_class || this.Business_class == this.selected_option_class) {
            if (this.Working_class == this.selected_option_class) {
              q5 = 'Working Capital';
            }

            if (this.Business_class == this.selected_option_class) {
              if (q5 != '') {
                q5 += ',Business Expansion';
              } else {
                q5 = 'Business Expansion';
              }
            }

            q5a = this.q5a_selected_option;
          } // //console.log("q1a_selected_option:-"+q1a);
          // //console.log("q1a2_selected_option:-"+this.q1a2_selected_option);


          window.sessionStorage.setItem('p2_q1', this.q1_selected_option);
          window.sessionStorage.setItem('p2_q2CR', this.q2_annual_turn_overCR);
          window.sessionStorage.setItem('p2_q3CR', this.q3_total_value_assetCR);
          window.sessionStorage.setItem('p2_q1a', q1a);
          window.sessionStorage.setItem('p2_q1a2', this.q1a2_selected_option);
          window.sessionStorage.setItem('p2_q2LACS', this.q2_annual_turn_overLACS);
          window.sessionStorage.setItem('p2_q3LACS', this.q3_total_value_assetLACS);
          window.sessionStorage.setItem('p2_q4', this.q4_selected_option);
          window.sessionStorage.setItem('p2_q5', q5);
          window.sessionStorage.setItem('p2_q5a', this.q5a_selected_option); // //console.log("q5:-"+this.q5_selected_option);
          // //console.log("q5a:-"+this.q5a_selected_option);
          //console.log('q1:-' + q1);
          //console.log('q1a:-' + q1a);
          //console.log('q2:-' + q2);
          //console.log('q3:-' + q3);
          //console.log('q4:-' + q4);
          //console.log('q5:-' + q5);
          //console.log('q5a:-' + q5a);
          // var formData = new FormData();
          // formData.append('user_id', this.getUser().user_id);
          // formData.append('q1', q1);
          // formData.append('q1a', q1a);
          // formData.append('q2', q2);
          // formData.append('q3', q3);
          // formData.append('q4', q4);
          // formData.append('q5', q5);
          // formData.append('q5a', q5a);

          var postData = {
            user_id: this.getUser().user_id,
            q1: q1,
            q1a: q1a,
            q2: q2,
            q3: q3,
            q4: q4,
            q5: q5,
            q5a: q5a
          };
          var formData = {
            request: this.aesEncryptionDecryptionService.encryptRequest(JSON.stringify(postData))
          };
          this.http.post(this.getSessionStoredItem(this.BASE_URL) + this.SAVE_BUSINESS_OWNER_URL, JSON.stringify(formData), {
            responseType: 'text'
          }).subscribe(function (data) {
            try {
              // //console.log('data received:-' + data);
              // let parsedJSON = JSON.parse(data);
              //console.log('data received:-' + data);
              var parsedData = JSON.parse(data);

              var parsedJSON = _this6.aesEncryptionDecryptionService.parseEncryptedResponse(parsedData.response);

              if (parsedJSON.status) {
                _this6.setSessionStoredItem(_this6.OWNER_DATA, JSON.stringify(parsedJSON.data));

                _this6.route.navigate(['/employer']);
              } else {
                alert(parsedJSON.message);
              }
            } catch (e) {//console.log(e);
            }
          }); // alert("all good please go ahead");
          // this.route.navigate(['/employer']);
        }
      }, {
        key: "checkNumber",
        value: function checkNumber() {
          console.log("event:-number");
          return true;
        }
      }, {
        key: "keyPress",
        value: function keyPress(event) {
          var pattern = /[0-9\+\-\ ]/;
          var inputChar = String.fromCharCode(event.charCode);
          console.log("inputChar:-" + inputChar);

          if (event.keyCode != 8 && !pattern.test(inputChar)) {
            event.preventDefault();
          }
        }
      }]);

      return OwnerComponent;
    }(_utils_BaseComp__WEBPACK_IMPORTED_MODULE_3__["BaseComp"]);

    OwnerComponent.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
      }, {
        type: _aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_5__["AESEncryptionDecryptionService"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q1_error', {
      static: false
    })], OwnerComponent.prototype, "q1_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q1a_error', {
      static: false
    })], OwnerComponent.prototype, "q1a_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q2LACS_error', {
      static: false
    })], OwnerComponent.prototype, "q2LACS_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q3LACS_error', {
      static: false
    })], OwnerComponent.prototype, "q3LACS_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q2CR_error', {
      static: false
    })], OwnerComponent.prototype, "q2CR_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q3CR_error', {
      static: false
    })], OwnerComponent.prototype, "q3CR_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q4_error', {
      static: false
    })], OwnerComponent.prototype, "q4_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q5_error', {
      static: false
    })], OwnerComponent.prototype, "q5_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('q5a_error', {
      static: false
    })], OwnerComponent.prototype, "q5a_error", void 0);
    OwnerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-owner',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./owner.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/owner/owner.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./owner.component.css */
      "./src/app/owner/owner.component.css")).default]
    })], OwnerComponent);
    /***/
  },

  /***/
  "./src/app/page-not-found/page-not-found.component.css":
  /*!*************************************************************!*\
    !*** ./src/app/page-not-found/page-not-found.component.css ***!
    \*************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPageNotFoundPageNotFoundComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2Utbm90LWZvdW5kL3BhZ2Utbm90LWZvdW5kLmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/page-not-found/page-not-found.component.ts":
  /*!************************************************************!*\
    !*** ./src/app/page-not-found/page-not-found.component.ts ***!
    \************************************************************/

  /*! exports provided: PageNotFoundComponent */

  /***/
  function srcAppPageNotFoundPageNotFoundComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PageNotFoundComponent", function () {
      return PageNotFoundComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var PageNotFoundComponent =
    /*#__PURE__*/
    function () {
      function PageNotFoundComponent() {
        _classCallCheck(this, PageNotFoundComponent);
      }

      _createClass(PageNotFoundComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return PageNotFoundComponent;
    }();

    PageNotFoundComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-page-not-found',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./page-not-found.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/page-not-found/page-not-found.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./page-not-found.component.css */
      "./src/app/page-not-found/page-not-found.component.css")).default]
    })], PageNotFoundComponent);
    /***/
  },

  /***/
  "./src/app/register/register.component.css":
  /*!*************************************************!*\
    !*** ./src/app/register/register.component.css ***!
    \*************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRegisterRegisterComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-dialog-container {\r\n    display: -webkit-box !important;\r\n    display: flex !important;\r\n    -webkit-box-orient: vertical;\r\n    -webkit-box-direction: normal;\r\n            flex-direction: column;\r\n    width: 250px;\r\n}\r\n\r\ninput.ng-touched.ng-invalid{\r\n    border-left: 5px red;\r\n}\r\n\r\n/* input.ng-touched.ng-valid{\r\n    border-left: 5px solid green;\r\n} */\r\n\r\n.paragraph{\r\n    font-size: 15px;\r\n    color: grey;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVnaXN0ZXIvcmVnaXN0ZXIuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLCtCQUF3QjtJQUF4Qix3QkFBd0I7SUFDeEIsNEJBQXNCO0lBQXRCLDZCQUFzQjtZQUF0QixzQkFBc0I7SUFDdEIsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLG9CQUFvQjtBQUN4Qjs7QUFFQTs7R0FFRzs7QUFFSDtJQUNJLGVBQWU7SUFDZixXQUFXO0FBQ2YiLCJmaWxlIjoic3JjL2FwcC9yZWdpc3Rlci9yZWdpc3Rlci5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1hdC1kaWFsb2ctY29udGFpbmVyIHtcclxuICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICB3aWR0aDogMjUwcHg7XHJcbn1cclxuXHJcbmlucHV0Lm5nLXRvdWNoZWQubmctaW52YWxpZHtcclxuICAgIGJvcmRlci1sZWZ0OiA1cHggcmVkO1xyXG59XHJcblxyXG4vKiBpbnB1dC5uZy10b3VjaGVkLm5nLXZhbGlke1xyXG4gICAgYm9yZGVyLWxlZnQ6IDVweCBzb2xpZCBncmVlbjtcclxufSAqL1xyXG5cclxuLnBhcmFncmFwaHtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIGNvbG9yOiBncmV5O1xyXG59Il19 */";
    /***/
  },

  /***/
  "./src/app/register/register.component.ts":
  /*!************************************************!*\
    !*** ./src/app/register/register.component.ts ***!
    \************************************************/

  /*! exports provided: RegisterComponent */

  /***/
  function srcAppRegisterRegisterComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RegisterComponent", function () {
      return RegisterComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _t_c_t_c_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../t-c/t-c.component */
    "./src/app/t-c/t-c.component.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _utils_BaseComp__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../utils/BaseComp */
    "./src/app/utils/BaseComp.ts");
    /* harmony import */


    var _aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../aesencryption-decryption.service */
    "./src/app/aesencryption-decryption.service.ts");

    var RegisterComponent =
    /*#__PURE__*/
    function (_utils_BaseComp__WEBP4) {
      _inherits(RegisterComponent, _utils_BaseComp__WEBP4);

      function RegisterComponent(dialog, route, http, aesEncryptionDecryptionService) {
        var _this7;

        _classCallCheck(this, RegisterComponent);

        _this7 = _possibleConstructorReturn(this, _getPrototypeOf(RegisterComponent).call(this));
        _this7.dialog = dialog;
        _this7.route = route;
        _this7.http = http;
        _this7.aesEncryptionDecryptionService = aesEncryptionDecryptionService;
        _this7.Salutation = 'Mr.';
        _this7.Name = '';
        _this7.date = '14-05-2020';
        _this7.Mobile = '';
        _this7.Email = '';
        _this7.Company_Name = '';
        _this7.Location = '';
        _this7.Aviva_Emp_Id = '';
        _this7.Terms_Condition = '';
        _this7.email_error = "Email cannot be blank.";
        _this7.show_Name_error = false;
        _this7.show_Date_error = false;
        _this7.show_Mobile_error = false;
        _this7.show_Email_error = false;
        _this7.show_CompanyName_error = false;
        _this7.show_City_error = false;
        _this7.show_TC_error = false;
        return _this7;
      }

      _createClass(RegisterComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.Salutation = window.sessionStorage.getItem('Martial Status') == null ? '' : window.sessionStorage.getItem('Martial Status');
          this.Name = window.sessionStorage.getItem('Name') == null ? '' : window.sessionStorage.getItem('Name');
          this.date = window.sessionStorage.getItem('date') == null ? '' : window.sessionStorage.getItem('date');
          this.Mobile = window.sessionStorage.getItem('Mobile') == null ? '' : window.sessionStorage.getItem('Mobile');
          this.Email = window.sessionStorage.getItem('Email') == null ? '' : window.sessionStorage.getItem('Email');
          this.Company_Name = window.sessionStorage.getItem('Company_Name') == null ? '' : window.sessionStorage.getItem('Company_Name');
          this.Location = window.sessionStorage.getItem('Location') == null ? '' : window.sessionStorage.getItem('Location');
          this.Aviva_Emp_Id = window.sessionStorage.getItem('Aviva_Emp_Id') == null ? '' : window.sessionStorage.getItem('Aviva_Emp_Id');
          this.Terms_Condition = window.sessionStorage.getItem('Terms_Condition') == null ? '' : window.sessionStorage.getItem('Terms_Condition');
        }
      }, {
        key: "_openCalendar",
        value: function _openCalendar(picker) {
          picker.open();
        }
      }, {
        key: "openDialog",
        value: function openDialog() {
          var dialogRef = this.dialog.open(_t_c_t_c_component__WEBPACK_IMPORTED_MODULE_3__["TCComponent"], {
            width: '70%',
            height: '50%'
          });
        } // sub():void{
        //   var formData=new FormData();
        //   formData.append('salutation','');
        //   formData.append('name','');
        //   formData.append('dob','');
        //   formData.append('mobile','');
        //   formData.append('email_id','');
        //   formData.append('company_name','');
        //   formData.append('city','');
        //   formData.append('aviva_emp_id','');
        //   this.http.get("http://10.72.9.169/sme/index.php/api/User/test",{responseType: 'text'}).subscribe(data => {
        //     //console.log('my data: ', data);
        //   })
        // }

      }, {
        key: "checkMobileNumber",
        value: function checkMobileNumber() {
          console.log('on key up');
        }
      }, {
        key: "validEmail",
        value: function validEmail(mail) {
          if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
            return true;
          }

          return false;
        }
      }, {
        key: "sub",
        value: function sub() {
          var _this8 = this;

          //console.log('Salutation Status:-' + this.Salutation);
          //console.log('name:-' + this.Name);
          if (this.Name == '') {
            this.show_Name_error = true;
            this.Name_error.nativeElement.focus();
            return;
          } else {
            this.show_Name_error = false;
          } //console.log('Date:-' + this.date);


          if (this.date == '') {
            // alert("Please enter Date");
            this.show_Date_error = true;
            this.Date_error.nativeElement.focus();
            return;
          } else {
            this.show_Date_error = false;
          } //console.log('Mobile:-' + this.Mobile);


          if (this.Mobile == '') {
            // alert("Please enter mobile number");
            this.show_Mobile_error = true;
            this.Mobile_error.nativeElement.focus();
            return;
          } else {
            this.show_Mobile_error = false;
          } //console.log('Email:-' + this.Email);


          if (this.Email == '') {
            // alert("Please enter Email");
            this.email_error = "Email cannot be blank.";
            this.show_Email_error = true;
            this.Email_error.nativeElement.focus();
            return;
          } else {
            this.show_Email_error = false;
          }

          if (!this.validEmail(this.Email)) {
            // alert("Please enter Email");
            this.email_error = "Enter valid email";
            this.show_Email_error = true;
            this.Email_error.nativeElement.focus();
            return;
          } else {
            this.show_Email_error = false;
          } //console.log('Company_Name:-' + this.Company_Name);


          if (this.Company_Name == '') {
            // alert("Please enter Company_Name");
            this.show_CompanyName_error = true;
            this.Company_error.nativeElement.focus();
            return;
          } else {
            this.show_CompanyName_error = false;
          } //console.log('Location:-' + this.Location);


          if (this.Location == '') {
            // alert("Please enter City");
            this.show_City_error = true;
            this.City_error.nativeElement.focus();
            return;
          } else {
            this.show_City_error = false;
          } //console.log('Terms_Condition:-' + this.Terms_Condition);


          if (this.Terms_Condition == '') {
            // alert('Please accept Terms and Conditions');
            this.show_TC_error = true;
            this.TC_error.nativeElement.focus();
            return;
          } // var formData = new FormData();
          // formData.append('salutation', this.Salutation);
          // formData.append('name', this.Name);
          // formData.append('dob', this.getServerFormattedDate(this.date));
          // formData.append('mobile', this.Mobile);
          // formData.append('email_id', this.Email);
          // formData.append('company_name', this.Company_Name);
          // formData.append('city', this.Location);
          // formData.append('aviva_emp_id', this.Aviva_Emp_Id);


          var postData = {
            salutation: this.Salutation,
            name: this.Name,
            dob: this.getServerFormattedDate(this.date),
            mobile: this.Mobile,
            email_id: this.Email,
            company_name: this.Company_Name,
            city: this.Location,
            aviva_emp_id: this.Aviva_Emp_Id
          };
          var formData = {
            request: this.aesEncryptionDecryptionService.encryptRequest(JSON.stringify(postData))
          }; //console.log("form Data:-" + JSON.stringify(formData));

          this.http.post(this.getSessionStoredItem(this.BASE_URL) + this.REGISTER_URL, JSON.stringify(formData), {
            responseType: 'text'
          }).subscribe(function (data) {
            try {
              //console.log('data received:-' + data);
              var parsedData = JSON.parse(data);

              var parsedJSON = _this8.aesEncryptionDecryptionService.parseEncryptedResponse(parsedData.response);

              if (parsedJSON.status) {
                _this8.setSessionStoredItem(_this8.REGISTER_DATA, JSON.stringify(parsedJSON.data));

                _this8.route.navigate(['/owner']);
              } else {
                alert(parsedJSON.message);
              }
            } catch (e) {//console.log(e);
            }
          }); // end of alert validation

          window.sessionStorage.setItem('Martial Status', this.Salutation);
          window.sessionStorage.setItem('Name', this.Name);
          window.sessionStorage.setItem('Date', this.date);
          window.sessionStorage.setItem('Mobile', this.Mobile);
          window.sessionStorage.setItem('Email', this.Email);
          window.sessionStorage.setItem('Company_Name', this.Company_Name);
          window.sessionStorage.setItem('Location', this.Location);
          window.sessionStorage.setItem('Aviva_Emp_Id', this.Aviva_Emp_Id);
          window.sessionStorage.setItem('Terms_Condition', this.Terms_Condition); // this.route.navigate(['/owner']);
        }
      }]);

      return RegisterComponent;
    }(_utils_BaseComp__WEBPACK_IMPORTED_MODULE_6__["BaseComp"]);

    RegisterComponent.ctorParameters = function () {
      return [{
        type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MatDialog"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
      }, {
        type: _aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_7__["AESEncryptionDecryptionService"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('Name_error', {
      static: false
    })], RegisterComponent.prototype, "Name_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('Date_error', {
      static: false
    })], RegisterComponent.prototype, "Date_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('Mobile_error', {
      static: false
    })], RegisterComponent.prototype, "Mobile_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('Email_error', {
      static: false
    })], RegisterComponent.prototype, "Email_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('Company_error', {
      static: false
    })], RegisterComponent.prototype, "Company_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('City_error', {
      static: false
    })], RegisterComponent.prototype, "City_error", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('TC_error', {
      static: false
    })], RegisterComponent.prototype, "TC_error", void 0);
    RegisterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-register',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./register.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./register.component.css */
      "./src/app/register/register.component.css")).default]
    })], RegisterComponent);
    /***/
  },

  /***/
  "./src/app/report/report.component.css":
  /*!*********************************************!*\
    !*** ./src/app/report/report.component.css ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppReportReportComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlcG9ydC9yZXBvcnQuY29tcG9uZW50LmNzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/report/report.component.ts":
  /*!********************************************!*\
    !*** ./src/app/report/report.component.ts ***!
    \********************************************/

  /*! exports provided: ReportComponent */

  /***/
  function srcAppReportReportComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReportComponent", function () {
      return ReportComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _t_c_t_c_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../t-c/t-c.component */
    "./src/app/t-c/t-c.component.ts");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _utils_BaseComp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../utils/BaseComp */
    "./src/app/utils/BaseComp.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../aesencryption-decryption.service */
    "./src/app/aesencryption-decryption.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var file_saver__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! file-saver */
    "./node_modules/file-saver/dist/FileSaver.min.js");
    /* harmony import */


    var file_saver__WEBPACK_IMPORTED_MODULE_8___default =
    /*#__PURE__*/
    __webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_8__);

    var ReportComponent =
    /*#__PURE__*/
    function (_utils_BaseComp__WEBP5) {
      _inherits(ReportComponent, _utils_BaseComp__WEBP5);

      function ReportComponent(dialog, route, aesEncryptionDecryptionService, http) {
        var _this9;

        _classCallCheck(this, ReportComponent);

        _this9 = _possibleConstructorReturn(this, _getPrototypeOf(ReportComponent).call(this));
        _this9.dialog = dialog;
        _this9.route = route;
        _this9.aesEncryptionDecryptionService = aesEncryptionDecryptionService;
        _this9.http = http;
        _this9.report_base_url = "";
        return _this9;
      }

      _createClass(ReportComponent, [{
        key: "onFocus",
        value: function onFocus() {// this.el.nativeElement.focus();
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          this.report_base_url = this.getSessionStoredItem(this.BASE_URL); //console.log("register data:-"+this.getSessionStoredItem(this.REGISTER_DATA));

          this.registerData = JSON.parse(this.getSessionStoredItem(this.REGISTER_DATA));

          if (this.getSessionStoredItem(this.REGISTER_DATA) == null || this.getSessionStoredItem(this.REGISTER_DATA) == '' || this.getSessionStoredItem(this.REGISTER_DATA) == 'null') {
            this.route.navigate(['/register']);
          } else if (this.getSessionStoredItem(this.OWNER_DATA) == null && this.getSessionStoredItem(this.OWNER_DATA) == '' && this.getSessionStoredItem(this.OWNER_DATA) == 'null') {
            this.route.navigate(['/owner']);
          } else if (this.getSessionStoredItem(this.SAVE_EMPLOYER) == null && this.getSessionStoredItem(this.SAVE_EMPLOYER) == '' && this.getSessionStoredItem(this.SAVE_EMPLOYER) == 'null') {
            this.route.navigate(['/employer']);
          } else if (this.getSessionStoredItem(this.SAVE_HOF) == null && this.getSessionStoredItem(this.SAVE_HOF) == '' && this.getSessionStoredItem(this.SAVE_HOF) == 'null') {
            this.route.navigate(['/head-family']);
          }

          this.downloadReport();
        }
      }, {
        key: "openDialog",
        value: function openDialog() {
          this.dialog.open(_t_c_t_c_component__WEBPACK_IMPORTED_MODULE_2__["TCComponent"]);
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          //Called once, before the instance is destroyed.
          //Add 'implements OnDestroy' to the class.
          this.setSessionStoredItem(this.REGISTER_DATA, "");
          this.setSessionStoredItem(this.OWNER_DATA, "");
          this.setSessionStoredItem(this.SAVE_EMPLOYER, "");
          this.setSessionStoredItem(this.SAVE_HOF, "");
        }
      }, {
        key: "downloadReport",
        value: function downloadReport() {
          var _this10 = this;

          // window.sessionStorage.setItem('Martial Status', "");
          // window.sessionStorage.setItem('Name', "");
          // window.sessionStorage.setItem('Date', "");
          // window.sessionStorage.setItem('Mobile', "");
          // window.sessionStorage.setItem('Email', "");
          // window.sessionStorage.setItem('Company_Name', "");
          // window.sessionStorage.setItem('Location', "");
          // window.sessionStorage.setItem('Aviva_Emp_Id', "");
          // window.sessionStorage.setItem('Terms_Condition', "");
          // window.open(this.OPEN_PDF+this.registerData.user_id, "_blank");
          window.sessionStorage.clear();
          console.log("registered_user_id:-" + this.registerData.user_id); // let postData = {
          //     user_id: this.aesEncryptionDecryptionService.encryptRequest(this.registerData.user_id)
          // }

          var postData = {
            user_id: this.registerData.user_id
          };
          this.http.post(this.report_base_url + this.OPEN_PDF, JSON.stringify(postData), {
            responseType: 'arraybuffer'
          }).subscribe(function (data) {
            try {
              console.log('data received:-' + data);
              Object(file_saver__WEBPACK_IMPORTED_MODULE_8__["saveAs"])(new Blob([data], {
                type: 'application/pdf'
              }), _this10.registerData.name + ".pdf"); // let parsedJSON = JSON.parse(data);
              //console.log("response:-" + parsedJSON.response);
              //console.log("parsedResponse:-" + JSON.stringify(this.aesEncryptionDecryptionService.parseEncryptedResponse(parsedJSON.response)));
            } catch (e) {
              console.log(e);
            }
          }); // window.open(this.OPEN_PDF + this.aesEncryptionDecryptionService.encryptRequest(this.registerData.user_id), "_blank");
        }
      }]);

      return ReportComponent;
    }(_utils_BaseComp__WEBPACK_IMPORTED_MODULE_4__["BaseComp"]);

    ReportComponent.ctorParameters = function () {
      return [{
        type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }, {
        type: _aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_6__["AESEncryptionDecryptionService"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"]
      }];
    };

    ReportComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-report',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./report.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/report/report.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./report.component.css */
      "./src/app/report/report.component.css")).default]
    })], ReportComponent);
    /***/
  },

  /***/
  "./src/app/start/start.component.css":
  /*!*******************************************!*\
    !*** ./src/app/start/start.component.css ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppStartStartComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3N0YXJ0L3N0YXJ0LmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/start/start.component.ts":
  /*!******************************************!*\
    !*** ./src/app/start/start.component.ts ***!
    \******************************************/

  /*! exports provided: StartComponent */

  /***/
  function srcAppStartStartComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "StartComponent", function () {
      return StartComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../aesencryption-decryption.service */
    "./src/app/aesencryption-decryption.service.ts");
    /* harmony import */


    var _utils_BaseComp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../utils/BaseComp */
    "./src/app/utils/BaseComp.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");

    var MIME_TYPES = {
      pdf: 'application/pdf'
    };

    var StartComponent =
    /*#__PURE__*/
    function (_utils_BaseComp__WEBP6) {
      _inherits(StartComponent, _utils_BaseComp__WEBP6);

      function StartComponent(aesEncryptionDecryptionService, http) {
        var _this11;

        _classCallCheck(this, StartComponent);

        _this11 = _possibleConstructorReturn(this, _getPrototypeOf(StartComponent).call(this));
        _this11.aesEncryptionDecryptionService = aesEncryptionDecryptionService;
        _this11.http = http;
        _this11.secretKey = "AVIVASME#2020";
        _this11.str = "checkingstring";
        return _this11;
      }

      _createClass(StartComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this12 = this;

          window.sessionStorage.clear(); // let encryption = this.aesEncryptionDecryptionService.encryptRequestTest("Sunil Vishwakarma");
          // //console.log("encryption:-" + encryption);
          //
          // let postData={
          //     name:'sunil',
          //     password:'123456'
          // }
          //
          //
          // let formData = {
          //     request: this.aesEncryptionDecryptionService.encryptRequest(JSON.stringify(postData))
          // }
          // //console.log("form Data:-"+JSON.stringify(formData));
          //
          // this.http.post(this.ENCRYPTION, JSON.stringify(formData), {responseType: 'text'}).subscribe(data => {
          //     try {
          //         //console.log('data received:-' + data);
          //
          //     } catch (e) {
          //         //console.log(e);
          //     }
          // });
          // this.http.get(this.ENCRYPTION_RESPONSE, {responseType: 'text'}).subscribe(data => {
          //     try {
          //         //console.log('data received:-' + data);
          //         let parsedJSON = JSON.parse(data);
          //         //console.log("response:-" + parsedJSON.response);
          //         //console.log("parsedResponse:-" + JSON.stringify(this.aesEncryptionDecryptionService.parseEncryptedResponse(parsedJSON.response)));
          //     } catch (e) {
          //         //console.log(e);
          //     }
          // });
          // let postData = {
          //     user_id: "1"
          // }
          //
          // this.http.post("http://localhost/sme/angular_pdf/pdf.php", JSON.stringify(postData), {responseType: 'arraybuffer'}).subscribe(data => {
          //     try {
          //         console.log('data received:-' + data);
          //         saveAs(new Blob([data], {type: MIME_TYPES.pdf}), 'user.pdf');
          //         // let parsedJSON = JSON.parse(data);
          //         //console.log("response:-" + parsedJSON.response);
          //         //console.log("parsedResponse:-" + JSON.stringify(this.aesEncryptionDecryptionService.parseEncryptedResponse(parsedJSON.response)));
          //     } catch (e) {
          //         console.log(e);
          //     }
          // });

          this.http.get("assets/config.json", {
            responseType: 'text'
          }).subscribe(function (data) {
            try {
              // console.log("data:-"+data);
              // console.log("base_url:-"+JSON.parse(data).base_url);
              _this12.setSessionStoredItem(_this12.BASE_URL, JSON.parse(data).base_url);
            } catch (e) {
              console.log(e);
            }
          });
        }
      }]);

      return StartComponent;
    }(_utils_BaseComp__WEBPACK_IMPORTED_MODULE_3__["BaseComp"]);

    StartComponent.ctorParameters = function () {
      return [{
        type: _aesencryption_decryption_service__WEBPACK_IMPORTED_MODULE_2__["AESEncryptionDecryptionService"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
      }];
    };

    StartComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-start',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./start.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/start/start.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./start.component.css */
      "./src/app/start/start.component.css")).default]
    })], StartComponent);
    /***/
  },

  /***/
  "./src/app/t-c/t-c.component.css":
  /*!***************************************!*\
    !*** ./src/app/t-c/t-c.component.css ***!
    \***************************************/

  /*! exports provided: default */

  /***/
  function srcAppTCTCComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".head{\r\n    background-color: #001E60;\r\n    color: white;\r\n}\r\n\r\n.TC{\r\n    overflow-x: hidden;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdC1jL3QtYy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxrQkFBa0I7QUFDdEIiLCJmaWxlIjoic3JjL2FwcC90LWMvdC1jLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMDFFNjA7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi5UQ3tcclxuICAgIG92ZXJmbG93LXg6IGhpZGRlbjtcclxufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/t-c/t-c.component.ts":
  /*!**************************************!*\
    !*** ./src/app/t-c/t-c.component.ts ***!
    \**************************************/

  /*! exports provided: TCComponent */

  /***/
  function srcAppTCTCComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TCComponent", function () {
      return TCComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");

    var TCComponent =
    /*#__PURE__*/
    function () {
      function TCComponent(data) {
        _classCallCheck(this, TCComponent);

        this.data = data;
      }

      _createClass(TCComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return TCComponent;
    }();

    TCComponent.ctorParameters = function () {
      return [{
        type: TCComponent,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"],
          args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MAT_DIALOG_DATA"]]
        }]
      }];
    };

    TCComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-t-c',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./t-c.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/t-c/t-c.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./t-c.component.css */
      "./src/app/t-c/t-c.component.css")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MAT_DIALOG_DATA"]))], TCComponent);
    /***/
  },

  /***/
  "./src/app/utils/BaseComp.ts":
  /*!***********************************!*\
    !*** ./src/app/utils/BaseComp.ts ***!
    \***********************************/

  /*! exports provided: BaseComp */

  /***/
  function srcAppUtilsBaseCompTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BaseComp", function () {
      return BaseComp;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var BaseComp =
    /*#__PURE__*/
    function () {
      function BaseComp() {
        _classCallCheck(this, BaseComp);

        // BASE_URL="http://localhost/sme/index.php/api/" ;
        // REGISTER_URL=this.BASE_URL+"User/insertUser";
        // SAVE_BUSINESS_OWNER_URL=this.BASE_URL+"User/saveBusinessOwner";
        // SAVE_EMPLOYER_URL=this.BASE_URL+"User/saveEmployer";
        // SAVE_HOF_URL=this.BASE_URL+"User/saveHOF";
        // ENCRYPTION=this.BASE_URL+"Encryption/checkEncryptionAPI";
        // ENCRYPTION_RESPONSE=this.BASE_URL+"Encryption/checkDecryption";
        this.BASE_URL = "BASE_URL";
        this.REGISTER_URL = "index.php/api/User/insertUser";
        this.SAVE_BUSINESS_OWNER_URL = "index.php/api/User/saveBusinessOwner";
        this.SAVE_EMPLOYER_URL = "index.php/api/User/saveEmployer";
        this.SAVE_HOF_URL = "index.php/api/User/saveHOF";
        this.ENCRYPTION = "index.php/api/Encryption/checkEncryptionAPI";
        this.ENCRYPTION_RESPONSE = "index.php/api/Encryption/checkDecryption"; // OPEN_PDF=this.BASE_URL+"CreatePdf/createPDF?user_id=";

        this.OPEN_PDF = "angular_pdf/pdf.php";
        this.REGISTER_DATA = "REGISTER_DATA";
        this.OWNER_DATA = "OWNER_DATA";
        this.SAVE_EMPLOYER = "SAVE_EMPLOYER";
        this.SAVE_HOF = "SAVE_HOF";
      }

      _createClass(BaseComp, [{
        key: "getServerFormattedDate",
        value: function getServerFormattedDate(dateString) {
          try {
            var mydate = new Date(dateString);
            var newDate = mydate.getFullYear() + "-" + (mydate.getMonth() + 1) + "-" + mydate.getDate(); //console.log("new Date:-"+newDate);

            return newDate;
          } catch (e) {//console.log(e);
          }

          return dateString;
        }
      }, {
        key: "getSessionStoredItem",
        value: function getSessionStoredItem(key) {
          return window.sessionStorage.getItem(key);
        }
      }, {
        key: "setSessionStoredItem",
        value: function setSessionStoredItem(key, value) {
          window.sessionStorage.setItem(key, value);
        }
      }, {
        key: "getUser",
        value: function getUser() {
          return JSON.parse(this.getSessionStoredItem(this.REGISTER_DATA));
        }
      }]);

      return BaseComp;
    }();
    /***/

  },

  /***/
  "./src/environments/environment.ts":
  /*!*****************************************!*\
    !*** ./src/environments/environment.ts ***!
    \*****************************************/

  /*! exports provided: environment */

  /***/
  function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "environment", function () {
      return environment;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js"); // This file can be replaced during build by using the `fileReplacements` array.
    // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
    // The list of file replacements can be found in `angular.json`.


    var environment = {
      production: false
    };
    /*
     * For easier debugging in development mode, you can import the following file
     * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
     *
     * This import should be commented out in production mode because it will have a negative impact
     * on performance if an error is thrown.
     */
    // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

    /***/
  },

  /***/
  "./src/main.ts":
  /*!*********************!*\
    !*** ./src/main.ts ***!
    \*********************/

  /*! no exports provided */

  /***/
  function srcMainTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var hammerjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! hammerjs */
    "./node_modules/hammerjs/hammer.js");
    /* harmony import */


    var hammerjs__WEBPACK_IMPORTED_MODULE_1___default =
    /*#__PURE__*/
    __webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_1__);
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/platform-browser-dynamic */
    "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
    /* harmony import */


    var _app_app_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./app/app.module */
    "./src/app/app.module.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./environments/environment */
    "./src/environments/environment.ts");

    if (_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].production) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["enableProdMode"])();
    }

    Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_4__["AppModule"]).catch(function (err) {
      return console.error(err);
    });
    /***/
  },

  /***/
  0:
  /*!***************************!*\
    !*** multi ./src/main.ts ***!
    \***************************/

  /*! no static exports found */

  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__(
    /*! /Users/sunilvishwakarma/Desktop/projects/sme/smewebsite/src/main.ts */
    "./src/main.ts");
    /***/
  }
}, [[0, "runtime", "vendor"]]]);
//# sourceMappingURL=main-es5.js.map