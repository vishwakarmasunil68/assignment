import { Component } from '@angular/core';
import {AlertController, IonicPage, NavController, NavParams} from 'ionic-angular';
import {ProfilePage} from "../profile/profile";
import {ReportProblemPage} from "../report-problem/report-problem";
import {PrivacyPolicyPage} from "../privacy-policy/privacy-policy";

/**
 * Generated class for the SettingPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-setting',
  templateUrl: 'setting.html',
})
export class SettingPage {

  constructor(public navCtrl: NavController, public navParams: NavParams,public alertCtrl:AlertController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SettingPage');
  }

  openProfilePage(){
    this.navCtrl.push(ProfilePage);
  }

  openChangePassword(){
    let alert = this.alertCtrl.create({
      title: 'Change Password',
      inputs: [
        {
          name: 'old_password',
          placeholder: 'Old password',
          type: 'password'
        },
        {
          name: 'new_password',
          placeholder: 'New Password',
          type: 'password'
        },
        {
          name: 'confirm_password',
          placeholder: 'Confirm Password',
          type: 'password'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Change',
          handler: data => {
            console.log("change password:-" + JSON.stringify(data));
            // this.callChangePasswordAPI(data.);

          }
        }
      ],
      enableBackdropDismiss: false
    });
    alert.present();
  }

  reportProblem(){
      this.navCtrl.push(ReportProblemPage);
  }
  openPrivayPolicy(){
      this.navCtrl.push(PrivacyPolicyPage);
  }

}
