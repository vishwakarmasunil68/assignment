import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ExpiredAssignmentListPage } from './expired-assignment-list';

@NgModule({
  declarations: [
    ExpiredAssignmentListPage,
  ],
  imports: [
    IonicPageModule.forChild(ExpiredAssignmentListPage),
  ],
})
export class ExpiredAssignmentListPageModule {}
