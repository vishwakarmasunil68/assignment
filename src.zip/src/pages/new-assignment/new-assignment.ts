import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the NewAssignmentPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-new-assignment',
  templateUrl: 'new-assignment.html',
})
export class NewAssignmentPage {


  startDate: string = "Date";

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    var d = new Date();

    let date = this.properFormatNumber(d.getDate());
    let month = this.properFormatNumber(d.getMonth() + 1);
    let year = d.getFullYear();

    this.startDate = year + "-" + month + "-" + date + "T00:00:00Z";
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewAssignmentPage');
  }

  properFormatNumber(number: number): string {
    let numString = "";
    if (number < 10) {
      numString = "0" + number;
    } else {
      numString = number + "";
    }
    return numString;
  }

}
