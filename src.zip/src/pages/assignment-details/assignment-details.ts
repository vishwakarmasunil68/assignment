import { Component } from '@angular/core';
import {ActionSheetController, AlertController, IonicPage, NavController, NavParams} from 'ionic-angular';

/**
 * Generated class for the AssignmentDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-assignment-details',
  templateUrl: 'assignment-details.html',
})
export class AssignmentDetailsPage {

  chats:string[]=[];
  view_details=false;

  constructor(public navCtrl: NavController, public navParams: NavParams,
              public actionSheetCtrl:ActionSheetController,public alertCtrl:AlertController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AssignmentDetailsPage');
    this.chats.push("");
    this.chats.push("");
    this.chats.push("");
    this.chats.push("");
    this.chats.push("");
    this.chats.push("");
    this.chats.push("");
    this.chats.push("");
  }

  presentSheet():void{
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Please Select',
      buttons: [
        {
          text: 'Rate',
          handler: () => {
            this.openRating();
          }
        },
        {
          text: 'View Details',
          handler: () => {
            console.log('Destructive clicked');
          }
        },{
          text: 'Not Satisfy',
          handler: () => {
            console.log('Archive clicked');
          }
        },{
          text: 'Verify Details',
          handler: () => {
            console.log('Archive clicked');
          }
        },{
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });
    actionSheet.present();
  }

  openRating(){
    const alert = this.alertCtrl.create({
      title: 'Rate',
      cssClass: 'alertstar',
      enableBackdropDismiss:true,
      buttons: [
        { text: '1', handler: data => { this.resolveRec(1);}},
        { text: '2', handler: data => { this.resolveRec(2);}},
        { text: '3', handler: data => { this.resolveRec(3);}},
        { text: '4', handler: data => { this.resolveRec(4);}},
        { text: '5', handler: data => { this.resolveRec(5);}}
      ]
    });
    alert.present();
  }

  resolveRec(number){

  }

}
