import {Component, ViewChild} from '@angular/core';
import {Events, MenuController, NavController, Tabs} from 'ionic-angular';
import {AssignmentListPage} from "../assignment-list/assignment-list";
import {NewAssignmentPage} from "../new-assignment/new-assignment";
import {ProfilePage} from "../profile/profile";
import {AssignmentDetailsPage} from "../assignment-details/assignment-details";
import {ContactusPage} from "../contactus/contactus";
import {SettingPage} from "../setting/setting";
import {NotificationListPage} from "../notification-list/notification-list";

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  tab1Root=AssignmentListPage;
  tab2Root=AssignmentListPage;
  tab3Root=AssignmentListPage;
  tab4Root=AssignmentListPage;

  @ViewChild('tabs') tab: Tabs;

  constructor(public navCtrl: NavController,public menuCtrl:MenuController,public events:Events) {
    events.subscribe('tab_clicked', (data) => {
      console.log("tab_clicked:-" + data);
      this.menuCtrl.close();
      switch (data) {
        case "open_menu":
          this.openMenu();
          break;
        case "live_track":
          break;
        case "profile":
          break;
        case "setting":
          this.navCtrl.push(SettingPage);
          break;
        case "view_assignment":
          this.viewAssignmentDetail();
          break;
        case "notifications":
          this.navCtrl.push(NotificationListPage);
          break;

      }
    });
    events.subscribe('menu_item_clicked', (data) => {
      console.log("menu_item_clicked:-" + data);
      this.menuCtrl.close();
      switch (data) {
        case "profile":
          this.navCtrl.push(ProfilePage);
          break;
        case "assignment_enquiries":
          this.tab.select(0);
          break;
        case "assignment_in_process":
          this.tab.select(1);
          break;
        case "assignment_delivered":
          this.tab.select(2);
          break;
        case "assignment_expired":
          this.tab.select(3);
          break;
        case "new_assignment":
          this.newAssignment();
          break;
        case "setting":
          this.navCtrl.push(SettingPage);
          break;
        case "contact_us":
          this.navCtrl.push(ContactusPage);
          break;
      }
    });
  }

  openProfile():void{
    this.navCtrl.push(ProfilePage);
  }

  openMenu():void{
    console.log("open menu");
    this.menuCtrl.open();
  }

  newAssignment():void{
      this.navCtrl.push(NewAssignmentPage);
  }

  viewAssignmentDetail():void{
      this.navCtrl.push(AssignmentDetailsPage);
  }
  getItems(data){
    console.log("search data:-"+data);
  }


}
