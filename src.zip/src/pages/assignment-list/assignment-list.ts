import { Component } from '@angular/core';
import {Events, IonicPage, NavController, NavParams} from 'ionic-angular';

/**
 * Generated class for the AssignmentListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-assignment-list',
  templateUrl: 'assignment-list.html',
})
export class AssignmentListPage {

  items:string[]=[];
  showCards:boolean[]=[];

  constructor(public navCtrl: NavController, public navParams: NavParams,public events:Events) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AssignmentListPage');
    // this.items.push("");
    // this.items.push("");
    // this.items.push("");
    // this.items.push("");
    // this.items.push("");
    // this.items.push("");
    // this.items.push("");
    // this.items.push("");

    this.showCards.push(false);
    this.showCards.push(false);
    this.showCards.push(false);
    this.showCards.push(false);
    this.showCards.push(false);
    this.showCards.push(false);
    this.showCards.push(false);
    this.showCards.push(false);
    this.showCards.push(false);
    this.showCards.push(false);
    this.showCards.push(false);
  }

  openMenu():void{
    this.events.publish("tab_clicked","open_menu");
  }

  showCard(position):void{
    for(let i=0;i<this.showCards.length;i++){
        this.showCards[i]=false;
    }
    if(this.showCards[position]){
      this.showCards[position]=false;
    }else{
      this.showCards[position]=true;
    }
  }
  viewAssignment():void{
    this.events.publish('tab_clicked','view_assignment');
  }

  getItems(data){
    console.log("search data:-"+data);
  }

  openNotifications(){
    this.events.publish('tab_clicked','notifications');
  }

}

interface itemPOJO{
  show_card:boolean;
}
