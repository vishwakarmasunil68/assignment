import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AssignmentListPage } from './assignment-list';

@NgModule({
  declarations: [
    AssignmentListPage,
  ],
  imports: [
    IonicPageModule.forChild(AssignmentListPage),
  ],
})
export class AssignmentListPageModule {}
