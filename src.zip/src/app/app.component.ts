import { Component } from '@angular/core';
import {Events, Platform} from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';
import {LoginPage} from "../pages/login/login";
import {NewAssignmentPage} from "../pages/new-assignment/new-assignment";
import {ProfilePage} from "../pages/profile/profile";
import {AssignmentDetailsPage} from "../pages/assignment-details/assignment-details";
import {SettingPage} from "../pages/setting/setting";
import {NotificationListPage} from "../pages/notification-list/notification-list";
@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  rootPage:any = AssignmentDetailsPage;
  submenuVisible:boolean=false;

  constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen,public events:Events) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
      splashScreen.hide();
    });
  }

  menuClicked(data): void {
    console.log("menu item clicked:-"+data);
    this.events.publish('menu_item_clicked', data);
  }

  assignmentSubMenu():void{
    if(this.submenuVisible){
      this.submenuVisible=false;
    }else{
      this.submenuVisible=true;
    }
  }



}

