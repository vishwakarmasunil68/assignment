import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import {LoginPage} from "../pages/login/login";
import {AssignmentListPage} from "../pages/assignment-list/assignment-list";
import {ExpiredAssignmentListPage} from "../pages/expired-assignment-list/expired-assignment-list";
import {NewAssignmentPage} from "../pages/new-assignment/new-assignment";
import {ProfilePage} from "../pages/profile/profile";
import {AssignmentDetailsPage} from "../pages/assignment-details/assignment-details";
import {ContactusPage} from "../pages/contactus/contactus";
import {SettingPage} from "../pages/setting/setting";
import {ReportProblemPage} from "../pages/report-problem/report-problem";
import {PrivacyPolicyPage} from "../pages/privacy-policy/privacy-policy";
import {NotificationListPage} from "../pages/notification-list/notification-list";

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    LoginPage,
    AssignmentListPage,
    ExpiredAssignmentListPage,
    NewAssignmentPage,
    ProfilePage,
    AssignmentDetailsPage,
    ContactusPage,
    SettingPage,
    ReportProblemPage,
    PrivacyPolicyPage,
    NotificationListPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    LoginPage,
    AssignmentListPage,
    ExpiredAssignmentListPage,
    NewAssignmentPage,
    ProfilePage,
    AssignmentDetailsPage,
    ContactusPage,
    SettingPage,
    ReportProblemPage,
    PrivacyPolicyPage,
    NotificationListPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
