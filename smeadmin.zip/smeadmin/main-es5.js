function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function () { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (typeof call === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
  /***/
  "./$$_lazy_route_resource lazy recursive":
  /*!******************************************************!*\
    !*** ./$$_lazy_route_resource lazy namespace object ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function $$_lazy_route_resourceLazyRecursive(module, exports) {
    function webpackEmptyAsyncContext(req) {
      // Here Promise.resolve().then() is used instead of new Promise() to prevent
      // uncaught exception popping up in devtools
      return Promise.resolve().then(function () {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      });
    }

    webpackEmptyAsyncContext.keys = function () {
      return [];
    };

    webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
    module.exports = webpackEmptyAsyncContext;
    webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
  /*!**************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
    \**************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAppComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- <mat-toolbar style=\"background-color: #ffd900;\" class=\"example-toolbar\">\n\t<button mat-icon-button (click)=\"isExpanded = !isExpanded\" style=\"width: 30px; height: 30px; margin: 20px 20px 20px 10px ;\">\n    <mat-icon style=\"font-size: 20px; margin-bottom: 10px;\">menu</mat-icon>\n  </button>\n  <a routerLink=\"/\" title=\"Home\" rel=\"home\" class=\"site-logo\">\n    <img src=\"assets/logo.png\" style=\"margin-top: -8px; width: 80%\" alt=\"\" typeof=\"foaf:Image\">\n  </a>\n</mat-toolbar>\n<mat-sidenav-container class=\"example-container\" autosize>\n\t<mat-sidenav #sidenav class=\"example-sidenav\" mode=\"side\" opened=\"true\" (mouseenter)=\"mouseenter()\" (mouseleave)=\"mouseleave()\" style=\"background-color: rgb(199, 199, 199);\">\n\t\t<mat-nav-list>\n\t\t\t<mat-list-item (click)=\"showSubmenu = !showSubmenu\" class=\"parent\" routerLink=\"/customer\" routerLinkActive=\"active-list-item\">\n\t\t\t\t<span class=\"full-width\" *ngIf=\"isExpanded || isShowing\">Customer</span>\n\t\t\t\t<mat-icon mat-list-icon>supervised_user_circle</mat-icon>\n      </mat-list-item>\n      \n      <mat-list-item (click)=\"showSubmenu = !showSubmenu\" class=\"parent\" routerLink=\"/short-lead\" routerLinkActive=\"active-list-item\">\n\t\t\t\t<span class=\"full-width\" *ngIf=\"isExpanded || isShowing\">Short Lead</span>\n\t\t\t\t<mat-icon mat-list-icon>account_circle</mat-icon>\n     </mat-list-item>\n\t\t</mat-nav-list>\n    <mat-nav-list>\n</mat-nav-list>\n\t</mat-sidenav>\n\n\t<div class=\"example-sidenav-content\">\n\t\t<router-outlet></router-outlet>\n\t</div>\n\n</mat-sidenav-container> -->\n\n<router-outlet></router-outlet>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/customers/customers.component.html":
  /*!******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/customers/customers.component.html ***!
    \******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCustomersCustomersComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<mat-card>\n    <mat-card-content>\n        <p style=\"display: inline-block; font-size: 18px\">Time Frame:-</p>\n        <div style=\"display: flex; width: 100%;\">\n            <mat-form-field>\n                <mat-label>From</mat-label>\n                <input matInput [matDatepicker]=\"picker1\" [(ngModel)]=\"dateF\">\n                <mat-datepicker-toggle matSuffix [for]=\"picker1\"></mat-datepicker-toggle>\n                <mat-datepicker #picker1></mat-datepicker>\n            </mat-form-field>\n            &nbsp;\n            <mat-form-field>\n                <mat-label>To</mat-label>\n                <input matInput [matDatepicker]=\"picker2\" [(ngModel)]=\"dateT\">\n                <mat-datepicker-toggle matSuffix [for]=\"picker2\"></mat-datepicker-toggle>\n                <mat-datepicker #picker2></mat-datepicker>\n            </mat-form-field>\n            &nbsp; &nbsp;\n            <button mat-raised-button color=\"primary\" style=\"height: 40px;\" (click)=\"searchUsers()\">Search</button>\n            &nbsp;\n            <button mat-raised-button color=\"primary\" style=\"height: 40px;\" (click)=\"export()\">EXPORT</button>\n        </div>\n\n        <!--      for date picker-->\n        <!--      <form class=\"form-inline\">-->\n        <!--        <div class=\"form-group hidden\">-->\n        <!--          <div class=\"input-group\">-->\n        <!--            <input name=\"datepicker\"-->\n        <!--                   class=\"form-control\"-->\n        <!--                   ngbDatepicker-->\n        <!--                   #datepicker=\"ngbDatepicker\"-->\n        <!--                   [autoClose]=\"'outside'\"-->\n        <!--                   (dateSelect)=\"onDateSelection($event)\"-->\n        <!--                   [displayMonths]=\"2\"-->\n        <!--                   [dayTemplate]=\"t\"-->\n        <!--                   outsideDays=\"hidden\"-->\n        <!--                   [startDate]=\"fromDate!\">-->\n        <!--            <ng-template #t let-date let-focused=\"focused\">-->\n        <!--        <span class=\"custom-day\"-->\n        <!--              [class.focused]=\"focused\"-->\n        <!--              [class.range]=\"isRange(date)\"-->\n        <!--              [class.faded]=\"isHovered(date) || isInside(date)\"-->\n        <!--              (mouseenter)=\"hoveredDate = date\"-->\n        <!--              (mouseleave)=\"hoveredDate = null\">-->\n        <!--          {{ date.day }}-->\n        <!--        </span>-->\n        <!--            </ng-template>-->\n        <!--          </div>-->\n        <!--        </div>-->\n        <!--        <div class=\"form-group\">-->\n        <!--          <div class=\"input-group\">-->\n        <!--            <input #dpFromDate-->\n        <!--                   class=\"form-control\" placeholder=\"yyyy-mm-dd\"-->\n        <!--                   name=\"dpFromDate\"-->\n        <!--                   [(ngModel)]=\"from_date\"-->\n        <!--                   [value]=\"formatter.format(fromDate)\"-->\n        <!--                   (input)=\"fromDate = validateInput(fromDate, dpFromDate.value)\">-->\n        <!--            <div class=\"input-group-append\">-->\n        <!--              <button class=\"btn btn-outline-secondary calendar\" (click)=\"datepicker.toggle()\" type=\"button\"></button>-->\n        <!--            </div>-->\n        <!--          </div>-->\n        <!--        </div>-->\n        <!--        <div class=\"form-group ml-2\">-->\n        <!--          <div class=\"input-group\">-->\n        <!--            <input #dpToDate-->\n        <!--                   class=\"form-control\" placeholder=\"yyyy-mm-dd\"-->\n        <!--                   name=\"dpToDate\"-->\n        <!--                   [(ngModel)]=\"to_date\"-->\n        <!--                   [value]=\"formatter.format(toDate)\"-->\n        <!--                   (input)=\"toDate = validateInput(toDate, dpToDate.value)\">-->\n        <!--            <div class=\"input-group-append\">-->\n        <!--              <button class=\"btn btn-outline-secondary calendar\" (click)=\"datepicker.toggle()\" type=\"button\"></button>-->\n        <!--            </div>-->\n        <!--          </div>-->\n        <!--        </div>-->\n        <!--        &nbsp;&nbsp;-->\n        <!--        <button mat-raised-button color=\"primary\" (click)=\"searchUsers()\">Search</button>-->\n        <!--        &nbsp;&nbsp;-->\n        <!--        <button mat-raised-button color=\"primary\" (click)=\"export()\">EXPORT</button>-->\n        <!--      </form>-->\n\n        <hr/>\n        <!--      <pre>From date model: {{ fromDate | json }}</pre>-->\n        <!--      <pre>To date model: {{ toDate | json }}</pre>-->\n\n        <!--      for date picker-->\n\n        <div class=\"mat-elevation-z8\">\n            <table mat-table [dataSource]=\"dataSource\">\n\n                <!-- Position Column -->\n                <ng-container matColumnDef=\"user_id\">\n                    <th mat-header-cell *matHeaderCellDef> User Id</th>\n                    <td mat-cell *matCellDef=\"let element\"> {{element.user_id}} </td>\n                </ng-container>\n\n                <!-- Name Column -->\n                <ng-container matColumnDef=\"name\">\n                    <th mat-header-cell *matHeaderCellDef> Name</th>\n                    <td mat-cell *matCellDef=\"let element\"> {{element.name}} </td>\n                </ng-container>\n\n                <!-- Email Column -->\n                <ng-container matColumnDef=\"dob\">\n                    <th mat-header-cell *matHeaderCellDef> DOB</th>\n                    <td mat-cell *matCellDef=\"let element\"> {{element.dob}} </td>\n                </ng-container>\n\n                <!-- Phone Number Column -->\n                <ng-container matColumnDef=\"mobile\">\n                    <th mat-header-cell *matHeaderCellDef> Mobile</th>\n                    <td mat-cell *matCellDef=\"let element\"> {{element.mobile}} </td>\n                </ng-container>\n\n                <!-- Date Column -->\n                <ng-container matColumnDef=\"email_id\">\n                    <th mat-header-cell *matHeaderCellDef> Email Id</th>\n                    <td mat-cell *matCellDef=\"let element\"> {{element.email_id}} </td>\n                </ng-container>\n\n                <ng-container matColumnDef=\"company_name\">\n                    <th mat-header-cell *matHeaderCellDef> Company Name</th>\n                    <td mat-cell *matCellDef=\"let element\"> {{element.company_name}} </td>\n                </ng-container>\n\n                <ng-container matColumnDef=\"city\">\n                    <th mat-header-cell *matHeaderCellDef> City</th>\n                    <td mat-cell *matCellDef=\"let element\"> {{element.city}} </td>\n                </ng-container>\n\n                <!-- <ng-container matColumnDef=\"actions\">\n                  <th  *matHeaderCellDef style=\"background-color: #ffd900;\"> Actions </th>\n                  <td *matCellDef=\"let row\" >\n                       <button mat-button >Edit</button>\n                       <button mat-button >Edit</button>\n                  </td>\n                </ng-container> -->\n\n                <!-- Get Details -->\n                <ng-container matColumnDef=\"actions\">\n                    <th mat-header-cell *matHeaderCellDef style=\"background-color: #ffd900\"> Details</th>\n                    <td mat-cell *matCellDef=\"let element\">\n                        <button mat-raised-button color=\"primary\" (click)=\"getRecord(element.user_id,element.name)\"\n                                style=\"font-size: 10px; width: 2em;\">PDF\n                        </button> &nbsp;\n                        <button mat-raised-button (click)=\"openDialog(element)\">\n                            <mat-icon>\n                                <img src=\"./assets/visibility-24px.svg\">\n                            </mat-icon>\n                        </button>\n                    </td>\n                </ng-container>\n                <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n                <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>\n            </table>\n            <mat-paginator [pageSizeOptions]=\"[5, 10, 20]\" showFirstLastButtons></mat-paginator>\n        </div>\n    </mat-card-content>\n</mat-card>\n\n\n<!-- <table class=\"table table-bordered\" *ngFor=\"let user of aUser\">\n  <thead>\n    <tr>\n      <th scope=\"col\">#</th>\n      <th scope=\"col\">{{user.name}}</th>\n      <th scope=\"col\">Last</th>\n      <th scope=\"col\">Handle</th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr>\n      <th scope=\"row\">1</th>\n      <td>Mark</td>\n      <td>Otto</td>\n      <td>@mdo</td>\n    </tr>\n    <tr>\n      <th scope=\"row\">2</th>\n      <td>Jacob</td>\n      <td>Thornton</td>\n      <td>@fat</td>\n    </tr>\n    <tr>\n      <th scope=\"row\">3</th>\n      <td colspan=\"2\">Larry the Bird</td>\n      <td>@twitter</td>\n    </tr>\n  </tbody>\n</table> -->\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/layout/layout.component.html":
  /*!************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/layout/layout.component.html ***!
    \************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppLayoutLayoutComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<mat-toolbar style=\"background-color: #ffd900;\" class=\"example-toolbar\">\n\t<button mat-icon-button (click)=\"isExpanded = !isExpanded\" style=\"width: 30px; height: 30px; margin: 20px 20px 20px 10px ;\">\n    <mat-icon style=\"font-size: 20px; margin-bottom: 10px;\">\n        <img src=\"./assets/menu-24px.svg\">\n    </mat-icon>\n  </button>\n  <!-- <h1 class=\"example-app-name\">Nested Menus</h1> -->\n  <a title=\"Home\" rel=\"home\" class=\"site-logo\">\n<!--    <img src=\"assets/logo.png\" style=\"margin-top: -8px; width: 80%\" alt=\"\" typeof=\"foaf:Image\">-->\n    <h2 style=\"color: #052d92\">Aviva SME Admin Panel</h2>\n  </a>\n</mat-toolbar>\n<mat-sidenav-container class=\"example-container\" autosize>\n\t<mat-sidenav #sidenav class=\"example-sidenav\" mode=\"side\" opened=\"true\" (mouseenter)=\"mouseenter()\" (mouseleave)=\"mouseleave()\" style=\"background-color: aliceblue;\">\n\t\t<mat-nav-list>\n\t\t\t<mat-list-item (click)=\"showSubmenu = !showSubmenu\" class=\"parent\" routerLink=\"/layout/customer\" routerLinkActive=\"active-list-item\">\n                <img src=\"./assets/supervised_user_circle-24px.svg\">\n                <span class=\"full-width\" *ngIf=\"isExpanded || isShowing\">Customer</span>\n<!--\t\t\t\t<mat-icon mat-list-icon>supervised_user_circle</mat-icon>-->\n\t\t\t\t<!-- <mat-icon class=\"menu-button\" [ngClass]=\"{'rotated' : showSubmenu}\" *ngIf=\"isExpanded || isShowing\">expand_more</mat-icon> -->\n      </mat-list-item>\n\n      <mat-list-item (click)=\"showSubmenu = !showSubmenu\" class=\"parent\" routerLink=\"/layout/short-lead\" routerLinkActive=\"active-list-item\">\n          <img src=\"./assets/account_circle-24px.svg\">\n          <span class=\"full-width\" *ngIf=\"isExpanded || isShowing\">Short Lead</span>\n<!--\t\t\t\t<mat-icon mat-list-icon>account_circle</mat-icon>-->\n\t\t\t\t<!-- <mat-icon class=\"menu-button\" [ngClass]=\"{'rotated' : showSubmenu}\" *ngIf=\"isExpanded || isShowing\">expand_more</mat-icon> -->\n      </mat-list-item>\n\n      <mat-list-item (click)=\"showSubmenu = !showSubmenu\" class=\"parent\" (click)=\"logoutUser()\" routerLinkActive=\"active-list-item\">\n          <img src=\"./assets/close-24px.svg\">\n          <span class=\"full-width\" *ngIf=\"isExpanded || isShowing\">Log out</span>\n<!--        <mat-icon mat-list-icon>close</mat-icon>-->\n        <!-- <mat-icon class=\"menu-button\" [ngClass]=\"{'rotated' : showSubmenu}\" *ngIf=\"isExpanded || isShowing\">expand_more</mat-icon> -->\n      </mat-list-item>\n\n\t\t\t<!-- <div class=\"submenu\" [ngClass]=\"{'expanded' : showSubmenu}\" *ngIf=\"isShowing || isExpanded\">\n\t\t\t\t<a mat-list-item href=\"...\">Submenu Item 1</a>\n\t\t\t\t<a mat-list-item href=\"...\">Submenu Item 2</a>\n\t\t\t\t<mat-list-item (click)=\"showSubSubMenu = !showSubSubMenu\" class=\"parent\">\n\t\t\t\t\t<span class=\"full-width\" *ngIf=\"isExpanded || isShowing\">Nested Menu</span>\n\t\t\t\t\t<mat-icon class=\"menu-button\" [ngClass]=\"{'rotated' : showSubSubMenu}\" *ngIf=\"isExpanded || isShowing\">expand_more</mat-icon>\n\t\t\t\t</mat-list-item>\n\t\t\t\t<div class=\"submenu\" [ngClass]=\"{'expanded' : showSubSubMenu}\" *ngIf=\"isShowing || isExpanded\">\n\t\t\t\t\t<mat-list-item>SubSubmenu Item 1</mat-list-item>\n\t\t\t\t\t<mat-list-item>SubSubmenu Item 2</mat-list-item>\n\t\t\t\t</div>\n\t\t\t</div> -->\n\t\t</mat-nav-list>\n    <mat-nav-list>\n</mat-nav-list>\n\t</mat-sidenav>\n\n\t<div class=\"example-sidenav-content\">\n\t\t<router-outlet></router-outlet>\n\t</div>\n\n</mat-sidenav-container>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.component.html":
  /*!**********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.component.html ***!
    \**********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppLoginLoginComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div style=\"background-color: grey; width: 100%; height: 100%;\" >\n\n    <mat-toolbar style=\"background-color: #ffd900;\" class=\"example-toolbar\">\n        <a routerLink=\"/\" title=\"Home\" rel=\"home\" class=\"site-logo\">\n          <img src=\"assets/logo.png\" style=\"margin-top: -8px; width: 80%\" alt=\"\" typeof=\"foaf:Image\">\n        </a>\n      </mat-toolbar>\n\n      <div>\n\n          <div class=\"login-page\">\n              <div class=\"form\">\n\n                <div style=\"width: 50%; padding-bottom: 20px; margin-top: -20px; display: block;\n                margin-left: auto;\n                margin-right: auto;\">\n                    <img src=\"assets/sme_login.png\" alt=\"\">\n                </div>\n\n\n                <form class=\"register-form\">\n                  <input type=\"text\" placeholder=\"name\"/>\n                  <input type=\"password\" placeholder=\"password\"/>\n                  <input type=\"text\" placeholder=\"email address\"/>\n                  <button>create</button>\n                  <p class=\"message\">Already registered? <a href=\"#\">Sign In</a></p>\n                </form>\n                <form class=\"login-form\">\n<!--                  <input type=\"text\" placeholder=\"username\"/>-->\n<!--                  <input type=\"password\" placeholder=\"password\"/>-->\n<!--                  <button routerLink=\"/layout/customer\">login</button>-->\n\n                  <input [(ngModel)]=\"user_name\" autocomplete=\"off\" [ngModelOptions]=\"{standalone: true}\" type=\"text\" placeholder=\"username\"/>\n                  <input [(ngModel)]=\"password\" autocomplete=\"off\" [ngModelOptions]=\"{standalone: true}\" type=\"password\" placeholder=\"password\"/>\n                  <button (click)=\"setBaseURL()\">login</button>\n                  <!-- <p class=\"message\">Not registered? <a href=\"#\">Create an account</a></p> -->\n                </form>\n              </div>\n            </div>\n\n\n      </div>\n\n</div>\n\n<router-outlet></router-outlet>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/question-modal/question-modal.component.html":
  /*!****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/question-modal/question-modal.component.html ***!
    \****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppQuestionModalQuestionModalComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<h2 mat-dialog-title>Questions</h2>\n<mat-dialog-content class=\"mat-typography\">\n  <mat-tab-group>\n\n    <mat-tab label=\"Register\">\n      <mat-card>\n        <mat-card-content style=\"\">\n\n          <table class=\"table table-bordered\">\n            <thead>\n            </thead>\n            <tbody>\n            <tr>\n              <td style=\"width: 10px;\">Q1.</td>\n              <td>Name</td>\n              <td>{{user.name}}</td>\n            </tr>\n            <tr>\n              <td style=\"width: 10px;\">Q2.</td>\n              <td>Date of Birth</td>\n              <td>{{user.dob}}</td>\n            </tr>\n            <tr>\n              <td style=\"width: 10px;\">Q3.</td>\n              <td>Mobile Number</td>\n              <td>{{user.mobile}}</td>\n            </tr>\n            <tr>\n              <td style=\"width: 10px;\">Q4.</td>\n              <td>Email ID</td>\n              <td>{{user.email_id}}</td>\n            </tr>\n            <tr>\n              <td style=\"width: 10px;\">Q5.</td>\n              <td>Company Name</td>\n              <td>{{user.company_name}}</td>\n            </tr>\n            <tr>\n              <td style=\"width: 10px;\">Q6.</td>\n              <td>City</td>\n              <td>{{user.city}}</td>\n            </tr>\n            <tr>\n              <td style=\"width: 10px;\">Q7.</td>\n              <td>Aviva Employee Id</td>\n              <td>{{user.aviva_emp_id}}</td>\n            </tr>\n            </tbody>\n          </table>\n        </mat-card-content>\n      </mat-card>\n    </mat-tab>\n\n    <mat-tab label=\"Business Owner\">\n      <mat-card>\n        <mat-card-content style=\"\">\n          <table class=\"table table-bordered\">\n            <thead>\n            </thead>\n            <tbody>\n            <tr>\n              <td style=\"width: 10px;\">Q1.</td>\n              <td>Q1. How is your company structured?</td>\n              <td>{{user.business.q1}}</td>\n            </tr>\n            <tr>\n              <td style=\"width: 10px;\">Q1a.</td>\n              <td>Q1a. What is the partnerwise shareholding?</td>\n              <td>{{user.business.q1a}}</td>\n            </tr>\n            <tr>\n              <td style=\"width: 10px;\">Q2.</td>\n              <td>Q2. What is the annual turnover of your company?</td>\n              <td>{{user.business.q2}}</td>\n            </tr>\n            <tr>\n              <td style=\"width: 10px;\">Q3.</td>\n              <td>Q3. What is the total value of assets of your company?</td>\n              <td>{{user.business.q3}}</td>\n            </tr>\n            <tr>\n              <td style=\"width: 10px;\">Q4.</td>\n              <td>Q4. Are you planning any business expansion in the next 5 years?</td>\n              <td>{{user.business.q4}}</td>\n            </tr>\n            <tr>\n              <td style=\"width: 10px;\">Q5.</td>\n              <td>Q5. Have you taken any loans for your business? If yes, for what purpose?</td>\n              <td>{{user.business.q5}}</td>\n            </tr>\n            <tr>\n              <td style=\"width: 10px;\">Q5a.</td>\n              <td>Q5a. What is your current unsecured loan outstanding? (In Rs. Lacs)</td>\n              <td>{{user.business.q5a}}</td>\n            </tr>\n            </tbody>\n          </table>\n\n\n          <!--          <div>-->\n          <!--            <p>Q1. How is your company structured?</p>-->\n          <!--            <hr>-->\n          <!--            <p>Q2. What is the annual turnover of your company?</p>-->\n          <!--            <hr>-->\n          <!--            <p>Q3. What is the total value of assets of your company?</p>-->\n          <!--            <hr>-->\n          <!--            <p>Q4. Are you planning any business expansion in the next 5 years?</p>-->\n          <!--            <hr>-->\n          <!--            <p>Q5. Have you taken any loans for your business? If yes, for what purpose?</p>-->\n          <!--          </div>-->\n        </mat-card-content>\n      </mat-card>\n    </mat-tab>\n\n    <mat-tab label=\"Employer\">\n      <mat-card>\n        <mat-card-content style=\"\">\n          <div>\n            <table class=\"table table-bordered\">\n              <thead>\n              </thead>\n              <tbody>\n              <tr>\n                <td style=\"width: 10px;\">Q1.</td>\n                <td>How many on roll employees do you have?</td>\n                <td>{{user.employee.q1}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q2.</td>\n                <td>How many of your current employees are critical to the business (key people)?</td>\n                <td>{{user.employee.q2}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q3.</td>\n                <td>When Key Employees leave, is it a challenge for your business?</td>\n                <td>{{user.employee.q3}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q4.</td>\n                <td>What business insurance solutions have you opted for?</td>\n                <td>{{user.employee.q4}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q5.</td>\n                <td>Have you made provisions for gratuity for your employees?</td>\n                <td>{{user.employee.q5}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q6.</td>\n                <td>Do your employees have a PF facility? If yes, have you opted for an EDLI scheme?</td>\n                <td>{{user.employee.q6}}</td>\n              </tr>\n              </tbody>\n            </table>\n\n          </div>\n        </mat-card-content>\n      </mat-card>\n    </mat-tab>\n\n    <mat-tab label=\"Head of the Family\">\n      <mat-card>\n        <mat-card-content style=\"\">\n          <div>\n            <table class=\"table table-bordered\">\n              <thead>\n              </thead>\n              <tbody>\n              <tr>\n                <td style=\"width: 10px;\">Q1.</td>\n                <td>Describe your immediate family/dependents.</td>\n                <td>{{user.hof.q1}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q2.</td>\n                <td>What is your current life insurance cover? (In Lacs)</td>\n                <td>{{user.hof.q2}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q3.</td>\n                <td>Have you purchased any Insurance Plan under MWP Act to protect your family?</td>\n                <td>{{user.hof.q3}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q4.</td>\n                <td>What is your annual income? (In lacs)</td>\n                <td>{{user.hof.q4}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q5.</td>\n                <td>What is the approximate fluctuation in your annual income?</td>\n                <td>{{user.hof.q5}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q6.</td>\n                <td>When your income is lower, how do you manage family expenses?</td>\n                <td>{{user.hof.q6}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q7.</td>\n                <td>Have you made any specific investments for your family?</td>\n                <td>{{user.hof.q7}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q8.</td>\n                <td>How prepared is your family to manage household expenses in case of any unfortunate event?</td>\n                <td>{{user.hof.q8}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q9.</td>\n                <td>Quality education is very expensive. Have you started planning for your child/children’s education?</td>\n                <td>{{user.hof.q9}}</td>\n              </tr>\n              <tr>\n                <td style=\"width: 10px;\">Q10.</td>\n                <td>Have you planned for your retirement years?</td>\n                <td>{{user.hof.q10}}</td>\n              </tr>\n\n              </tbody>\n            </table>\n          </div>\n        </mat-card-content>\n      </mat-card>\n    </mat-tab>\n  </mat-tab-group>\n</mat-dialog-content>\n<mat-dialog-actions align=\"end\">\n  <!-- <button mat-button mat-dialog-close>Cancel</button> -->\n  <button mat-button [mat-dialog-close]=\"true\" cdkFocusInitial>OK</button>\n</mat-dialog-actions>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/short-lead/short-lead.component.html":
  /*!********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/short-lead/short-lead.component.html ***!
    \********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppShortLeadShortLeadComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<mat-card>\n  <mat-card-content>\n    <p style=\"display: inline; font-size: 18px\">Time Frame:-</p>\n\n\n      <div style=\"display: flex; width: 100%;\">\n          <mat-form-field>\n              <mat-label>From</mat-label>\n              <input matInput [matDatepicker]=\"picker1\" [(ngModel)]=\"dateF\">\n              <mat-datepicker-toggle matSuffix [for]=\"picker1\"></mat-datepicker-toggle>\n              <mat-datepicker #picker1></mat-datepicker>\n          </mat-form-field>\n          &nbsp;\n          <mat-form-field>\n              <mat-label>To</mat-label>\n              <input matInput [matDatepicker]=\"picker2\" [(ngModel)]=\"dateT\">\n              <mat-datepicker-toggle matSuffix [for]=\"picker2\"></mat-datepicker-toggle>\n              <mat-datepicker #picker2></mat-datepicker>\n          </mat-form-field>\n          &nbsp; &nbsp;\n          <button mat-raised-button color=\"primary\" style=\"height: 40px;\" (click)=\"searchUsers()\">Search</button>\n          &nbsp;\n          <button mat-raised-button color=\"primary\" style=\"height: 40px;\" (click)=\"export()\">EXPORT</button>\n      </div>\n\n\n    <!--      for date picker-->\n<!--    <form class=\"form-inline\">-->\n<!--      <div class=\"form-group hidden\">-->\n<!--        <div class=\"input-group\">-->\n<!--          <input name=\"datepicker\"-->\n<!--                 class=\"form-control\"-->\n<!--                 ngbDatepicker-->\n<!--                 #datepicker=\"ngbDatepicker\"-->\n<!--                 [autoClose]=\"'outside'\"-->\n<!--                 (dateSelect)=\"onDateSelection($event)\"-->\n<!--                 [displayMonths]=\"2\"-->\n<!--                 [dayTemplate]=\"t\"-->\n<!--                 outsideDays=\"hidden\"-->\n<!--                 [startDate]=\"fromDate!\">-->\n<!--          <ng-template #t let-date let-focused=\"focused\">-->\n<!--        <span class=\"custom-day\"-->\n<!--              [class.focused]=\"focused\"-->\n<!--              [class.range]=\"isRange(date)\"-->\n<!--              [class.faded]=\"isHovered(date) || isInside(date)\"-->\n<!--              (mouseenter)=\"hoveredDate = date\"-->\n<!--              (mouseleave)=\"hoveredDate = null\">-->\n<!--          {{ date.day }}-->\n<!--        </span>-->\n<!--          </ng-template>-->\n<!--        </div>-->\n<!--      </div>-->\n<!--      <div class=\"form-group\">-->\n<!--        <div class=\"input-group\">-->\n<!--          <input #dpFromDate-->\n<!--                 class=\"form-control\" placeholder=\"yyyy-mm-dd\"-->\n<!--                 name=\"dpFromDate\"-->\n<!--                 [(ngModel)]=\"from_date\"-->\n<!--                 [value]=\"formatter.format(fromDate)\"-->\n<!--                 (input)=\"fromDate = validateInput(fromDate, dpFromDate.value)\">-->\n<!--          <div class=\"input-group-append\">-->\n<!--            <button class=\"btn btn-outline-secondary calendar\" (click)=\"datepicker.toggle()\" type=\"button\"></button>-->\n<!--          </div>-->\n<!--        </div>-->\n<!--      </div>-->\n<!--      <div class=\"form-group ml-2\">-->\n<!--        <div class=\"input-group\">-->\n<!--          <input #dpToDate-->\n<!--                 class=\"form-control\" placeholder=\"yyyy-mm-dd\"-->\n<!--                 name=\"dpToDate\"-->\n<!--                 [(ngModel)]=\"to_date\"-->\n<!--                 [value]=\"formatter.format(toDate)\"-->\n<!--                 (input)=\"toDate = validateInput(toDate, dpToDate.value)\">-->\n<!--          <div class=\"input-group-append\">-->\n<!--            <button class=\"btn btn-outline-secondary calendar\" (click)=\"datepicker.toggle()\" type=\"button\"></button>-->\n<!--          </div>-->\n<!--        </div>-->\n<!--      </div>-->\n<!--      &nbsp;&nbsp;-->\n<!--      <button mat-raised-button color=\"primary\" (click)=\"searchUsers()\">Search</button>-->\n<!--      &nbsp;&nbsp;-->\n<!--      <button mat-raised-button color=\"primary\" (click)=\"getSheet()\">EXPORT</button>-->\n<!--    </form>-->\n\n    <hr/>\n    <!--      <pre>From date model: {{ fromDate | json }}</pre>-->\n    <!--      <pre>To date model: {{ toDate | json }}</pre>-->\n\n    <!--      for date picker-->\n\n\n    <div class=\"mat-elevation-z8\">\n      <table mat-table [dataSource]=\"dataSource\">\n\n        <!-- Position Column -->\n        <ng-container matColumnDef=\"position\">\n          <th mat-header-cell *matHeaderCellDef> User Id</th>\n          <td mat-cell *matCellDef=\"let element\"> {{element.user_id}} </td>\n        </ng-container>\n\n        <!-- Name Column -->\n        <ng-container matColumnDef=\"name\">\n          <th mat-header-cell *matHeaderCellDef> Name</th>\n          <td mat-cell *matCellDef=\"let element\"> {{element.name}} </td>\n        </ng-container>\n\n        <!-- Date Column -->\n        <ng-container matColumnDef=\"DOB\">\n          <th mat-header-cell *matHeaderCellDef> DOB</th>\n          <td mat-cell *matCellDef=\"let element\"> {{element.dob}} </td>\n        </ng-container>\n\n\n        <!-- Phone Number Column -->\n        <ng-container matColumnDef=\"phone_number\">\n          <th mat-header-cell *matHeaderCellDef> Mobile</th>\n          <td mat-cell *matCellDef=\"let element\"> {{element.mobile}} </td>\n        </ng-container>\n\n        <!-- Email Column -->\n        <ng-container matColumnDef=\"email\">\n          <th mat-header-cell *matHeaderCellDef> Email</th>\n          <td mat-cell *matCellDef=\"let element\"> {{element.email_id}} </td>\n        </ng-container>\n        <!-- Email Column -->\n        <ng-container matColumnDef=\"Company_name\">\n          <th mat-header-cell *matHeaderCellDef> Company Name</th>\n          <td mat-cell *matCellDef=\"let element\"> {{element.company_name}} </td>\n        </ng-container>\n        <!-- Email Column -->\n        <ng-container matColumnDef=\"city\">\n          <th mat-header-cell *matHeaderCellDef> City</th>\n          <td mat-cell *matCellDef=\"let element\"> {{element.city}} </td>\n        </ng-container>\n\n\n        <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n        <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>\n      </table>\n\n      <mat-paginator [pageSizeOptions]=\"[5, 10, 20]\" showFirstLastButtons></mat-paginator>\n    </div>\n  </mat-card-content>\n</mat-card>\n";
    /***/
  },

  /***/
  "./node_modules/tslib/tslib.es6.js":
  /*!*****************************************!*\
    !*** ./node_modules/tslib/tslib.es6.js ***!
    \*****************************************/

  /*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __createBinding, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault, __classPrivateFieldGet, __classPrivateFieldSet */

  /***/
  function node_modulesTslibTslibEs6Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__extends", function () {
      return __extends;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__assign", function () {
      return _assign;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__rest", function () {
      return __rest;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__decorate", function () {
      return __decorate;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__param", function () {
      return __param;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__metadata", function () {
      return __metadata;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__awaiter", function () {
      return __awaiter;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__generator", function () {
      return __generator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__createBinding", function () {
      return __createBinding;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__exportStar", function () {
      return __exportStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__values", function () {
      return __values;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__read", function () {
      return __read;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spread", function () {
      return __spread;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spreadArrays", function () {
      return __spreadArrays;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__await", function () {
      return __await;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function () {
      return __asyncGenerator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function () {
      return __asyncDelegator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncValues", function () {
      return __asyncValues;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function () {
      return __makeTemplateObject;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importStar", function () {
      return __importStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importDefault", function () {
      return __importDefault;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__classPrivateFieldGet", function () {
      return __classPrivateFieldGet;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__classPrivateFieldSet", function () {
      return __classPrivateFieldSet;
    });
    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.
    
    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.
    
    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */

    /* global Reflect, Promise */


    var _extendStatics = function extendStatics(d, b) {
      _extendStatics = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function (d, b) {
        d.__proto__ = b;
      } || function (d, b) {
        for (var p in b) {
          if (b.hasOwnProperty(p)) d[p] = b[p];
        }
      };

      return _extendStatics(d, b);
    };

    function __extends(d, b) {
      _extendStatics(d, b);

      function __() {
        this.constructor = d;
      }

      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var _assign = function __assign() {
      _assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];

          for (var p in s) {
            if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
          }
        }

        return t;
      };

      return _assign.apply(this, arguments);
    };

    function __rest(s, e) {
      var t = {};

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
      }

      if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
      }
      return t;
    }

    function __decorate(decorators, target, key, desc) {
      var c = arguments.length,
          r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
          d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      }
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
      return function (target, key) {
        decorator(target, key, paramIndex);
      };
    }

    function __metadata(metadataKey, metadataValue) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function (resolve) {
          resolve(value);
        });
      }

      return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }

        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }

        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }

        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    }

    function __generator(thisArg, body) {
      var _ = {
        label: 0,
        sent: function sent() {
          if (t[0] & 1) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      },
          f,
          y,
          t,
          g;
      return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
      }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
        return this;
      }), g;

      function verb(n) {
        return function (v) {
          return step([n, v]);
        };
      }

      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");

        while (_) {
          try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];

            switch (op[0]) {
              case 0:
              case 1:
                t = op;
                break;

              case 4:
                _.label++;
                return {
                  value: op[1],
                  done: false
                };

              case 5:
                _.label++;
                y = op[1];
                op = [0];
                continue;

              case 7:
                op = _.ops.pop();

                _.trys.pop();

                continue;

              default:
                if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                  _ = 0;
                  continue;
                }

                if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                  _.label = op[1];
                  break;
                }

                if (op[0] === 6 && _.label < t[1]) {
                  _.label = t[1];
                  t = op;
                  break;
                }

                if (t && _.label < t[2]) {
                  _.label = t[2];

                  _.ops.push(op);

                  break;
                }

                if (t[2]) _.ops.pop();

                _.trys.pop();

                continue;
            }

            op = body.call(thisArg, _);
          } catch (e) {
            op = [6, e];
            y = 0;
          } finally {
            f = t = 0;
          }
        }

        if (op[0] & 5) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    }

    function __createBinding(o, m, k, k2) {
      if (k2 === undefined) k2 = k;
      o[k2] = m[k];
    }

    function __exportStar(m, exports) {
      for (var p in m) {
        if (p !== "default" && !exports.hasOwnProperty(p)) exports[p] = m[p];
      }
    }

    function __values(o) {
      var s = typeof Symbol === "function" && Symbol.iterator,
          m = s && o[s],
          i = 0;
      if (m) return m.call(o);
      if (o && typeof o.length === "number") return {
        next: function next() {
          if (o && i >= o.length) o = void 0;
          return {
            value: o && o[i++],
            done: !o
          };
        }
      };
      throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
      var m = typeof Symbol === "function" && o[Symbol.iterator];
      if (!m) return o;
      var i = m.call(o),
          r,
          ar = [],
          e;

      try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) {
          ar.push(r.value);
        }
      } catch (error) {
        e = {
          error: error
        };
      } finally {
        try {
          if (r && !r.done && (m = i["return"])) m.call(i);
        } finally {
          if (e) throw e.error;
        }
      }

      return ar;
    }

    function __spread() {
      for (var ar = [], i = 0; i < arguments.length; i++) {
        ar = ar.concat(__read(arguments[i]));
      }

      return ar;
    }

    function __spreadArrays() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++) {
        s += arguments[i].length;
      }

      for (var r = Array(s), k = 0, i = 0; i < il; i++) {
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) {
          r[k] = a[j];
        }
      }

      return r;
    }

    ;

    function __await(v) {
      return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var g = generator.apply(thisArg, _arguments || []),
          i,
          q = [];
      return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i;

      function verb(n) {
        if (g[n]) i[n] = function (v) {
          return new Promise(function (a, b) {
            q.push([n, v, a, b]) > 1 || resume(n, v);
          });
        };
      }

      function resume(n, v) {
        try {
          step(g[n](v));
        } catch (e) {
          settle(q[0][3], e);
        }
      }

      function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
      }

      function fulfill(value) {
        resume("next", value);
      }

      function reject(value) {
        resume("throw", value);
      }

      function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
      }
    }

    function __asyncDelegator(o) {
      var i, p;
      return i = {}, verb("next"), verb("throw", function (e) {
        throw e;
      }), verb("return"), i[Symbol.iterator] = function () {
        return this;
      }, i;

      function verb(n, f) {
        i[n] = o[n] ? function (v) {
          return (p = !p) ? {
            value: __await(o[n](v)),
            done: n === "return"
          } : f ? f(v) : v;
        } : f;
      }
    }

    function __asyncValues(o) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var m = o[Symbol.asyncIterator],
          i;
      return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i);

      function verb(n) {
        i[n] = o[n] && function (v) {
          return new Promise(function (resolve, reject) {
            v = o[n](v), settle(resolve, reject, v.done, v.value);
          });
        };
      }

      function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function (v) {
          resolve({
            value: v,
            done: d
          });
        }, reject);
      }
    }

    function __makeTemplateObject(cooked, raw) {
      if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", {
          value: raw
        });
      } else {
        cooked.raw = raw;
      }

      return cooked;
    }

    ;

    function __importStar(mod) {
      if (mod && mod.__esModule) return mod;
      var result = {};
      if (mod != null) for (var k in mod) {
        if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
      }
      result["default"] = mod;
      return result;
    }

    function __importDefault(mod) {
      return mod && mod.__esModule ? mod : {
        "default": mod
      };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
      if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
      }

      return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
      if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to set private field on non-instance");
      }

      privateMap.set(receiver, value);
      return value;
    }
    /***/

  },

  /***/
  "./src/app/BaseComp.ts":
  /*!*****************************!*\
    !*** ./src/app/BaseComp.ts ***!
    \*****************************/

  /*! exports provided: BaseComp */

  /***/
  function srcAppBaseCompTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BaseComp", function () {
      return BaseComp;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var BaseComp = /*#__PURE__*/function () {
      function BaseComp() {
        _classCallCheck(this, BaseComp);

        this.BASE_URL = "BASE_URL";
        this.LOGIN_FAILED_TIMES = "LOGIN_FAILED_TIMES"; // LOGIN_URL = this.getItem(this.BASE_URL) + "index.php/api/User/checkAdminLogin";
        // GET_ALL_USERS = this.getItem(this.BASE_URL) + "index.php/api/User/getAllUsers";
        // OPEN_PDF = this.getItem(this.BASE_URL) + "angular_pdf/pdf.php?user_id=";
        // GET_ALL_USER_EXCEL = this.getItem(this.BASE_URL) + "index.php/api/User/getAllUsersExcel";
        // GET_ALL_SHORT_LEAD = this.getItem(this.BASE_URL) + "index.php/api/User/getShortLeadExcel";

        this.LOGIN_URL = "index.php/api/User/checkAdminLogin";
        this.GET_ALL_USERS = "index.php/api/User/getAllUsers"; // OPEN_PDF = "angular_pdf/pdf.php?user_id=";

        this.OPEN_PDF = "angular_pdf/pdf.php";
        this.GET_ALL_USER_EXCEL = "index.php/api/User/getAllUsersExcel";
        this.GET_ALL_SHORT_LEAD = "index.php/api/User/getShortLeadExcel";
        this.IS_USER_LOGIN = "IS_USER_LOGIN"; // getItem(key: string): string {
        //     return window.localStorage.getItem(key);
        // }
        //
        // setItem(key: string, value: string) {
        //     window.localStorage.setItem(key, value);
        // }
      }

      _createClass(BaseComp, [{
        key: "getSessionStoredItem",
        value: function getSessionStoredItem(key) {
          return window.sessionStorage.getItem(key);
        }
      }, {
        key: "getLoginFailedPref",
        value: function getLoginFailedPref() {
          var login_failed = window.localStorage.getItem("login_failed");

          if (login_failed == '' || login_failed == undefined || login_failed == null) {
            return 0;
          } else {
            return parseInt(login_failed);
          }
        }
      }, {
        key: "increaseLoginFailedPref",
        value: function increaseLoginFailedPref() {
          window.localStorage.setItem("login_failed", (this.getLoginFailedPref() + 1).toString());
          this.setLastLoginTime();
        }
      }, {
        key: "setLastLoginTime",
        value: function setLastLoginTime() {
          window.localStorage.setItem("last_login_time", this.setDate() + " " + this.setTime());
        }
      }, {
        key: "getLastLoginTime",
        value: function getLastLoginTime() {
          return window.localStorage.getItem("last_login_time");
        }
      }, {
        key: "resetLoginFailed",
        value: function resetLoginFailed() {
          window.localStorage.setItem("login_failed", "0");
        }
      }, {
        key: "setSessionStoredItem",
        value: function setSessionStoredItem(key, value) {
          window.sessionStorage.setItem(key, value);
        }
      }, {
        key: "getDifferenceBetweenTwoDatesInMin",
        value: function getDifferenceBetweenTwoDatesInMin(startTime, endTime) {
          // var startTime = new Date(date1);
          // var endTime = new Date(date2);
          var difference = endTime.getTime() - startTime.getTime(); // This will give difference in milliseconds

          var resultInMinutes = Math.round(difference / 60000);
          return resultInMinutes;
        }
      }, {
        key: "setDate",
        value: function setDate() {
          var d = new Date();
          var date = this.properFormatNumber(d.getDate());
          var month = this.properFormatNumber(d.getMonth() + 1);
          var year = d.getFullYear();
          var finalDate = year + '-' + month + '-' + date;
          return finalDate;
        }
      }, {
        key: "setTime",
        value: function setTime() {
          var d = new Date();
          var hour = this.properFormatNumber(d.getHours());
          var minutes = this.properFormatNumber(d.getMinutes() + 1);
          var sec = this.properFormatNumber(d.getSeconds() + 1);
          var year = d.getFullYear();
          var finalDate = hour + ':' + minutes + ':' + sec;
          return finalDate;
        }
      }, {
        key: "properFormatNumber",
        value: function properFormatNumber(number) {
          var numString = '';

          if (number < 10) {
            numString = '0' + number;
          } else {
            numString = number + '';
          }

          return numString;
        }
      }]);

      return BaseComp;
    }();
    /***/

  },

  /***/
  "./src/app/aes-encryption-decryption.service.ts":
  /*!******************************************************!*\
    !*** ./src/app/aes-encryption-decryption.service.ts ***!
    \******************************************************/

  /*! exports provided: AesEncryptionDecryptionService */

  /***/
  function srcAppAesEncryptionDecryptionServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AesEncryptionDecryptionService", function () {
      return AesEncryptionDecryptionService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var crypto_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! crypto-js */
    "./node_modules/crypto-js/index.js");
    /* harmony import */


    var crypto_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_2__);

    var AesEncryptionDecryptionService = /*#__PURE__*/function () {
      function AesEncryptionDecryptionService() {
        _classCallCheck(this, AesEncryptionDecryptionService);

        this.secretKey = "AVIVASME#2020";
      }

      _createClass(AesEncryptionDecryptionService, [{
        key: "encrypt",
        value: function encrypt(value) {
          return crypto_js__WEBPACK_IMPORTED_MODULE_2__["AES"].encrypt(value, this.secretKey.trim()).toString();
        }
      }, {
        key: "decrypt",
        value: function decrypt(textToDecrypt) {
          return crypto_js__WEBPACK_IMPORTED_MODULE_2__["AES"].decrypt(textToDecrypt, this.secretKey.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Utf8);
        }
      }, {
        key: "encryptRequestTest",
        value: function encryptRequestTest(str) {
          var iv = "2b61bb1c405a3d1a6479f31b849c372a";
          var s = "87d25e5d94d46fd5";
          var CryptoJSAesJson = {
            stringify: function stringify(cipherParams) {
              var j = {
                ct: cipherParams.ciphertext.toString(crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Base64)
              };
              if (cipherParams.iv) j.iv = iv;
              if (cipherParams.salt) j.s = s; //console.log("params:-"+JSON.stringify(j));

              return JSON.stringify(j);
            },
            parse: function parse(jsonStr) {
              var j = JSON.parse(jsonStr); //console.log("j.iv:-"+j.iv);
              //console.log("j.s:-"+j.s);

              var cipherParams = crypto_js__WEBPACK_IMPORTED_MODULE_2__["lib"].CipherParams.create({
                ciphertext: crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Base64.parse(j.ct)
              });
              if (j.iv) cipherParams.iv = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Hex.parse(iv);
              if (j.s) cipherParams.salt = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Hex.parse(s);
              return cipherParams;
            }
          };
          var encryption = crypto_js__WEBPACK_IMPORTED_MODULE_2__["AES"].encrypt(str, this.secretKey, {
            format: CryptoJSAesJson
          });
          var encrypted = encryption.toString();
          var encryptedString = JSON.parse(encryption).ct + "," + JSON.parse(encryption).iv + "," + JSON.parse(encryption).s; //console.log("encryptedString:-" + encryptedString);

          return JSON.parse(encryption).ct;
        }
      }, {
        key: "encryptRequest",
        value: function encryptRequest(str) {
          var CryptoJSAesJson = {
            stringify: function stringify(cipherParams) {
              var j = {
                ct: cipherParams.ciphertext.toString(crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Base64)
              };
              if (cipherParams.iv) j.iv = cipherParams.iv.toString();
              if (cipherParams.salt) j.s = cipherParams.salt.toString();
              return JSON.stringify(j);
            },
            parse: function parse(jsonStr) {
              var j = JSON.parse(jsonStr);
              var cipherParams = crypto_js__WEBPACK_IMPORTED_MODULE_2__["lib"].CipherParams.create({
                ciphertext: crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Base64.parse(j.ct)
              });
              if (j.iv) cipherParams.iv = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Hex.parse(j.iv);
              if (j.s) cipherParams.salt = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Hex.parse(j.s);
              return cipherParams;
            }
          };
          var encryption = crypto_js__WEBPACK_IMPORTED_MODULE_2__["AES"].encrypt(str, this.secretKey, {
            format: CryptoJSAesJson
          });
          var encrypted = encryption.toString();
          var encryptedString = JSON.parse(encryption).ct + "%A%T" + JSON.parse(encryption).iv + "%A%T" + JSON.parse(encryption).s; // //console.log("encryptedString:-" + encryptedString);

          return encryptedString;
        }
      }, {
        key: "parseEncryptedResponse",
        value: function parseEncryptedResponse(responseData) {
          //console.log("responsedata:-" + responseData);
          var ct = responseData.split("%A%T")[0];
          var iv = responseData.split("%A%T")[1];
          var s = responseData.split("%A%T")[2]; //console.log("ct:-" + ct);
          //console.log("iv:-" + iv);
          //console.log("s:-" + s);

          var encrypted1 = {
            ct: ct,
            iv: iv,
            s: s
          };
          var CryptoJSAesJson = {
            stringify: function stringify(cipherParams) {
              var j = {
                ct: cipherParams.ciphertext.toString(crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Base64)
              };
              if (cipherParams.iv) j.iv = cipherParams.iv.toString();
              if (cipherParams.salt) j.s = cipherParams.salt.toString();
              return JSON.stringify(j);
            },
            parse: function parse(jsonStr) {
              var j = JSON.parse(jsonStr);
              var cipherParams = crypto_js__WEBPACK_IMPORTED_MODULE_2__["lib"].CipherParams.create({
                ciphertext: crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Base64.parse(j.ct)
              });
              if (j.iv) cipherParams.iv = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Hex.parse(j.iv);
              if (j.s) cipherParams.salt = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Hex.parse(j.s);
              return cipherParams;
            }
          };
          var decrypted = JSON.parse(crypto_js__WEBPACK_IMPORTED_MODULE_2__["AES"].decrypt(JSON.stringify(encrypted1), this.secretKey, {
            format: CryptoJSAesJson
          }).toString(crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Utf8));
          return decrypted;
        }
      }]);

      return AesEncryptionDecryptionService;
    }();

    AesEncryptionDecryptionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], AesEncryptionDecryptionService);
    /***/
  },

  /***/
  "./src/app/app-routing.module.ts":
  /*!***************************************!*\
    !*** ./src/app/app-routing.module.ts ***!
    \***************************************/

  /*! exports provided: AppRoutingModule */

  /***/
  function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
      return AppRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _layout_layout_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./layout/layout.component */
    "./src/app/layout/layout.component.ts");
    /* harmony import */


    var _short_lead_short_lead_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./short-lead/short-lead.component */
    "./src/app/short-lead/short-lead.component.ts");
    /* harmony import */


    var _customers_customers_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./customers/customers.component */
    "./src/app/customers/customers.component.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _login_login_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./login/login.component */
    "./src/app/login/login.component.ts");

    var routes = [{
      path: '',
      redirectTo: 'login',
      pathMatch: 'full'
    }, // {path: '', redirectTo: 'customer', pathMatch: 'full'},
    {
      path: '',
      component: _login_login_component__WEBPACK_IMPORTED_MODULE_6__["LoginComponent"]
    }, {
      path: 'login',
      component: _login_login_component__WEBPACK_IMPORTED_MODULE_6__["LoginComponent"]
    }, {
      path: 'layout',
      component: _layout_layout_component__WEBPACK_IMPORTED_MODULE_1__["LayoutComponent"],
      children: [{
        path: 'customer',
        component: _customers_customers_component__WEBPACK_IMPORTED_MODULE_3__["CustomersComponent"]
      }, {
        path: 'short-lead',
        component: _short_lead_short_lead_component__WEBPACK_IMPORTED_MODULE_2__["ShortLeadComponent"]
      }]
    }];

    var AppRoutingModule = function AppRoutingModule() {
      _classCallCheck(this, AppRoutingModule);
    };

    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forRoot(routes, {
        useHash: true
      })],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"]]
    })], AppRoutingModule);
    /***/
  },

  /***/
  "./src/app/app.component.scss":
  /*!************************************!*\
    !*** ./src/app/app.component.scss ***!
    \************************************/

  /*! exports provided: default */

  /***/
  function srcAppAppComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/app.component.ts":
  /*!**********************************!*\
    !*** ./src/app/app.component.ts ***!
    \**********************************/

  /*! exports provided: AppComponent */

  /***/
  function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
      return AppComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var AppComponent = function AppComponent() {
      _classCallCheck(this, AppComponent);

      this.title = 'sme-Dashboard';
    };

    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-root',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./app.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./app.component.scss */
      "./src/app/app.component.scss"))["default"]]
    })], AppComponent);
    /***/
  },

  /***/
  "./src/app/app.module.ts":
  /*!*******************************!*\
    !*** ./src/app/app.module.ts ***!
    \*******************************/

  /*! exports provided: AppModule */

  /***/
  function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppModule", function () {
      return AppModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _layout_layout_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./layout/layout.component */
    "./src/app/layout/layout.component.ts");
    /* harmony import */


    var _userservice_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./userservice.service */
    "./src/app/userservice.service.ts");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./app-routing.module */
    "./src/app/app-routing.module.ts");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./app.component */
    "./src/app/app.component.ts");
    /* harmony import */


    var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/platform-browser/animations */
    "./node_modules/@angular/platform-browser/fesm2015/animations.js");
    /* harmony import */


    var _material_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./material.module */
    "./src/app/material.module.ts");
    /* harmony import */


    var _customers_customers_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./customers/customers.component */
    "./src/app/customers/customers.component.ts");
    /* harmony import */


    var _short_lead_short_lead_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./short-lead/short-lead.component */
    "./src/app/short-lead/short-lead.component.ts");
    /* harmony import */


    var _question_modal_question_modal_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./question-modal/question-modal.component */
    "./src/app/question-modal/question-modal.component.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! @ng-bootstrap/ng-bootstrap */
    "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");
    /* harmony import */


    var _login_login_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! ./login/login.component */
    "./src/app/login/login.component.ts");
    /* harmony import */


    var _angular_material_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! @angular/material/core */
    "./node_modules/@angular/material/esm2015/core.js");

    var AppModule = function AppModule() {
      _classCallCheck(this, AppModule);
    };

    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["NgModule"])({
      declarations: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"], _customers_customers_component__WEBPACK_IMPORTED_MODULE_9__["CustomersComponent"], _short_lead_short_lead_component__WEBPACK_IMPORTED_MODULE_10__["ShortLeadComponent"], _question_modal_question_modal_component__WEBPACK_IMPORTED_MODULE_11__["QuestionModalComponent"], _login_login_component__WEBPACK_IMPORTED_MODULE_15__["LoginComponent"], _layout_layout_component__WEBPACK_IMPORTED_MODULE_1__["LayoutComponent"]],
      entryComponents: [_question_modal_question_modal_component__WEBPACK_IMPORTED_MODULE_11__["QuestionModalComponent"]],
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_5__["AppRoutingModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__["BrowserAnimationsModule"], _material_module__WEBPACK_IMPORTED_MODULE_8__["MaterialModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_12__["HttpClientModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_13__["FormsModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_14__["NgbModule"]],
      providers: [_userservice_service__WEBPACK_IMPORTED_MODULE_2__["UserserviceService"], {
        provide: _angular_material_core__WEBPACK_IMPORTED_MODULE_16__["MAT_DATE_LOCALE"],
        useValue: 'en-GB'
      }],
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"]]
    })], AppModule);
    /***/
  },

  /***/
  "./src/app/customers/customers.component.scss":
  /*!****************************************************!*\
    !*** ./src/app/customers/customers.component.scss ***!
    \****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCustomersCustomersComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "table {\n  width: 100%;\n}\n\ntr.example-detail-row {\n  height: 0;\n}\n\ntr.example-element-row:not(.example-expanded-row):hover {\n  background: #777;\n}\n\ntr.example-element-row:not(.example-expanded-row):active {\n  background: #efefef;\n}\n\n.example-element-row td {\n  border-bottom-width: 0;\n}\n\n.example-element-detail {\n  overflow: hidden;\n  display: flex;\n}\n\n.example-element-diagram {\n  min-width: 80px;\n  border: 2px solid black;\n  padding: 8px;\n  font-weight: lighter;\n  margin: 8px 0;\n  height: 104px;\n}\n\n.example-element-symbol {\n  font-weight: bold;\n  font-size: 40px;\n  line-height: normal;\n}\n\n.example-element-description {\n  padding: 16px;\n}\n\n.example-element-description-attribution {\n  opacity: 0.5;\n}\n\n.mat-header-cell {\n  font-size: 15px;\n  background-color: #ffd900;\n}\n\n.dialog {\n  max-width: 600px;\n}\n\n.basic-container {\n  width: auto;\n}\n\n.center {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.calendars {\n  flex: 1;\n  display: flex;\n  flex-direction: row;\n  align-items: stretch;\n}\n\n.calendars .column {\n  display: flex;\n  flex-direction: column;\n  align-items: stretch;\n  justify-content: flex-start;\n  padding: 0 4px;\n  flex: 1;\n}\n\n.form-group.hidden {\n  width: 0;\n  margin: 0;\n  border: none;\n  padding: 0;\n}\n\n.custom-day {\n  text-align: center;\n  padding: 0.185rem 0.25rem;\n  display: inline-block;\n  height: 2rem;\n  width: 2rem;\n}\n\n.custom-day.focused {\n  background-color: #e6e6e6;\n}\n\n.custom-day.range, .custom-day:hover {\n  background-color: #0275d8;\n  color: white;\n}\n\nbutton.calendar, button.calendar:active {\n  width: 2.75rem;\n  zoom: 0.8;\n  background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAcCAYAAAAEN20fAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAEUSURBVEiJ7ZQxToVAEIY/YCHGxN6XGOIpnpaEsBSeQC9ArZbm9TZ6ADyBNzAhQGGl8Riv4BLAWAgmkpBYkH1b8FWT2WK/zJ8ZJ4qiI6XUI3ANnGKWBnht2/ZBDRK3hgVGNsCd7/ui+JkEIrKtqurLpEWaphd933+IyI3LEIdpCYCiKD6HcuOa/nwOa0ScJEnk0BJg0UTUWJRl6RxCYEzEmomsIlPU3IPW+grIAbquy+q6fluy/28RIBeRMwDXdXMgXLj/B2uimRXpui4D9sBeRLKl+1N+L+t6RwbWrZliTTTr1oxYtzVWiTQAcRxvTX+eJMnlUDaO1vpZRO5NS0x48sIwfPc87xg4B04MCzQi8hIEwe4bl1DnFMCN2zsAAAAASUVORK5CYII=\") !important;\n  background-repeat: no-repeat;\n  background-size: 23px;\n  background-position: center;\n  border: 0;\n  border-bottom: 1px solid black;\n}\n\n.form-control {\n  border: 0;\n  border-bottom: 1px solid black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zdW5pbHZpc2h3YWthcm1hL0Rlc2t0b3AvcHJvamVjdHMvc21lL3NtZWFkbWluL3NyYy9hcHAvY3VzdG9tZXJzL2N1c3RvbWVycy5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvY3VzdG9tZXJzL2N1c3RvbWVycy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7QUNDSjs7QURFRTtFQUNFLFNBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0FDQ0o7O0FERUU7RUFDRSxtQkFBQTtBQ0NKOztBREVFO0VBQ0Usc0JBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsYUFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7QUNDSjs7QURFRTtFQUNFLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0FDQ0o7O0FERUU7RUFDRSxhQUFBO0FDQ0o7O0FERUU7RUFDRSxZQUFBO0FDQ0o7O0FERUE7RUFDRSxlQUFBO0VBQ0EseUJBQUE7QUNDRjs7QURLRTtFQUVFLGdCQUFBO0FDSEo7O0FETUU7RUFDRSxXQUFBO0FDSEo7O0FETUU7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ0hKOztBREtFO0VBQ0UsT0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUVBLG9CQUFBO0FDSEo7O0FET0k7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxvQkFBQTtFQUNBLDJCQUFBO0VBQ0EsY0FBQTtFQUNBLE9BQUE7QUNMTjs7QURXQTtFQUNFLFFBQUE7RUFDQSxTQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7QUNSRjs7QURVQTtFQUNFLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxxQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FDUEY7O0FEU0E7RUFDRSx5QkFBQTtBQ05GOztBRFFBO0VBQ0UseUJBQUE7RUFDQSxZQUFBO0FDTEY7O0FEV0E7RUFDRSxjQUFBO0VBQ0EsU0FBQTtFQUNBLDBsQkFBQTtFQUNBLDRCQUFBO0VBQ0EscUJBQUE7RUFDQSwyQkFBQTtFQUNBLFNBQUE7RUFDQSw4QkFBQTtBQ1JGOztBRFlBO0VBQ0UsU0FBQTtFQUNBLDhCQUFBO0FDVEYiLCJmaWxlIjoic3JjL2FwcC9jdXN0b21lcnMvY3VzdG9tZXJzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsidGFibGUge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgfVxyXG5cclxuICB0ci5leGFtcGxlLWRldGFpbC1yb3cge1xyXG4gICAgaGVpZ2h0OiAwO1xyXG4gIH1cclxuXHJcbiAgdHIuZXhhbXBsZS1lbGVtZW50LXJvdzpub3QoLmV4YW1wbGUtZXhwYW5kZWQtcm93KTpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjNzc3O1xyXG4gIH1cclxuXHJcbiAgdHIuZXhhbXBsZS1lbGVtZW50LXJvdzpub3QoLmV4YW1wbGUtZXhwYW5kZWQtcm93KTphY3RpdmUge1xyXG4gICAgYmFja2dyb3VuZDogI2VmZWZlZjtcclxuICB9XHJcblxyXG4gIC5leGFtcGxlLWVsZW1lbnQtcm93IHRkIHtcclxuICAgIGJvcmRlci1ib3R0b20td2lkdGg6IDA7XHJcbiAgfVxyXG5cclxuICAuZXhhbXBsZS1lbGVtZW50LWRldGFpbCB7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICB9XHJcblxyXG4gIC5leGFtcGxlLWVsZW1lbnQtZGlhZ3JhbSB7XHJcbiAgICBtaW4td2lkdGg6IDgwcHg7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcclxuICAgIHBhZGRpbmc6IDhweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBsaWdodGVyO1xyXG4gICAgbWFyZ2luOiA4cHggMDtcclxuICAgIGhlaWdodDogMTA0cHg7XHJcbiAgfVxyXG5cclxuICAuZXhhbXBsZS1lbGVtZW50LXN5bWJvbCB7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGZvbnQtc2l6ZTogNDBweDtcclxuICAgIGxpbmUtaGVpZ2h0OiBub3JtYWw7XHJcbiAgfVxyXG5cclxuICAuZXhhbXBsZS1lbGVtZW50LWRlc2NyaXB0aW9uIHtcclxuICAgIHBhZGRpbmc6IDE2cHg7XHJcbiAgfVxyXG5cclxuICAuZXhhbXBsZS1lbGVtZW50LWRlc2NyaXB0aW9uLWF0dHJpYnV0aW9uIHtcclxuICAgIG9wYWNpdHk6IDAuNTtcclxuICB9XHJcblxyXG4ubWF0LWhlYWRlci1jZWxse1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZkOTAwO1xyXG59XHJcblxyXG5cclxuXHJcbi8vIGRhdGUgcmFuZ2UgcGlja2VyXHJcbiAgLmRpYWxvZyB7XHJcbiAgICAvLyBtYXJnaW46IDIwMHB4IGF1dG87XHJcbiAgICBtYXgtd2lkdGg6IDYwMHB4XHJcbiAgfVxyXG5cclxuICAuYmFzaWMtY29udGFpbmVye1xyXG4gICAgd2lkdGg6IGF1dG87XHJcbiAgfVxyXG5cclxuICAuY2VudGVyIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgfVxyXG4gIC5jYWxlbmRhcnMge1xyXG4gICAgZmxleDogMTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgLy8ganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XHJcbiAgICBhbGlnbi1pdGVtczogc3RyZXRjaDtcclxuICAgIC8vIG1hcmdpbjogMCAtNHB4O1xyXG5cclxuXHJcbiAgICAuY29sdW1uIHtcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgYWxpZ24taXRlbXM6IHN0cmV0Y2g7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogZmxleC1zdGFydDtcclxuICAgICAgcGFkZGluZzogMCA0cHg7XHJcbiAgICAgIGZsZXg6IDE7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvL2RhdGUgcGlja2VyIGNzc1xyXG5cclxuLmZvcm0tZ3JvdXAuaGlkZGVuIHtcclxuICB3aWR0aDogMDtcclxuICBtYXJnaW46IDA7XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIHBhZGRpbmc6IDA7XHJcbn1cclxuLmN1c3RvbS1kYXkge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBwYWRkaW5nOiAwLjE4NXJlbSAwLjI1cmVtO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBoZWlnaHQ6IDJyZW07XHJcbiAgd2lkdGg6IDJyZW07XHJcbn1cclxuLmN1c3RvbS1kYXkuZm9jdXNlZCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcclxufVxyXG4uY3VzdG9tLWRheS5yYW5nZSwgLmN1c3RvbS1kYXk6aG92ZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigyLCAxMTcsIDIxNik7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG59XHJcbi5jdXN0b20tZGF5LmZhZGVkIHtcclxuICAvL2JhY2tncm91bmQtY29sb3I6IHJnYmEoMiwgMTE3LCAyMTYsIDAuNSk7XHJcbn1cclxuXHJcbmJ1dHRvbi5jYWxlbmRhciwgYnV0dG9uLmNhbGVuZGFyOmFjdGl2ZSB7XHJcbiAgd2lkdGg6IDIuNzVyZW07XHJcbiAgem9vbTogMC44O1xyXG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFDSUFBQUFjQ0FZQUFBQUVOMjBmQUFBQUJITkNTVlFJQ0FnSWZBaGtpQUFBQUFsd1NGbHpBQUFPeEFBQURzUUJsU3NPR3dBQUFCbDBSVmgwVTI5bWRIZGhjbVVBZDNkM0xtbHVhM05qWVhCbExtOXlaNXZ1UEJvQUFBRVVTVVJCVkVpSjdaUXhUb1ZBRUlZL1lDSEd4TjZYR09JcG5wYUVzQlNlUUM5QXJaYm05VFo2QUR5Qk56QWhRR0dsOFJpdjRCTEFXQWdta3BCWWtIMWI4RldUMldLL3pKOFpKNHFpSTZYVUkzQU5uR0tXQm5odDIvWkJEUkszaGdWR05zQ2Q3L3VpK0prRUlyS3RxdXJMcEVXYXBoZDkzMytJeUkzTEVJZHBDWUNpS0Q2SGN1T2EvbndPYTBTY0pFbmswQkpnMFVUVVdKUmw2UnhDWUV6RW1vbXNJbFBVM0lQVytncklBYnF1eStxNmZsdXkvMjhSSUJlUk13RFhkWE1nWExqL0IydWltUlhwdWk0RDlzQmVSTEtsKzFOK0wrdDZSd2JXclpsaVRUVHIxb3hZdHpWV2lUUUFjUnh2VFgrZUpNbmxVRGFPMXZwWlJPNU5TMHg0OHNJd2ZQYzg3eGc0QjA0TUN6UWk4aElFd2U0YmwxRG5GTUNOMnpzQUFBQUFTVVZPUks1Q1lJST0nKSAhaW1wb3J0YW50O1xyXG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgYmFja2dyb3VuZC1zaXplOiAyM3B4O1xyXG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuICBib3JkZXI6IDA7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGJsYWNrO1xyXG59XHJcbi8vZGF0ZSBwaWNrZXIgY3NzXHJcblxyXG4uZm9ybS1jb250cm9se1xyXG4gIGJvcmRlcjogMDtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgYmxhY2s7XHJcbn1cclxuIiwidGFibGUge1xuICB3aWR0aDogMTAwJTtcbn1cblxudHIuZXhhbXBsZS1kZXRhaWwtcm93IHtcbiAgaGVpZ2h0OiAwO1xufVxuXG50ci5leGFtcGxlLWVsZW1lbnQtcm93Om5vdCguZXhhbXBsZS1leHBhbmRlZC1yb3cpOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogIzc3Nztcbn1cblxudHIuZXhhbXBsZS1lbGVtZW50LXJvdzpub3QoLmV4YW1wbGUtZXhwYW5kZWQtcm93KTphY3RpdmUge1xuICBiYWNrZ3JvdW5kOiAjZWZlZmVmO1xufVxuXG4uZXhhbXBsZS1lbGVtZW50LXJvdyB0ZCB7XG4gIGJvcmRlci1ib3R0b20td2lkdGg6IDA7XG59XG5cbi5leGFtcGxlLWVsZW1lbnQtZGV0YWlsIHtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgZGlzcGxheTogZmxleDtcbn1cblxuLmV4YW1wbGUtZWxlbWVudC1kaWFncmFtIHtcbiAgbWluLXdpZHRoOiA4MHB4O1xuICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcbiAgcGFkZGluZzogOHB4O1xuICBmb250LXdlaWdodDogbGlnaHRlcjtcbiAgbWFyZ2luOiA4cHggMDtcbiAgaGVpZ2h0OiAxMDRweDtcbn1cblxuLmV4YW1wbGUtZWxlbWVudC1zeW1ib2wge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zaXplOiA0MHB4O1xuICBsaW5lLWhlaWdodDogbm9ybWFsO1xufVxuXG4uZXhhbXBsZS1lbGVtZW50LWRlc2NyaXB0aW9uIHtcbiAgcGFkZGluZzogMTZweDtcbn1cblxuLmV4YW1wbGUtZWxlbWVudC1kZXNjcmlwdGlvbi1hdHRyaWJ1dGlvbiB7XG4gIG9wYWNpdHk6IDAuNTtcbn1cblxuLm1hdC1oZWFkZXItY2VsbCB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZDkwMDtcbn1cblxuLmRpYWxvZyB7XG4gIG1heC13aWR0aDogNjAwcHg7XG59XG5cbi5iYXNpYy1jb250YWluZXIge1xuICB3aWR0aDogYXV0bztcbn1cblxuLmNlbnRlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uY2FsZW5kYXJzIHtcbiAgZmxleDogMTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgYWxpZ24taXRlbXM6IHN0cmV0Y2g7XG59XG4uY2FsZW5kYXJzIC5jb2x1bW4ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBhbGlnbi1pdGVtczogc3RyZXRjaDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICBwYWRkaW5nOiAwIDRweDtcbiAgZmxleDogMTtcbn1cblxuLmZvcm0tZ3JvdXAuaGlkZGVuIHtcbiAgd2lkdGg6IDA7XG4gIG1hcmdpbjogMDtcbiAgYm9yZGVyOiBub25lO1xuICBwYWRkaW5nOiAwO1xufVxuXG4uY3VzdG9tLWRheSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogMC4xODVyZW0gMC4yNXJlbTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBoZWlnaHQ6IDJyZW07XG4gIHdpZHRoOiAycmVtO1xufVxuXG4uY3VzdG9tLWRheS5mb2N1c2VkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcbn1cblxuLmN1c3RvbS1kYXkucmFuZ2UsIC5jdXN0b20tZGF5OmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAyNzVkODtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG5idXR0b24uY2FsZW5kYXIsIGJ1dHRvbi5jYWxlbmRhcjphY3RpdmUge1xuICB3aWR0aDogMi43NXJlbTtcbiAgem9vbTogMC44O1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCJkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUNJQUFBQWNDQVlBQUFBRU4yMGZBQUFBQkhOQ1NWUUlDQWdJZkFoa2lBQUFBQWx3U0ZsekFBQU94QUFBRHNRQmxTc09Hd0FBQUJsMFJWaDBVMjltZEhkaGNtVUFkM2QzTG1sdWEzTmpZWEJsTG05eVo1dnVQQm9BQUFFVVNVUkJWRWlKN1pReFRvVkFFSVkvWUNIR3hONlhHT0lwbnBhRXNCU2VRQzlBclpibTlUWjZBRHlCTnpBaFFHR2w4Uml2NEJMQVdBZ21rcEJZa0gxYjhGV1QyV0sveko4Wko0cWlJNlhVSTNBTm5HS1dCbmh0Mi9aQkRSSzNoZ1ZHTnNDZDcvdWkrSmtFSXJLdHF1ckxwRVdhcGhkOTMzK0l5STNMRUlkcENZQ2lLRDZIY3VPYS9ud09hMFNjSkVuazBCSmcwVVRVV0pSbDZSeENZRXpFbW9tc0lsUFUzSVBXK2dySUFicXV5K3E2Zmx1eS8yOFJJQmVSTXdEWGRYTWdYTGovQjJ1aW1SWHB1aTREOXNCZVJMS2wrMU4rTCt0NlJ3YldyWmxpVFRUcjFveFl0elZXaVRRQWNSeHZUWCtlSk1ubFVEYU8xdnBaUk81TlMweDQ4c0l3ZlBjODd4ZzRCMDRNQ3pRaThoSUV3ZTRibDFEbkZNQ04yenNBQUFBQVNVVk9SSzVDWUlJPVwiKSAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IDIzcHg7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgYm9yZGVyOiAwO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgYmxhY2s7XG59XG5cbi5mb3JtLWNvbnRyb2wge1xuICBib3JkZXI6IDA7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBibGFjaztcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/customers/customers.component.ts":
  /*!**************************************************!*\
    !*** ./src/app/customers/customers.component.ts ***!
    \**************************************************/

  /*! exports provided: CustomersComponent */

  /***/
  function srcAppCustomersCustomersComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CustomersComponent", function () {
      return CustomersComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _userservice_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../userservice.service */
    "./src/app/userservice.service.ts");
    /* harmony import */


    var _question_modal_question_modal_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./../question-modal/question-modal.component */
    "./src/app/question-modal/question-modal.component.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_table__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/material/table */
    "./node_modules/@angular/material/esm2015/table.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @ng-bootstrap/ng-bootstrap */
    "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _aes_encryption_decryption_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ../aes-encryption-decryption.service */
    "./src/app/aes-encryption-decryption.service.ts");
    /* harmony import */


    var _BaseComp__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ../BaseComp */
    "./src/app/BaseComp.ts");
    /* harmony import */


    var file_saver__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! file-saver */
    "./node_modules/file-saver/dist/FileSaver.min.js");
    /* harmony import */


    var file_saver__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_12__); // import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from "@angular/material";
    // import { AppDateAdapter, APP_DATE_FORMATS} from '../date.adapter';
    //for date picker format


    var CustomersComponent = /*#__PURE__*/function (_BaseComp__WEBPACK_IM) {
      _inherits(CustomersComponent, _BaseComp__WEBPACK_IM);

      var _super = _createSuper(CustomersComponent);

      function CustomersComponent(dialog, userservice, http, calendar, formatter, router, aesEncryptionDecryptionService) {
        var _this;

        _classCallCheck(this, CustomersComponent);

        _this = _super.call(this);
        _this.dialog = dialog;
        _this.userservice = userservice;
        _this.http = http;
        _this.calendar = calendar;
        _this.formatter = formatter;
        _this.router = router;
        _this.aesEncryptionDecryptionService = aesEncryptionDecryptionService; //date ngb picker

        _this.hoveredDate = null; //date ngb picker

        _this.showdateranger = false; // ELEMENT_DATA: AllUsers[];

        _this.users = [];
        _this.displayedColumns = ['user_id', 'name', 'dob', 'mobile', 'email_id', 'company_name', 'city', 'actions'];
        _this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_5__["MatTableDataSource"](_this.users);
        _this.picker1 = "2020-05-26";
        _this.from_date = "";
        _this.to_date = "";
        _this.dateF = new Date();
        _this.dateT = new Date();

        if (_this.getSessionStoredItem(_this.IS_USER_LOGIN) != "1") {
          _this.router.navigateByUrl("/login");
        }

        _this.from_date = _this.setDate();
        _this.to_date = _this.setDate();
        return _this;
      }

      _createClass(CustomersComponent, [{
        key: "formatNumber",
        value: function formatNumber(num) {
          if (num.length == 1) {
            return "0" + num;
          }

          return num;
        }
      }, {
        key: "setDate",
        value: function setDate() {
          var d = new Date();
          var date = this.formatNumber(d.getDate().toString());
          var month = this.formatNumber((d.getMonth() + 1).toString());
          var year = d.getFullYear();
          var finalDate = year + "-" + month + "-" + date;
          return finalDate;
        }
      }, {
        key: "searchUsers",
        value: function searchUsers() {
          this.from_date = this.dateF.getFullYear() + "-" + this.formatNumber((this.dateF.getMonth() + 1).toString()) + "-" + this.formatNumber(this.dateF.getDate().toString()) + " 00:00:00";
          this.to_date = this.dateT.getFullYear() + "-" + this.formatNumber((this.dateT.getMonth() + 1).toString()) + "-" + this.formatNumber(this.dateT.getDate().toString()) + " 23:59:59";
          var date1 = new Date(this.from_date);
          var date2 = new Date(this.to_date);

          if (date2 > date1) {
            // console.log("fromDate:-"+this.from_date);
            // console.log("toDate:-"+this.to_date);
            this.getAllUser();
          } else {
            alert("End date should be greater than Start date");
          } // this.from_date = this.fromDate.year + "-" + this.formatNumber(this.fromDate.month.toString()) + "-" + this.formatNumber(this.fromDate.day.toString());
          // //console.log("from_date:-" + this.from_date);
          // this.to_date = this.toDate.year + "-" + this.formatNumber(this.toDate.month.toString()) + "-" + this.formatNumber(this.toDate.day.toString());
          // //console.log("to_date:-" + this.to_date);
          // this.getAllUser();

        }
      }, {
        key: "export",
        value: function _export() {
          this.from_date = this.dateF.getFullYear() + "-" + this.formatNumber((this.dateF.getMonth() + 1).toString()) + "-" + this.formatNumber(this.dateF.getDate().toString()) + " 00:00:00";
          this.to_date = this.dateT.getFullYear() + "-" + this.formatNumber((this.dateT.getMonth() + 1).toString()) + "-" + this.formatNumber(this.dateT.getDate().toString()) + " 23:59:59";
          var date1 = new Date(this.from_date);
          var date2 = new Date(this.to_date);

          if (date2 > date1) {
            // console.log("fromDate:-"+this.from_date);
            // console.log("toDate:-"+this.to_date);
            this.getSheet();
          } else {
            alert("End date should be greater than Start date");
          } // this.from_date = this.fromDate.year + "-" + this.formatNumber(this.fromDate.month.toString()) + "-" + this.formatNumber(this.fromDate.day.toString());
          // //console.log("from_date:-" + this.from_date);
          // this.to_date = this.toDate.year + "-" + this.formatNumber(this.toDate.month.toString()) + "-" + this.formatNumber(this.toDate.day.toString());
          //console.log("to_date:-" + this.to_date);

        }
      }, {
        key: "getSheet",
        value: function getSheet() {
          var _this2 = this;

          var url = this.getSessionStoredItem(this.BASE_URL) + this.GET_ALL_USER_EXCEL + '?from_date=' + this.from_date + "&to_date=" + this.to_date; //console.log("url:-" + url);
          // window.open(url);

          this.http.get(url, {
            responseType: 'arraybuffer'
          }).subscribe(function (data) {
            try {
              //console.log('data received:-' + data);
              Object(file_saver__WEBPACK_IMPORTED_MODULE_12__["saveAs"])(new Blob([data], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetxml.sheet'
              }), _this2.from_date + _this2.to_date + ".xlsx"); // let parsedJSON = JSON.parse(data);
              //console.log("response:-" + parsedJSON.response);
              //console.log("parsedResponse:-" + JSON.stringify(this.aesEncryptionDecryptionService.parseEncryptedResponse(parsedJSON.response)));
            } catch (e) {//console.log(e);
            }
          }); // let postData = {
          //     from_date: this.from_date,
          //     to_date: this.to_date
          // }
          //
          // let formData = {
          //     request: this.aesEncryptionDecryptionService.encryptRequest(JSON.stringify(postData))
          // }
          //
          // //console.log("formData:-"+JSON.stringify(formData))
          //
          //
          // this.http.post(this.GET_ALL_USER_EXCEL, JSON.stringify(formData), {responseType: 'arraybuffer'}).subscribe(data => {
          //     try {
          //         //console.log('data received:-' + data);
          //         saveAs(new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetxml.sheet'}), this.from_date+this.to_date+".xlsx");
          //         // let parsedJSON = JSON.parse(data);
          //         //console.log("response:-" + parsedJSON.response);
          //         //console.log("parsedResponse:-" + JSON.stringify(this.aesEncryptionDecryptionService.parseEncryptedResponse(parsedJSON.response)));
          //     } catch (e) {
          //         //console.log(e);
          //     }
          // });
        }
      }, {
        key: "openDialog",
        value: function openDialog(element) {
          window.sessionStorage.setItem("element", JSON.stringify(element));
          var dialogRef = this.dialog.open(_question_modal_question_modal_component__WEBPACK_IMPORTED_MODULE_2__["QuestionModalComponent"]);
          dialogRef.afterClosed().subscribe(function (result) {//console.log(`Dialog result: ${result}`);
          });
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          this.searchUsers();
          this.dataSource.paginator = this.paginator; // @ts-ignore
          // this.fromDate = Date.now();
        }
      }, {
        key: "showDate",
        value: function showDate() {
          this.showdateranger = !this.showdateranger;
        }
      }, {
        key: "getAllUser",
        value: function getAllUser() {
          var _this3 = this;

          // let resp = this.userservice.allusers();
          // resp.subscribe(report=>this.dataSource.data=report as AllUsers[]);
          this.users = [];
          var url = this.getSessionStoredItem(this.BASE_URL) + this.GET_ALL_USERS; //console.log("url:-" + url);

          var postData = {
            from_date: this.from_date,
            to_date: this.to_date
          };
          var formData = {
            request: this.aesEncryptionDecryptionService.encryptRequest(JSON.stringify(postData))
          };
          this.http.post(url, JSON.stringify(formData), {
            responseType: 'text'
          }).subscribe(function (result) {
            try {
              //console.log("data:-" + JSON.stringify(result));
              var parsedData = JSON.parse(result);

              var parsedJSON = _this3.aesEncryptionDecryptionService.parseEncryptedResponse(parsedData.response);

              if (parsedJSON.status == 1) {
                for (var i = 0; i < parsedJSON.result.length; i++) {
                  if (parsedJSON.result[i].businessData != null && parsedJSON.result[i].employeeData != null && parsedJSON.result[i].hofData != null) {
                    var business = null;

                    if (parsedJSON.result[i].businessData != null) {
                      business = {
                        bo_id: parsedJSON.result[i].businessData.bo_id,
                        user_id: parsedJSON.result[i].businessData.user_id,
                        q1: parsedJSON.result[i].businessData.q1,
                        q1a: parsedJSON.result[i].businessData.q1a,
                        q2: parsedJSON.result[i].businessData.q2,
                        q3: parsedJSON.result[i].businessData.q3,
                        q4: parsedJSON.result[i].businessData.q4,
                        q5: parsedJSON.result[i].businessData.q5,
                        q5a: parsedJSON.result[i].businessData.q5a
                      };
                    }

                    var employee = null;

                    if (parsedJSON.result[i].employeeData != null) {
                      employee = {
                        emp_id: parsedJSON.result[i].employeeData.emp_id,
                        user_id: parsedJSON.result[i].employeeData.user_id,
                        q1: parsedJSON.result[i].employeeData.q1,
                        q2: parsedJSON.result[i].employeeData.q2,
                        q3: parsedJSON.result[i].employeeData.q3,
                        q4: parsedJSON.result[i].employeeData.q4,
                        q5: parsedJSON.result[i].employeeData.q5,
                        q6: parsedJSON.result[i].employeeData.q6
                      };
                    }

                    var hof = null;

                    if (parsedJSON.result[i].hofData != null) {
                      hof = {
                        hof_id: parsedJSON.result[i].hofData.emp_id,
                        user_id: parsedJSON.result[i].hofData.user_id,
                        q1: parsedJSON.result[i].hofData.q1,
                        q2: parsedJSON.result[i].hofData.q2,
                        q3: parsedJSON.result[i].hofData.q3,
                        q4: parsedJSON.result[i].hofData.q4,
                        q5: parsedJSON.result[i].hofData.q5,
                        q6: parsedJSON.result[i].hofData.q6,
                        q7: parsedJSON.result[i].hofData.q7,
                        q8: parsedJSON.result[i].hofData.q8,
                        q9: parsedJSON.result[i].hofData.q9,
                        q10: parsedJSON.result[i].hofData.q10
                      };
                    }

                    var user = {
                      user_id: parsedJSON.result[i].user_id,
                      salutation: parsedJSON.result[i].salutation,
                      name: parsedJSON.result[i].name,
                      dob: parsedJSON.result[i].dob,
                      mobile: parsedJSON.result[i].mobile,
                      email_id: parsedJSON.result[i].email_id,
                      company_name: parsedJSON.result[i].company_name,
                      city: parsedJSON.result[i].city,
                      aviva_emp_id: parsedJSON.result[i].aviva_emp_id,
                      added_on: parsedJSON.result[i].added_on,
                      business: business,
                      employee: employee,
                      hof: hof
                    };

                    _this3.users.push(user);
                  }
                }

                _this3.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_5__["MatTableDataSource"](_this3.users);
              }
            } catch (err) {//console.log(err);
            }
          });
        }
      }, {
        key: "getRecord",
        value: function getRecord(element, name) {
          //console.log(JSON.stringify(element));
          // window.open("http://localhost/sme/index.php/api/CreatePdf/createPDF?user_id=" + element);
          // window.open("http://10.72.9.117/angular_pdf/pdf.php?user_id=" + this.aesEncryptionDecryptionService.encryptRequest(element));
          //console.log("user_id:-" + element);
          // let postData = {
          //     user_id: this.aesEncryptionDecryptionService.encryptRequest(element)
          // }
          var postData = {
            user_id: element
          };
          this.http.post(this.getSessionStoredItem(this.BASE_URL) + this.OPEN_PDF, JSON.stringify(postData), {
            responseType: 'arraybuffer'
          }).subscribe(function (data) {
            try {
              //console.log('data received:-' + data);
              Object(file_saver__WEBPACK_IMPORTED_MODULE_12__["saveAs"])(new Blob([data], {
                type: 'application/pdf'
              }), name + ".pdf"); // let parsedJSON = JSON.parse(data);
              //console.log("response:-" + parsedJSON.response);
              //console.log("parsedResponse:-" + JSON.stringify(this.aesEncryptionDecryptionService.parseEncryptedResponse(parsedJSON.response)));
            } catch (e) {//console.log(e);
            }
          });
        } //  for ngb date picker

      }, {
        key: "onDateSelection",
        value: function onDateSelection(date) {
          if (!this.fromDate && !this.toDate) {
            this.fromDate = date;
          } else if (this.fromDate && !this.toDate && date && date.after(this.fromDate)) {
            this.toDate = date;
          } else {
            this.toDate = null;
            this.fromDate = date;
          }
        }
      }, {
        key: "isHovered",
        value: function isHovered(date) {
          return this.fromDate && !this.toDate && this.hoveredDate && date.after(this.fromDate) && date.before(this.hoveredDate);
        }
      }, {
        key: "isInside",
        value: function isInside(date) {
          return this.toDate && date.after(this.fromDate) && date.before(this.toDate);
        }
      }, {
        key: "isRange",
        value: function isRange(date) {
          return date.equals(this.fromDate) || this.toDate && date.equals(this.toDate) || this.isInside(date) || this.isHovered(date);
        }
      }, {
        key: "validateInput",
        value: function validateInput(currentValue, input) {
          var parsed = this.formatter.parse(input);
          return parsed && this.calendar.isValid(_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__["NgbDate"].from(parsed)) ? _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__["NgbDate"].from(parsed) : currentValue;
        }
      }]);

      return CustomersComponent;
    }(_BaseComp__WEBPACK_IMPORTED_MODULE_11__["BaseComp"]);

    CustomersComponent.ctorParameters = function () {
      return [{
        type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"]
      }, {
        type: _userservice_service__WEBPACK_IMPORTED_MODULE_1__["UserserviceService"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"]
      }, {
        type: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__["NgbCalendar"]
      }, {
        type: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__["NgbDateParserFormatter"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_9__["Router"]
      }, {
        type: _aes_encryption_decryption_service__WEBPACK_IMPORTED_MODULE_10__["AesEncryptionDecryptionService"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"])(_angular_material_paginator__WEBPACK_IMPORTED_MODULE_4__["MatPaginator"], {
      "static": true
    })], CustomersComponent.prototype, "paginator", void 0);
    CustomersComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
      selector: 'app-customers',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./customers.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/customers/customers.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./customers.component.scss */
      "./src/app/customers/customers.component.scss"))["default"]]
    })], CustomersComponent); // const ELEMENT_DATA: PeriodicElement[] = [
    //   {position: 1, name: 'shravan kumar vishwakarma', email: 'shravan.vishwakarma@avivaindia.com', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 2, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 3, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 4, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 5, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 6, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 7, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 8, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 9, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 10, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 11, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 12, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 13, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 14, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 15, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 16, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 17, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 18, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 19, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 20, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    // ];

    /***/
  },

  /***/
  "./src/app/layout/layout.component.scss":
  /*!**********************************************!*\
    !*** ./src/app/layout/layout.component.scss ***!
    \**********************************************/

  /*! exports provided: default */

  /***/
  function srcAppLayoutLayoutComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".example-container {\n  height: 100%;\n}\n\n.example-sidenav-content {\n  height: 100%;\n}\n\n.example-sidenav {\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  background-color: red;\n}\n\n.full-width {\n  width: 100%;\n}\n\n.menu-button {\n  transition: 300ms ease-in-out;\n  transform: rotate(0deg);\n}\n\n.menu-button.rotated {\n  transform: rotate(180deg);\n}\n\n.submenu {\n  overflow-y: hidden;\n  transition: transform 300ms ease;\n  transform: scaleY(0);\n  transform-origin: top;\n  padding-left: 30px;\n}\n\n.submenu.expanded {\n  transform: scaleY(1);\n}\n\n.example-toolbar {\n  height: 58px;\n}\n\n.active-list-item {\n  color: #052d92 !important;\n  /* Note: You could also use a custom theme */\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zdW5pbHZpc2h3YWthcm1hL0Rlc2t0b3AvcHJvamVjdHMvc21lL3NtZWFkbWluL3NyYy9hcHAvbGF5b3V0L2xheW91dC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvbGF5b3V0L2xheW91dC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLFlBQUE7QUNBSjs7QURHRTtFQUVFLFlBQUE7QUNESjs7QURLRTtFQUNHLHlCQUFBO0tBQUEsc0JBQUE7TUFBQSxxQkFBQTtVQUFBLGlCQUFBO0VBQ0EscUJBQUE7QUNGTDs7QURJRTtFQUNFLFdBQUE7QUNESjs7QURHRTtFQUNFLDZCQUFBO0VBQ0EsdUJBQUE7QUNBSjs7QURFRTtFQUNFLHlCQUFBO0FDQ0o7O0FEQ0U7RUFDRSxrQkFBQTtFQUNBLGdDQUFBO0VBQ0Esb0JBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0FDRUo7O0FEQUU7RUFDRSxvQkFBQTtBQ0dKOztBREFFO0VBQ0ksWUFBQTtBQ0dOOztBREFFO0VBQ0UseUJBQUE7RUFBMkIsNENBQUE7QUNJL0IiLCJmaWxlIjoic3JjL2FwcC9sYXlvdXQvbGF5b3V0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmV4YW1wbGUtY29udGFpbmVyIHtcclxuICAgIC8vIGhlaWdodDogNTAwcHg7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAvLyBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDAsIDAsIDAsIDAuNSk7XHJcbiAgfVxyXG4gIC5leGFtcGxlLXNpZGVuYXYtY29udGVudCB7XHJcbiAgICAvLyBkaXNwbGF5OiBmbGV4O1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgLy8gYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIC8vIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIH1cclxuICAuZXhhbXBsZS1zaWRlbmF2IHtcclxuICAgICB1c2VyLXNlbGVjdDogbm9uZTtcclxuICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZWQ7XHJcbiAgfVxyXG4gIC5mdWxsLXdpZHRoIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gIH1cclxuICAubWVudS1idXR0b24ge1xyXG4gICAgdHJhbnNpdGlvbjogMzAwbXMgZWFzZS1pbi1vdXQ7XHJcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTtcclxuICB9XHJcbiAgLm1lbnUtYnV0dG9uLnJvdGF0ZWQge1xyXG4gICAgdHJhbnNmb3JtOiByb3RhdGUoMTgwZGVnKTtcclxuICB9XHJcbiAgLnN1Ym1lbnUge1xyXG4gICAgb3ZlcmZsb3cteTogaGlkZGVuO1xyXG4gICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDMwMG1zIGVhc2U7XHJcbiAgICB0cmFuc2Zvcm06IHNjYWxlWSgwKTtcclxuICAgIHRyYW5zZm9ybS1vcmlnaW46IHRvcDtcclxuICAgIHBhZGRpbmctbGVmdDogMzBweDtcclxuICB9XHJcbiAgLnN1Ym1lbnUuZXhwYW5kZWQge1xyXG4gICAgdHJhbnNmb3JtOiBzY2FsZVkoMSk7XHJcbiAgfVxyXG5cclxuICAuZXhhbXBsZS10b29sYmFye1xyXG4gICAgICBoZWlnaHQ6IDU4cHg7XHJcbiAgfVxyXG5cclxuICAuYWN0aXZlLWxpc3QtaXRlbSB7XHJcbiAgICBjb2xvcjogIzA1MmQ5MiAhaW1wb3J0YW50OyAvKiBOb3RlOiBZb3UgY291bGQgYWxzbyB1c2UgYSBjdXN0b20gdGhlbWUgKi9cclxuICAgIC8vIGJhY2tncm91bmQtY29sb3I6IGJsdWU7XHJcbiAgfSIsIi5leGFtcGxlLWNvbnRhaW5lciB7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLmV4YW1wbGUtc2lkZW5hdi1jb250ZW50IHtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uZXhhbXBsZS1zaWRlbmF2IHtcbiAgdXNlci1zZWxlY3Q6IG5vbmU7XG4gIGJhY2tncm91bmQtY29sb3I6IHJlZDtcbn1cblxuLmZ1bGwtd2lkdGgge1xuICB3aWR0aDogMTAwJTtcbn1cblxuLm1lbnUtYnV0dG9uIHtcbiAgdHJhbnNpdGlvbjogMzAwbXMgZWFzZS1pbi1vdXQ7XG4gIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xufVxuXG4ubWVudS1idXR0b24ucm90YXRlZCB7XG4gIHRyYW5zZm9ybTogcm90YXRlKDE4MGRlZyk7XG59XG5cbi5zdWJtZW51IHtcbiAgb3ZlcmZsb3cteTogaGlkZGVuO1xuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMzAwbXMgZWFzZTtcbiAgdHJhbnNmb3JtOiBzY2FsZVkoMCk7XG4gIHRyYW5zZm9ybS1vcmlnaW46IHRvcDtcbiAgcGFkZGluZy1sZWZ0OiAzMHB4O1xufVxuXG4uc3VibWVudS5leHBhbmRlZCB7XG4gIHRyYW5zZm9ybTogc2NhbGVZKDEpO1xufVxuXG4uZXhhbXBsZS10b29sYmFyIHtcbiAgaGVpZ2h0OiA1OHB4O1xufVxuXG4uYWN0aXZlLWxpc3QtaXRlbSB7XG4gIGNvbG9yOiAjMDUyZDkyICFpbXBvcnRhbnQ7XG4gIC8qIE5vdGU6IFlvdSBjb3VsZCBhbHNvIHVzZSBhIGN1c3RvbSB0aGVtZSAqL1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/layout/layout.component.ts":
  /*!********************************************!*\
    !*** ./src/app/layout/layout.component.ts ***!
    \********************************************/

  /*! exports provided: LayoutComponent */

  /***/
  function srcAppLayoutLayoutComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LayoutComponent", function () {
      return LayoutComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _BaseComp__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../BaseComp */
    "./src/app/BaseComp.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var LayoutComponent = /*#__PURE__*/function (_BaseComp__WEBPACK_IM2) {
      _inherits(LayoutComponent, _BaseComp__WEBPACK_IM2);

      var _super2 = _createSuper(LayoutComponent);

      function LayoutComponent(router) {
        var _this4;

        _classCallCheck(this, LayoutComponent);

        _this4 = _super2.call(this);
        _this4.router = router;
        _this4.title = 'sme-Dashboard';
        _this4.isExpanded = true;
        _this4.showSubmenu = false;
        _this4.isShowing = false;
        _this4.showSubSubMenu = false;
        return _this4;
      }

      _createClass(LayoutComponent, [{
        key: "mouseenter",
        value: function mouseenter() {
          if (!this.isExpanded) {
            this.isShowing = true;
          }
        }
      }, {
        key: "mouseleave",
        value: function mouseleave() {
          if (!this.isExpanded) {
            this.isShowing = false;
          }
        }
      }, {
        key: "logoutUser",
        value: function logoutUser() {
          this.setSessionStoredItem(this.IS_USER_LOGIN, "0");
          this.router.navigateByUrl("/login"); //console.log("logout");
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return LayoutComponent;
    }(_BaseComp__WEBPACK_IMPORTED_MODULE_2__["BaseComp"]);

    LayoutComponent.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('sidenav', {
      "static": false
    })], LayoutComponent.prototype, "sidenav", void 0);
    LayoutComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-layout',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./layout.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/layout/layout.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./layout.component.scss */
      "./src/app/layout/layout.component.scss"))["default"]]
    })], LayoutComponent);
    /***/
  },

  /***/
  "./src/app/login/login.component.scss":
  /*!********************************************!*\
    !*** ./src/app/login/login.component.scss ***!
    \********************************************/

  /*! exports provided: default */

  /***/
  function srcAppLoginLoginComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "@import url(https://fonts.googleapis.com/css?family=Roboto:300);\n.login-page {\n  width: 360px;\n  padding: 8% 0 0;\n  margin: auto;\n}\n.form {\n  position: relative;\n  z-index: 1;\n  background: #FFFFFF;\n  max-width: 360px;\n  margin: 0 auto 100px;\n  padding: 45px;\n  text-align: center;\n  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);\n}\n.form input {\n  font-family: \"Roboto\", sans-serif;\n  outline: 0;\n  background: #f2f2f2;\n  width: 100%;\n  border: 0;\n  margin: 0 0 15px;\n  padding: 15px;\n  box-sizing: border-box;\n  font-size: 14px;\n}\n.form button {\n  font-family: \"Roboto\", sans-serif;\n  text-transform: uppercase;\n  outline: 0;\n  background: #052d92;\n  width: 100%;\n  border: 0;\n  padding: 15px;\n  color: #FFFFFF;\n  font-size: 14px;\n  transition: all 0.3 ease;\n  cursor: pointer;\n}\n.form button:hover, .form button:active, .form button:focus {\n  background: #052d92;\n}\n.form .message {\n  margin: 15px 0 0;\n  color: #b3b3b3;\n  font-size: 12px;\n}\n.form .message a {\n  color: #052d92;\n  text-decoration: none;\n}\n.form .register-form {\n  display: none;\n}\n.container {\n  position: relative;\n  z-index: 1;\n  max-width: 300px;\n  margin: 0 auto;\n}\n.container:before, .container:after {\n  content: \"\";\n  display: block;\n  clear: both;\n}\n.container .info {\n  margin: 50px auto;\n  text-align: center;\n}\n.container .info h1 {\n  margin: 0 0 15px;\n  padding: 0;\n  font-size: 36px;\n  font-weight: 300;\n  color: #1a1a1a;\n}\n.container .info span {\n  color: #4d4d4d;\n  font-size: 12px;\n}\n.container .info span a {\n  color: #000000;\n  text-decoration: none;\n}\n.container .info span .fa {\n  color: #EF3B3A;\n}\nbody {\n  background: #76b852;\n  /* fallback for old browsers */\n  background: linear-gradient(to left, #76b852, #8DC26F);\n  font-family: \"Roboto\", sans-serif;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zdW5pbHZpc2h3YWthcm1hL0Rlc2t0b3AvcHJvamVjdHMvc21lL3NtZWFkbWluL3NyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2xvZ2luL2xvZ2luLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFRLCtEQUFBO0FBRVI7RUFDRSxZQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7QUNBRjtBREVBO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsMEVBQUE7QUNDRjtBRENBO0VBQ0UsaUNBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtBQ0VGO0FEQUE7RUFDRSxpQ0FBQTtFQUNBLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFFQSx3QkFBQTtFQUNBLGVBQUE7QUNHRjtBRERBO0VBQ0UsbUJBQUE7QUNJRjtBREZBO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQ0tGO0FESEE7RUFDRSxjQUFBO0VBQ0EscUJBQUE7QUNNRjtBREpBO0VBQ0UsYUFBQTtBQ09GO0FETEE7RUFDRSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNRRjtBRE5BO0VBQ0UsV0FBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0FDU0Y7QURQQTtFQUNFLGlCQUFBO0VBQ0Esa0JBQUE7QUNVRjtBRFJBO0VBQ0UsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQ1dGO0FEVEE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQ1lGO0FEVkE7RUFDRSxjQUFBO0VBQ0EscUJBQUE7QUNhRjtBRFhBO0VBQ0UsY0FBQTtBQ2NGO0FEWkE7RUFDRSxtQkFBQTtFQUFxQiw4QkFBQTtFQUlyQixzREFBQTtFQUNBLGlDQUFBO0VBQ0EsbUNBQUE7RUFDQSxrQ0FBQTtBQ2dCRiIsImZpbGUiOiJzcmMvYXBwL2xvZ2luL2xvZ2luLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCB1cmwoaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PVJvYm90bzozMDApO1xyXG5cclxuLmxvZ2luLXBhZ2Uge1xyXG4gIHdpZHRoOiAzNjBweDtcclxuICBwYWRkaW5nOiA4JSAwIDA7XHJcbiAgbWFyZ2luOiBhdXRvO1xyXG59XHJcbi5mb3JtIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgei1pbmRleDogMTtcclxuICBiYWNrZ3JvdW5kOiAjRkZGRkZGO1xyXG4gIG1heC13aWR0aDogMzYwcHg7XHJcbiAgbWFyZ2luOiAwIGF1dG8gMTAwcHg7XHJcbiAgcGFkZGluZzogNDVweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgYm94LXNoYWRvdzogMCAwIDIwcHggMCByZ2JhKDAsIDAsIDAsIDAuMiksIDAgNXB4IDVweCAwIHJnYmEoMCwgMCwgMCwgMC4yNCk7XHJcbn1cclxuLmZvcm0gaW5wdXQge1xyXG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiLCBzYW5zLXNlcmlmO1xyXG4gIG91dGxpbmU6IDA7XHJcbiAgYmFja2dyb3VuZDogI2YyZjJmMjtcclxuICB3aWR0aDogMTAwJTtcclxuICBib3JkZXI6IDA7XHJcbiAgbWFyZ2luOiAwIDAgMTVweDtcclxuICBwYWRkaW5nOiAxNXB4O1xyXG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcbi5mb3JtIGJ1dHRvbiB7XHJcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvXCIsIHNhbnMtc2VyaWY7XHJcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICBvdXRsaW5lOiAwO1xyXG4gIGJhY2tncm91bmQ6ICMwNTJkOTI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYm9yZGVyOiAwO1xyXG4gIHBhZGRpbmc6IDE1cHg7XHJcbiAgY29sb3I6ICNGRkZGRkY7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuMyBlYXNlO1xyXG4gIHRyYW5zaXRpb246IGFsbCAwLjMgZWFzZTtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuLmZvcm0gYnV0dG9uOmhvdmVyLC5mb3JtIGJ1dHRvbjphY3RpdmUsLmZvcm0gYnV0dG9uOmZvY3VzIHtcclxuICBiYWNrZ3JvdW5kOiAjMDUyZDkyO1xyXG59XHJcbi5mb3JtIC5tZXNzYWdlIHtcclxuICBtYXJnaW46IDE1cHggMCAwO1xyXG4gIGNvbG9yOiAjYjNiM2IzO1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxufVxyXG4uZm9ybSAubWVzc2FnZSBhIHtcclxuICBjb2xvcjogIzA1MmQ5MjtcclxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbn1cclxuLmZvcm0gLnJlZ2lzdGVyLWZvcm0ge1xyXG4gIGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuLmNvbnRhaW5lciB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgbWF4LXdpZHRoOiAzMDBweDtcclxuICBtYXJnaW46IDAgYXV0bztcclxufVxyXG4uY29udGFpbmVyOmJlZm9yZSwgLmNvbnRhaW5lcjphZnRlciB7XHJcbiAgY29udGVudDogXCJcIjtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBjbGVhcjogYm90aDtcclxufVxyXG4uY29udGFpbmVyIC5pbmZvIHtcclxuICBtYXJnaW46IDUwcHggYXV0bztcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuLmNvbnRhaW5lciAuaW5mbyBoMSB7XHJcbiAgbWFyZ2luOiAwIDAgMTVweDtcclxuICBwYWRkaW5nOiAwO1xyXG4gIGZvbnQtc2l6ZTogMzZweDtcclxuICBmb250LXdlaWdodDogMzAwO1xyXG4gIGNvbG9yOiAjMWExYTFhO1xyXG59XHJcbi5jb250YWluZXIgLmluZm8gc3BhbiB7XHJcbiAgY29sb3I6ICM0ZDRkNGQ7XHJcbiAgZm9udC1zaXplOiAxMnB4O1xyXG59XHJcbi5jb250YWluZXIgLmluZm8gc3BhbiBhIHtcclxuICBjb2xvcjogIzAwMDAwMDtcclxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbn1cclxuLmNvbnRhaW5lciAuaW5mbyBzcGFuIC5mYSB7XHJcbiAgY29sb3I6ICNFRjNCM0E7XHJcbn1cclxuYm9keSB7XHJcbiAgYmFja2dyb3VuZDogIzc2Yjg1MjsgLyogZmFsbGJhY2sgZm9yIG9sZCBicm93c2VycyAqL1xyXG4gIGJhY2tncm91bmQ6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KHJpZ2h0LCAjNzZiODUyLCAjOERDMjZGKTtcclxuICBiYWNrZ3JvdW5kOiAtbW96LWxpbmVhci1ncmFkaWVudChyaWdodCwgIzc2Yjg1MiwgIzhEQzI2Rik7XHJcbiAgYmFja2dyb3VuZDogLW8tbGluZWFyLWdyYWRpZW50KHJpZ2h0LCAjNzZiODUyLCAjOERDMjZGKTtcclxuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gbGVmdCwgIzc2Yjg1MiwgIzhEQzI2Rik7XHJcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvXCIsIHNhbnMtc2VyaWY7XHJcbiAgLXdlYmtpdC1mb250LXNtb290aGluZzogYW50aWFsaWFzZWQ7XHJcbiAgLW1vei1vc3gtZm9udC1zbW9vdGhpbmc6IGdyYXlzY2FsZTsgICAgICBcclxufSIsIkBpbXBvcnQgdXJsKGh0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Sb2JvdG86MzAwKTtcbi5sb2dpbi1wYWdlIHtcbiAgd2lkdGg6IDM2MHB4O1xuICBwYWRkaW5nOiA4JSAwIDA7XG4gIG1hcmdpbjogYXV0bztcbn1cblxuLmZvcm0ge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHotaW5kZXg6IDE7XG4gIGJhY2tncm91bmQ6ICNGRkZGRkY7XG4gIG1heC13aWR0aDogMzYwcHg7XG4gIG1hcmdpbjogMCBhdXRvIDEwMHB4O1xuICBwYWRkaW5nOiA0NXB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJveC1zaGFkb3c6IDAgMCAyMHB4IDAgcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDVweCA1cHggMCByZ2JhKDAsIDAsIDAsIDAuMjQpO1xufVxuXG4uZm9ybSBpbnB1dCB7XG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiLCBzYW5zLXNlcmlmO1xuICBvdXRsaW5lOiAwO1xuICBiYWNrZ3JvdW5kOiAjZjJmMmYyO1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyOiAwO1xuICBtYXJnaW46IDAgMCAxNXB4O1xuICBwYWRkaW5nOiAxNXB4O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbi5mb3JtIGJ1dHRvbiB7XG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiLCBzYW5zLXNlcmlmO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBvdXRsaW5lOiAwO1xuICBiYWNrZ3JvdW5kOiAjMDUyZDkyO1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyOiAwO1xuICBwYWRkaW5nOiAxNXB4O1xuICBjb2xvcjogI0ZGRkZGRjtcbiAgZm9udC1zaXplOiAxNHB4O1xuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAwLjMgZWFzZTtcbiAgdHJhbnNpdGlvbjogYWxsIDAuMyBlYXNlO1xuICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbi5mb3JtIGJ1dHRvbjpob3ZlciwgLmZvcm0gYnV0dG9uOmFjdGl2ZSwgLmZvcm0gYnV0dG9uOmZvY3VzIHtcbiAgYmFja2dyb3VuZDogIzA1MmQ5Mjtcbn1cblxuLmZvcm0gLm1lc3NhZ2Uge1xuICBtYXJnaW46IDE1cHggMCAwO1xuICBjb2xvcjogI2IzYjNiMztcbiAgZm9udC1zaXplOiAxMnB4O1xufVxuXG4uZm9ybSAubWVzc2FnZSBhIHtcbiAgY29sb3I6ICMwNTJkOTI7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbn1cblxuLmZvcm0gLnJlZ2lzdGVyLWZvcm0ge1xuICBkaXNwbGF5OiBub25lO1xufVxuXG4uY29udGFpbmVyIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB6LWluZGV4OiAxO1xuICBtYXgtd2lkdGg6IDMwMHB4O1xuICBtYXJnaW46IDAgYXV0bztcbn1cblxuLmNvbnRhaW5lcjpiZWZvcmUsIC5jb250YWluZXI6YWZ0ZXIge1xuICBjb250ZW50OiBcIlwiO1xuICBkaXNwbGF5OiBibG9jaztcbiAgY2xlYXI6IGJvdGg7XG59XG5cbi5jb250YWluZXIgLmluZm8ge1xuICBtYXJnaW46IDUwcHggYXV0bztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY29udGFpbmVyIC5pbmZvIGgxIHtcbiAgbWFyZ2luOiAwIDAgMTVweDtcbiAgcGFkZGluZzogMDtcbiAgZm9udC1zaXplOiAzNnB4O1xuICBmb250LXdlaWdodDogMzAwO1xuICBjb2xvcjogIzFhMWExYTtcbn1cblxuLmNvbnRhaW5lciAuaW5mbyBzcGFuIHtcbiAgY29sb3I6ICM0ZDRkNGQ7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cblxuLmNvbnRhaW5lciAuaW5mbyBzcGFuIGEge1xuICBjb2xvcjogIzAwMDAwMDtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xufVxuXG4uY29udGFpbmVyIC5pbmZvIHNwYW4gLmZhIHtcbiAgY29sb3I6ICNFRjNCM0E7XG59XG5cbmJvZHkge1xuICBiYWNrZ3JvdW5kOiAjNzZiODUyO1xuICAvKiBmYWxsYmFjayBmb3Igb2xkIGJyb3dzZXJzICovXG4gIGJhY2tncm91bmQ6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KHJpZ2h0LCAjNzZiODUyLCAjOERDMjZGKTtcbiAgYmFja2dyb3VuZDogLW1vei1saW5lYXItZ3JhZGllbnQocmlnaHQsICM3NmI4NTIsICM4REMyNkYpO1xuICBiYWNrZ3JvdW5kOiAtby1saW5lYXItZ3JhZGllbnQocmlnaHQsICM3NmI4NTIsICM4REMyNkYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gbGVmdCwgIzc2Yjg1MiwgIzhEQzI2Rik7XG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiLCBzYW5zLXNlcmlmO1xuICAtd2Via2l0LWZvbnQtc21vb3RoaW5nOiBhbnRpYWxpYXNlZDtcbiAgLW1vei1vc3gtZm9udC1zbW9vdGhpbmc6IGdyYXlzY2FsZTtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/login/login.component.ts":
  /*!******************************************!*\
    !*** ./src/app/login/login.component.ts ***!
    \******************************************/

  /*! exports provided: LoginComponent */

  /***/
  function srcAppLoginLoginComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginComponent", function () {
      return LoginComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _aes_encryption_decryption_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../aes-encryption-decryption.service */
    "./src/app/aes-encryption-decryption.service.ts");
    /* harmony import */


    var _BaseComp__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../BaseComp */
    "./src/app/BaseComp.ts");

    var LoginComponent = /*#__PURE__*/function (_BaseComp__WEBPACK_IM3) {
      _inherits(LoginComponent, _BaseComp__WEBPACK_IM3);

      var _super3 = _createSuper(LoginComponent);

      function LoginComponent(http, router, aesEncryptionDecryptionService) {
        var _this5;

        _classCallCheck(this, LoginComponent);

        _this5 = _super3.call(this);
        _this5.http = http;
        _this5.router = router;
        _this5.aesEncryptionDecryptionService = aesEncryptionDecryptionService;
        _this5.user_name = "";
        _this5.password = "";
        _this5.ip = "";
        return _this5;
      }

      _createClass(LoginComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this6 = this;

          // routerLink="/layout/customer"
          this.http.get("assets/config.json", {
            responseType: 'text'
          }).subscribe(function (data) {
            try {
              //console.log("data:-"+data);
              //console.log("base_url:-"+JSON.parse(data).base_url);
              _this6.setSessionStoredItem(_this6.BASE_URL, JSON.parse(data).base_url);
            } catch (e) {//console.log(e);
            }
          });
          this.http.get("http://localhost/sme/index.php/api/User/getIP", {
            responseType: 'text'
          }).subscribe(function (data) {
            try {
              //console.log("data:-"+data);
              //console.log("base_url:-"+JSON.parse(data).base_url);
              console.log("ip:-" + data);
              _this6.ip = data;
            } catch (e) {//console.log(e);
            }
          });
        }
      }, {
        key: "loginAdmin",
        value: function loginAdmin() {
          //console.log("user_name:"+this.user_name);
          //console.log("password:"+this.password);
          //console.log("login_attempt:-"+this.getLoginFailedPref());
          // if(this.getLoginFailedPref()>=5){
          //   let lastLoginTime=this.getLastLoginTime();
          //   if(lastLoginTime==""||lastLoginTime==undefined||lastLoginTime==null){
          //     this.makeLogin();
          //   }else{
          //     let currentDate=new Date();
          //     let lastLoginDate=new Date(lastLoginTime);
          //     if(this.getDifferenceBetweenTwoDatesInMin(lastLoginDate,currentDate)>=10){
          //       this.resetLoginFailed();
          //       this.makeLogin();
          //     }else{
          //       alert("Your id is blocked due to multiple login attempts. Please wait for 10 mins");
          //     }
          //   }
          // }else{
          //   this.makeLogin();
          // }
          this.makeLogin();
        }
      }, {
        key: "makeLogin",
        value: function makeLogin() {
          var _this7 = this;

          if (this.user_name == '') {
            alert("please enter username");
            return;
          }

          if (this.password == '') {
            alert("please enter password");
            return;
          }

          var postData = {
            user_name: this.user_name,
            password: this.password,
            ip: this.ip
          };
          var formData = {
            request: this.aesEncryptionDecryptionService.encryptRequest(JSON.stringify(postData))
          };
          var url = this.getSessionStoredItem(this.BASE_URL) + this.LOGIN_URL; //console.log("url:-" + url);

          this.http.post(url, JSON.stringify(formData), {
            responseType: 'text'
          }).subscribe(function (result) {
            try {
              //console.log("data:-" + JSON.stringify(result));
              var parsedData = JSON.parse(result);

              var parsedJSON = _this7.aesEncryptionDecryptionService.parseEncryptedResponse(parsedData.response);

              if (parsedJSON.status == 1) {
                _this7.setSessionStoredItem(_this7.IS_USER_LOGIN, "1"); // this.resetLoginFailed();


                _this7.router.navigateByUrl("/layout/customer");
              } else if (parsedJSON.status == -1) {
                // this.increaseLoginFailedPref();
                alert(parsedJSON.message);
              } else {
                alert("Invalid Credentials");
              }
            } catch (err) {//console.log(err);
            }
          });
        }
      }, {
        key: "setBaseURL",
        value: function setBaseURL() {
          var _this8 = this;

          this.http.get("assets/config.json", {
            responseType: 'text'
          }).subscribe(function (data) {
            try {
              // //console.log("data:-"+data);
              var base_url = JSON.parse(data).base_url; // //console.log("base_url:-"+base_url.toString());

              _this8.setSessionStoredItem(_this8.BASE_URL, base_url.toString()); // //console.log("base url:-"+this.getItem(this.BASE_URL));


              _this8.loginAdmin();
            } catch (e) {//console.log(e);
            }
          });
        }
      }]);

      return LoginComponent;
    }(_BaseComp__WEBPACK_IMPORTED_MODULE_5__["BaseComp"]);

    LoginComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _aes_encryption_decryption_service__WEBPACK_IMPORTED_MODULE_4__["AesEncryptionDecryptionService"]
      }];
    };

    LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-login',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./login.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./login.component.scss */
      "./src/app/login/login.component.scss"))["default"]]
    })], LoginComponent);
    /***/
  },

  /***/
  "./src/app/material.module.ts":
  /*!************************************!*\
    !*** ./src/app/material.module.ts ***!
    \************************************/

  /*! exports provided: MaterialModule */

  /***/
  function srcAppMaterialModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MaterialModule", function () {
      return MaterialModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/material */
    "./node_modules/@angular/material/esm2015/material.js");
    /* harmony import */


    var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/cdk/table */
    "./node_modules/@angular/cdk/esm2015/table.js");
    /* harmony import */


    var _angular_cdk_accordion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/cdk/accordion */
    "./node_modules/@angular/cdk/esm2015/accordion.js");
    /* harmony import */


    var _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/cdk/a11y */
    "./node_modules/@angular/cdk/esm2015/a11y.js");
    /* harmony import */


    var _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/cdk/bidi */
    "./node_modules/@angular/cdk/esm2015/bidi.js");
    /* harmony import */


    var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/cdk/overlay */
    "./node_modules/@angular/cdk/esm2015/overlay.js");
    /* harmony import */


    var _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/cdk/platform */
    "./node_modules/@angular/cdk/esm2015/platform.js");
    /* harmony import */


    var _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/cdk/observers */
    "./node_modules/@angular/cdk/esm2015/observers.js");
    /* harmony import */


    var _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @angular/cdk/portal */
    "./node_modules/@angular/cdk/esm2015/portal.js");
    /**
     * @license
     * Copyright Google LLC All Rights Reserved.
     *
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://angular.io/license
     */

    /**
     * NgModule that includes all Material modules that are required to serve the demo-app.
     */


    var MaterialModule = function MaterialModule() {
      _classCallCheck(this, MaterialModule);
    };

    MaterialModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      exports: [_angular_material__WEBPACK_IMPORTED_MODULE_2__["MatAutocompleteModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatButtonModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatButtonToggleModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatCardModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatCheckboxModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatChipsModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDatepickerModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialogModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatExpansionModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatFormFieldModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatGridListModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatIconModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatInputModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatListModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatMenuModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatPaginatorModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatProgressBarModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatProgressSpinnerModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatRadioModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatRippleModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSelectModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSidenavModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSlideToggleModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSliderModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSnackBarModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSortModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatStepperModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTabsModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatToolbarModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTooltipModule"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatNativeDateModule"], _angular_cdk_table__WEBPACK_IMPORTED_MODULE_3__["CdkTableModule"], _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_5__["A11yModule"], _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_6__["BidiModule"], _angular_cdk_accordion__WEBPACK_IMPORTED_MODULE_4__["CdkAccordionModule"], _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_9__["ObserversModule"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__["OverlayModule"], _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_8__["PlatformModule"], _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_10__["PortalModule"]]
    })], MaterialModule);
    /***/
  },

  /***/
  "./src/app/question-modal/question-modal.component.scss":
  /*!**************************************************************!*\
    !*** ./src/app/question-modal/question-modal.component.scss ***!
    \**************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppQuestionModalQuestionModalComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3F1ZXN0aW9uLW1vZGFsL3F1ZXN0aW9uLW1vZGFsLmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/question-modal/question-modal.component.ts":
  /*!************************************************************!*\
    !*** ./src/app/question-modal/question-modal.component.ts ***!
    \************************************************************/

  /*! exports provided: QuestionModalComponent */

  /***/
  function srcAppQuestionModalQuestionModalComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "QuestionModalComponent", function () {
      return QuestionModalComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var QuestionModalComponent = /*#__PURE__*/function () {
      function QuestionModalComponent() {
        _classCallCheck(this, QuestionModalComponent);
      }

      _createClass(QuestionModalComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.user = JSON.parse(window.sessionStorage.getItem("element"));
        }
      }]);

      return QuestionModalComponent;
    }();

    QuestionModalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-question-modal',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./question-modal.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/question-modal/question-modal.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./question-modal.component.scss */
      "./src/app/question-modal/question-modal.component.scss"))["default"]]
    })], QuestionModalComponent);
    /***/
  },

  /***/
  "./src/app/short-lead/short-lead.component.scss":
  /*!******************************************************!*\
    !*** ./src/app/short-lead/short-lead.component.scss ***!
    \******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppShortLeadShortLeadComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "table {\n  width: 100%;\n}\n\ntr.example-detail-row {\n  height: 0;\n}\n\ntr.example-element-row:not(.example-expanded-row):hover {\n  background: #777;\n}\n\ntr.example-element-row:not(.example-expanded-row):active {\n  background: #efefef;\n}\n\n.example-element-row td {\n  border-bottom-width: 0;\n}\n\n.example-element-detail {\n  overflow: hidden;\n  display: flex;\n}\n\n.example-element-diagram {\n  min-width: 80px;\n  border: 2px solid black;\n  padding: 8px;\n  font-weight: lighter;\n  margin: 8px 0;\n  height: 104px;\n}\n\n.example-element-symbol {\n  font-weight: bold;\n  font-size: 40px;\n  line-height: normal;\n}\n\n.example-element-description {\n  padding: 16px;\n}\n\n.example-element-description-attribution {\n  opacity: 0.5;\n}\n\n.mat-header-cell {\n  font-size: 15px;\n  background-color: #ffd900;\n}\n\n.dialog {\n  max-width: 600px;\n}\n\n.basic-container {\n  width: auto;\n}\n\n.center {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.calendars {\n  flex: 1;\n  display: flex;\n  flex-direction: row;\n  align-items: stretch;\n}\n\n.calendars .column {\n  display: flex;\n  flex-direction: column;\n  align-items: stretch;\n  justify-content: flex-start;\n  padding: 0 4px;\n  flex: 1;\n}\n\n.form-group.hidden {\n  width: 0;\n  margin: 0;\n  border: none;\n  padding: 0;\n}\n\n.custom-day {\n  text-align: center;\n  padding: 0.185rem 0.25rem;\n  display: inline-block;\n  height: 2rem;\n  width: 2rem;\n}\n\n.custom-day.focused {\n  background-color: #e6e6e6;\n}\n\n.custom-day.range, .custom-day:hover {\n  background-color: #0275d8;\n  color: white;\n}\n\nbutton.calendar, button.calendar:active {\n  width: 2.75rem;\n  zoom: 0.8;\n  background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAcCAYAAAAEN20fAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAEUSURBVEiJ7ZQxToVAEIY/YCHGxN6XGOIpnpaEsBSeQC9ArZbm9TZ6ADyBNzAhQGGl8Riv4BLAWAgmkpBYkH1b8FWT2WK/zJ8ZJ4qiI6XUI3ANnGKWBnht2/ZBDRK3hgVGNsCd7/ui+JkEIrKtqurLpEWaphd933+IyI3LEIdpCYCiKD6HcuOa/nwOa0ScJEnk0BJg0UTUWJRl6RxCYEzEmomsIlPU3IPW+grIAbquy+q6fluy/28RIBeRMwDXdXMgXLj/B2uimRXpui4D9sBeRLKl+1N+L+t6RwbWrZliTTTr1oxYtzVWiTQAcRxvTX+eJMnlUDaO1vpZRO5NS0x48sIwfPc87xg4B04MCzQi8hIEwe4bl1DnFMCN2zsAAAAASUVORK5CYII=\") !important;\n  background-repeat: no-repeat;\n  background-size: 23px;\n  background-position: center;\n  border: 0;\n  border-bottom: 1px solid black;\n}\n\n.form-control {\n  border: 0;\n  border-bottom: 1px solid black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zdW5pbHZpc2h3YWthcm1hL0Rlc2t0b3AvcHJvamVjdHMvc21lL3NtZWFkbWluL3NyYy9hcHAvc2hvcnQtbGVhZC9zaG9ydC1sZWFkLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9zaG9ydC1sZWFkL3Nob3J0LWxlYWQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFBO0FDQ0Y7O0FERUE7RUFDRSxTQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtBQ0NGOztBREVBO0VBQ0UsbUJBQUE7QUNDRjs7QURFQTtFQUNFLHNCQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtFQUNBLGFBQUE7QUNDRjs7QURFQTtFQUNFLGVBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0FDQ0Y7O0FERUE7RUFDRSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtBQ0NGOztBREVBO0VBQ0UsYUFBQTtBQ0NGOztBREVBO0VBQ0UsWUFBQTtBQ0NGOztBREVBO0VBQ0UsZUFBQTtFQUNBLHlCQUFBO0FDQ0Y7O0FES0E7RUFFRSxnQkFBQTtBQ0hGOztBRE1BO0VBQ0UsV0FBQTtBQ0hGOztBRE1BO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNIRjs7QURLQTtFQUNFLE9BQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFFQSxvQkFBQTtBQ0hGOztBRE9FO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0Esb0JBQUE7RUFDQSwyQkFBQTtFQUNBLGNBQUE7RUFDQSxPQUFBO0FDTEo7O0FEV0E7RUFDRSxRQUFBO0VBQ0EsU0FBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0FDUkY7O0FEVUE7RUFDRSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQ1BGOztBRFNBO0VBQ0UseUJBQUE7QUNORjs7QURRQTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtBQ0xGOztBRFdBO0VBQ0UsY0FBQTtFQUNBLFNBQUE7RUFDQSwwbEJBQUE7RUFDQSw0QkFBQTtFQUNBLHFCQUFBO0VBQ0EsMkJBQUE7RUFDQSxTQUFBO0VBQ0EsOEJBQUE7QUNSRjs7QURZQTtFQUNFLFNBQUE7RUFDQSw4QkFBQTtBQ1RGIiwiZmlsZSI6InNyYy9hcHAvc2hvcnQtbGVhZC9zaG9ydC1sZWFkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsidGFibGUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG50ci5leGFtcGxlLWRldGFpbC1yb3cge1xyXG4gIGhlaWdodDogMDtcclxufVxyXG5cclxudHIuZXhhbXBsZS1lbGVtZW50LXJvdzpub3QoLmV4YW1wbGUtZXhwYW5kZWQtcm93KTpob3ZlciB7XHJcbiAgYmFja2dyb3VuZDogIzc3NztcclxufVxyXG5cclxudHIuZXhhbXBsZS1lbGVtZW50LXJvdzpub3QoLmV4YW1wbGUtZXhwYW5kZWQtcm93KTphY3RpdmUge1xyXG4gIGJhY2tncm91bmQ6ICNlZmVmZWY7XHJcbn1cclxuXHJcbi5leGFtcGxlLWVsZW1lbnQtcm93IHRkIHtcclxuICBib3JkZXItYm90dG9tLXdpZHRoOiAwO1xyXG59XHJcblxyXG4uZXhhbXBsZS1lbGVtZW50LWRldGFpbCB7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG59XHJcblxyXG4uZXhhbXBsZS1lbGVtZW50LWRpYWdyYW0ge1xyXG4gIG1pbi13aWR0aDogODBweDtcclxuICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcclxuICBwYWRkaW5nOiA4cHg7XHJcbiAgZm9udC13ZWlnaHQ6IGxpZ2h0ZXI7XHJcbiAgbWFyZ2luOiA4cHggMDtcclxuICBoZWlnaHQ6IDEwNHB4O1xyXG59XHJcblxyXG4uZXhhbXBsZS1lbGVtZW50LXN5bWJvbCB7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZm9udC1zaXplOiA0MHB4O1xyXG4gIGxpbmUtaGVpZ2h0OiBub3JtYWw7XHJcbn1cclxuXHJcbi5leGFtcGxlLWVsZW1lbnQtZGVzY3JpcHRpb24ge1xyXG4gIHBhZGRpbmc6IDE2cHg7XHJcbn1cclxuXHJcbi5leGFtcGxlLWVsZW1lbnQtZGVzY3JpcHRpb24tYXR0cmlidXRpb24ge1xyXG4gIG9wYWNpdHk6IDAuNTtcclxufVxyXG5cclxuLm1hdC1oZWFkZXItY2VsbHtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZDkwMDtcclxufVxyXG5cclxuXHJcblxyXG4vLyBkYXRlIHJhbmdlIHBpY2tlclxyXG4uZGlhbG9nIHtcclxuICAvLyBtYXJnaW46IDIwMHB4IGF1dG87XHJcbiAgbWF4LXdpZHRoOiA2MDBweFxyXG59XHJcblxyXG4uYmFzaWMtY29udGFpbmVye1xyXG4gIHdpZHRoOiBhdXRvO1xyXG59XHJcblxyXG4uY2VudGVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLmNhbGVuZGFycyB7XHJcbiAgZmxleDogMTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgLy8ganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XHJcbiAgYWxpZ24taXRlbXM6IHN0cmV0Y2g7XHJcbiAgLy8gbWFyZ2luOiAwIC00cHg7XHJcblxyXG5cclxuICAuY29sdW1uIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYWxpZ24taXRlbXM6IHN0cmV0Y2g7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XHJcbiAgICBwYWRkaW5nOiAwIDRweDtcclxuICAgIGZsZXg6IDE7XHJcbiAgfVxyXG59XHJcblxyXG4vL2RhdGUgcGlja2VyIGNzc1xyXG5cclxuLmZvcm0tZ3JvdXAuaGlkZGVuIHtcclxuICB3aWR0aDogMDtcclxuICBtYXJnaW46IDA7XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIHBhZGRpbmc6IDA7XHJcbn1cclxuLmN1c3RvbS1kYXkge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBwYWRkaW5nOiAwLjE4NXJlbSAwLjI1cmVtO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBoZWlnaHQ6IDJyZW07XHJcbiAgd2lkdGg6IDJyZW07XHJcbn1cclxuLmN1c3RvbS1kYXkuZm9jdXNlZCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcclxufVxyXG4uY3VzdG9tLWRheS5yYW5nZSwgLmN1c3RvbS1kYXk6aG92ZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigyLCAxMTcsIDIxNik7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG59XHJcbi5jdXN0b20tZGF5LmZhZGVkIHtcclxuICAvL2JhY2tncm91bmQtY29sb3I6IHJnYmEoMiwgMTE3LCAyMTYsIDAuNSk7XHJcbn1cclxuXHJcbmJ1dHRvbi5jYWxlbmRhciwgYnV0dG9uLmNhbGVuZGFyOmFjdGl2ZSB7XHJcbiAgd2lkdGg6IDIuNzVyZW07XHJcbiAgem9vbTogMC44O1xyXG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFDSUFBQUFjQ0FZQUFBQUVOMjBmQUFBQUJITkNTVlFJQ0FnSWZBaGtpQUFBQUFsd1NGbHpBQUFPeEFBQURzUUJsU3NPR3dBQUFCbDBSVmgwVTI5bWRIZGhjbVVBZDNkM0xtbHVhM05qWVhCbExtOXlaNXZ1UEJvQUFBRVVTVVJCVkVpSjdaUXhUb1ZBRUlZL1lDSEd4TjZYR09JcG5wYUVzQlNlUUM5QXJaYm05VFo2QUR5Qk56QWhRR0dsOFJpdjRCTEFXQWdta3BCWWtIMWI4RldUMldLL3pKOFpKNHFpSTZYVUkzQU5uR0tXQm5odDIvWkJEUkszaGdWR05zQ2Q3L3VpK0prRUlyS3RxdXJMcEVXYXBoZDkzMytJeUkzTEVJZHBDWUNpS0Q2SGN1T2EvbndPYTBTY0pFbmswQkpnMFVUVVdKUmw2UnhDWUV6RW1vbXNJbFBVM0lQVytncklBYnF1eStxNmZsdXkvMjhSSUJlUk13RFhkWE1nWExqL0IydWltUlhwdWk0RDlzQmVSTEtsKzFOK0wrdDZSd2JXclpsaVRUVHIxb3hZdHpWV2lUUUFjUnh2VFgrZUpNbmxVRGFPMXZwWlJPNU5TMHg0OHNJd2ZQYzg3eGc0QjA0TUN6UWk4aElFd2U0YmwxRG5GTUNOMnpzQUFBQUFTVVZPUks1Q1lJST0nKSAhaW1wb3J0YW50O1xyXG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgYmFja2dyb3VuZC1zaXplOiAyM3B4O1xyXG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuICBib3JkZXI6IDA7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGJsYWNrO1xyXG59XHJcbi8vZGF0ZSBwaWNrZXIgY3NzXHJcblxyXG4uZm9ybS1jb250cm9se1xyXG4gIGJvcmRlcjogMDtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgYmxhY2s7XHJcbn1cclxuIiwidGFibGUge1xuICB3aWR0aDogMTAwJTtcbn1cblxudHIuZXhhbXBsZS1kZXRhaWwtcm93IHtcbiAgaGVpZ2h0OiAwO1xufVxuXG50ci5leGFtcGxlLWVsZW1lbnQtcm93Om5vdCguZXhhbXBsZS1leHBhbmRlZC1yb3cpOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogIzc3Nztcbn1cblxudHIuZXhhbXBsZS1lbGVtZW50LXJvdzpub3QoLmV4YW1wbGUtZXhwYW5kZWQtcm93KTphY3RpdmUge1xuICBiYWNrZ3JvdW5kOiAjZWZlZmVmO1xufVxuXG4uZXhhbXBsZS1lbGVtZW50LXJvdyB0ZCB7XG4gIGJvcmRlci1ib3R0b20td2lkdGg6IDA7XG59XG5cbi5leGFtcGxlLWVsZW1lbnQtZGV0YWlsIHtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgZGlzcGxheTogZmxleDtcbn1cblxuLmV4YW1wbGUtZWxlbWVudC1kaWFncmFtIHtcbiAgbWluLXdpZHRoOiA4MHB4O1xuICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcbiAgcGFkZGluZzogOHB4O1xuICBmb250LXdlaWdodDogbGlnaHRlcjtcbiAgbWFyZ2luOiA4cHggMDtcbiAgaGVpZ2h0OiAxMDRweDtcbn1cblxuLmV4YW1wbGUtZWxlbWVudC1zeW1ib2wge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zaXplOiA0MHB4O1xuICBsaW5lLWhlaWdodDogbm9ybWFsO1xufVxuXG4uZXhhbXBsZS1lbGVtZW50LWRlc2NyaXB0aW9uIHtcbiAgcGFkZGluZzogMTZweDtcbn1cblxuLmV4YW1wbGUtZWxlbWVudC1kZXNjcmlwdGlvbi1hdHRyaWJ1dGlvbiB7XG4gIG9wYWNpdHk6IDAuNTtcbn1cblxuLm1hdC1oZWFkZXItY2VsbCB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZDkwMDtcbn1cblxuLmRpYWxvZyB7XG4gIG1heC13aWR0aDogNjAwcHg7XG59XG5cbi5iYXNpYy1jb250YWluZXIge1xuICB3aWR0aDogYXV0bztcbn1cblxuLmNlbnRlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uY2FsZW5kYXJzIHtcbiAgZmxleDogMTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgYWxpZ24taXRlbXM6IHN0cmV0Y2g7XG59XG4uY2FsZW5kYXJzIC5jb2x1bW4ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBhbGlnbi1pdGVtczogc3RyZXRjaDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICBwYWRkaW5nOiAwIDRweDtcbiAgZmxleDogMTtcbn1cblxuLmZvcm0tZ3JvdXAuaGlkZGVuIHtcbiAgd2lkdGg6IDA7XG4gIG1hcmdpbjogMDtcbiAgYm9yZGVyOiBub25lO1xuICBwYWRkaW5nOiAwO1xufVxuXG4uY3VzdG9tLWRheSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogMC4xODVyZW0gMC4yNXJlbTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBoZWlnaHQ6IDJyZW07XG4gIHdpZHRoOiAycmVtO1xufVxuXG4uY3VzdG9tLWRheS5mb2N1c2VkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcbn1cblxuLmN1c3RvbS1kYXkucmFuZ2UsIC5jdXN0b20tZGF5OmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAyNzVkODtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG5idXR0b24uY2FsZW5kYXIsIGJ1dHRvbi5jYWxlbmRhcjphY3RpdmUge1xuICB3aWR0aDogMi43NXJlbTtcbiAgem9vbTogMC44O1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCJkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUNJQUFBQWNDQVlBQUFBRU4yMGZBQUFBQkhOQ1NWUUlDQWdJZkFoa2lBQUFBQWx3U0ZsekFBQU94QUFBRHNRQmxTc09Hd0FBQUJsMFJWaDBVMjltZEhkaGNtVUFkM2QzTG1sdWEzTmpZWEJsTG05eVo1dnVQQm9BQUFFVVNVUkJWRWlKN1pReFRvVkFFSVkvWUNIR3hONlhHT0lwbnBhRXNCU2VRQzlBclpibTlUWjZBRHlCTnpBaFFHR2w4Uml2NEJMQVdBZ21rcEJZa0gxYjhGV1QyV0sveko4Wko0cWlJNlhVSTNBTm5HS1dCbmh0Mi9aQkRSSzNoZ1ZHTnNDZDcvdWkrSmtFSXJLdHF1ckxwRVdhcGhkOTMzK0l5STNMRUlkcENZQ2lLRDZIY3VPYS9ud09hMFNjSkVuazBCSmcwVVRVV0pSbDZSeENZRXpFbW9tc0lsUFUzSVBXK2dySUFicXV5K3E2Zmx1eS8yOFJJQmVSTXdEWGRYTWdYTGovQjJ1aW1SWHB1aTREOXNCZVJMS2wrMU4rTCt0NlJ3YldyWmxpVFRUcjFveFl0elZXaVRRQWNSeHZUWCtlSk1ubFVEYU8xdnBaUk81TlMweDQ4c0l3ZlBjODd4ZzRCMDRNQ3pRaThoSUV3ZTRibDFEbkZNQ04yenNBQUFBQVNVVk9SSzVDWUlJPVwiKSAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IDIzcHg7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgYm9yZGVyOiAwO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgYmxhY2s7XG59XG5cbi5mb3JtLWNvbnRyb2wge1xuICBib3JkZXI6IDA7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBibGFjaztcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/short-lead/short-lead.component.ts":
  /*!****************************************************!*\
    !*** ./src/app/short-lead/short-lead.component.ts ***!
    \****************************************************/

  /*! exports provided: ShortLeadComponent */

  /***/
  function srcAppShortLeadShortLeadComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ShortLeadComponent", function () {
      return ShortLeadComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _userservice_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../userservice.service */
    "./src/app/userservice.service.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/material/table */
    "./node_modules/@angular/material/esm2015/table.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ng-bootstrap/ng-bootstrap */
    "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _aes_encryption_decryption_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../aes-encryption-decryption.service */
    "./src/app/aes-encryption-decryption.service.ts");
    /* harmony import */


    var _BaseComp__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../BaseComp */
    "./src/app/BaseComp.ts");
    /* harmony import */


    var file_saver__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! file-saver */
    "./node_modules/file-saver/dist/FileSaver.min.js");
    /* harmony import */


    var file_saver__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_10__);

    var ShortLeadComponent = /*#__PURE__*/function (_BaseComp__WEBPACK_IM4) {
      _inherits(ShortLeadComponent, _BaseComp__WEBPACK_IM4);

      var _super4 = _createSuper(ShortLeadComponent);

      function ShortLeadComponent(http, userservice, calendar, formatter, router, aesEncryptionDecryptionService) {
        var _this9;

        _classCallCheck(this, ShortLeadComponent);

        _this9 = _super4.call(this);
        _this9.http = http;
        _this9.userservice = userservice;
        _this9.calendar = calendar;
        _this9.formatter = formatter;
        _this9.router = router;
        _this9.aesEncryptionDecryptionService = aesEncryptionDecryptionService; //date ngb picker

        _this9.hoveredDate = null; //date ngb picker

        _this9.showdateranger = false;
        _this9.displayedColumns = ['position', 'name', 'DOB', 'phone_number', 'email', 'Company_name', 'city'];
        _this9.users = [];
        _this9.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_4__["MatTableDataSource"](_this9.users);
        _this9.picker1 = "2020-05-26";
        _this9.from_date = "";
        _this9.to_date = "";
        _this9.dateF = new Date();
        _this9.dateT = new Date();

        if (_this9.getSessionStoredItem(_this9.IS_USER_LOGIN) != "1") {
          _this9.router.navigateByUrl("/login");
        }

        _this9.from_date = _this9.setDate();
        _this9.to_date = _this9.setDate();
        return _this9;
      }

      _createClass(ShortLeadComponent, [{
        key: "formatNumber",
        value: function formatNumber(num) {
          if (num.length == 1) {
            return "0" + num;
          }

          return num;
        }
      }, {
        key: "setDate",
        value: function setDate() {
          var d = new Date();
          var date = this.formatNumber(d.getDate().toString());
          var month = this.formatNumber((d.getMonth() + 1).toString());
          var year = d.getFullYear();
          var finalDate = year + "-" + month + "-" + date;
          return finalDate;
        }
      }, {
        key: "searchUsers",
        value: function searchUsers() {
          // this.from_date=this.dateF.year + "-" + this.formatNumber(this.dateF.month.toString()) + "-" + this.formatNumber(this.dateF.day.toString());
          // this.to_date=this.dateT.year + "-" + this.formatNumber(this.dateT.month.toString()) + "-" + this.formatNumber(this.dateT.day.toString());
          this.from_date = this.dateF.getFullYear() + "-" + this.formatNumber((this.dateF.getMonth() + 1).toString()) + "-" + this.formatNumber(this.dateF.getDate().toString()) + " 00:00:00";
          this.to_date = this.dateT.getFullYear() + "-" + this.formatNumber((this.dateT.getMonth() + 1).toString()) + "-" + this.formatNumber(this.dateT.getDate().toString()) + " 23:59:59";
          var date1 = new Date(this.from_date);
          var date2 = new Date(this.to_date);

          if (date2 > date1) {
            // console.log("fromDate:-"+this.from_date);
            // console.log("toDate:-"+this.to_date);
            this.getAllUser();
          } else {
            alert("End date should be greater than Start date");
          } // this.from_date = this.fromDate.year + "-" + this.formatNumber(this.fromDate.month.toString()) + "-" + this.formatNumber(this.fromDate.day.toString());
          // //console.log("from_date:-"+this.from_date);
          // this.to_date = this.toDate.year + "-" + this.formatNumber(this.toDate.month.toString()) + "-" + this.formatNumber(this.toDate.day.toString());
          // //console.log("to_date:-"+this.to_date);

        }
      }, {
        key: "export",
        value: function _export() {
          this.from_date = this.dateF.getFullYear() + "-" + this.formatNumber((this.dateF.getMonth() + 1).toString()) + "-" + this.formatNumber(this.dateF.getDate().toString()) + " 00:00:00";
          this.to_date = this.dateT.getFullYear() + "-" + this.formatNumber((this.dateT.getMonth() + 1).toString()) + "-" + this.formatNumber(this.dateT.getDate().toString()) + " 23:59:59";
          var date1 = new Date(this.from_date);
          var date2 = new Date(this.to_date);

          if (date2 > date1) {
            // console.log("fromDate:-"+this.from_date);
            // console.log("toDate:-"+this.to_date);
            this.from_date = this.dateF.getFullYear() + "-" + this.formatNumber((this.dateF.getMonth() + 1).toString()) + "-" + this.formatNumber(this.dateF.getDate().toString());
            this.to_date = this.dateT.getFullYear() + "-" + this.formatNumber((this.dateT.getMonth() + 1).toString()) + "-" + this.formatNumber(this.dateT.getDate().toString());
            this.getSheet();
          } else {
            alert("End date should be greater than Start date");
          } // this.from_date = this.fromDate.year + "-" + this.formatNumber(this.fromDate.month.toString()) + "-" + this.formatNumber(this.fromDate.day.toString());
          // //console.log("from_date:-"+this.from_date);
          // this.to_date = this.toDate.year + "-" + this.formatNumber(this.toDate.month.toString()) + "-" + this.formatNumber(this.toDate.day.toString());
          // //console.log("to_date:-"+this.to_date);
          // this.getSheet();

        }
      }, {
        key: "getSheet",
        value: function getSheet() {
          var _this10 = this;

          var url = this.getSessionStoredItem(this.BASE_URL) + this.GET_ALL_SHORT_LEAD + '?from_date=' + this.from_date + "&to_date=" + this.to_date; //console.log("url:-"+url);
          // window.open(url);

          this.http.get(url, {
            responseType: 'arraybuffer'
          }).subscribe(function (data) {
            try {
              //console.log('data received:-' + data);
              Object(file_saver__WEBPACK_IMPORTED_MODULE_10__["saveAs"])(new Blob([data], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetxml.sheet'
              }), _this10.from_date + _this10.to_date + ".xlsx"); // let parsedJSON = JSON.parse(data);
              //console.log("response:-" + parsedJSON.response);
              //console.log("parsedResponse:-" + JSON.stringify(this.aesEncryptionDecryptionService.parseEncryptedResponse(parsedJSON.response)));
            } catch (e) {//console.log(e);
            }
          });
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          this.searchUsers();
          this.dataSource.paginator = this.paginator;
        }
      }, {
        key: "showDate",
        value: function showDate() {
          this.showdateranger = !this.showdateranger;
        }
      }, {
        key: "getAllUser",
        value: function getAllUser() {
          var _this11 = this;

          // let resp = this.userservice.allusers();
          // resp.subscribe(report=>this.dataSource.data=report as AllUsers[]);
          this.users = [];
          var url = this.getSessionStoredItem(this.BASE_URL) + this.GET_ALL_USERS; //console.log("url:-" + url);

          var postData = {
            from_date: this.from_date,
            to_date: this.to_date
          };
          var formData = {
            request: this.aesEncryptionDecryptionService.encryptRequest(JSON.stringify(postData))
          };
          this.http.post(url, JSON.stringify(formData), {
            responseType: 'text'
          }).subscribe(function (result) {
            try {
              //console.log("data:-" + JSON.stringify(result));
              var parsedData = JSON.parse(result);

              var parsedJSON = _this11.aesEncryptionDecryptionService.parseEncryptedResponse(parsedData.response);

              if (parsedJSON.status == 1) {
                for (var i = 0; i < parsedJSON.result.length; i++) {
                  if (parsedJSON.result[i].businessData == null || parsedJSON.result[i].employeeData == null || parsedJSON.result[i].hofData == null) {
                    var user = {
                      user_id: parsedJSON.result[i].user_id,
                      salutation: parsedJSON.result[i].salutation,
                      name: parsedJSON.result[i].name,
                      dob: parsedJSON.result[i].dob,
                      mobile: parsedJSON.result[i].mobile,
                      email_id: parsedJSON.result[i].email_id,
                      company_name: parsedJSON.result[i].company_name,
                      city: parsedJSON.result[i].city,
                      aviva_emp_id: parsedJSON.result[i].aviva_emp_id,
                      added_on: parsedJSON.result[i].added_on
                    };

                    _this11.users.push(user);
                  }
                }

                _this11.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_4__["MatTableDataSource"](_this11.users);
              }
            } catch (err) {//console.log(err);
            }
          });
        } //  for ngb date picker

      }, {
        key: "onDateSelection",
        value: function onDateSelection(date) {
          if (!this.fromDate && !this.toDate) {
            this.fromDate = date;
          } else if (this.fromDate && !this.toDate && date && date.after(this.fromDate)) {
            this.toDate = date;
          } else {
            this.toDate = null;
            this.fromDate = date;
          }
        }
      }, {
        key: "isHovered",
        value: function isHovered(date) {
          return this.fromDate && !this.toDate && this.hoveredDate && date.after(this.fromDate) && date.before(this.hoveredDate);
        }
      }, {
        key: "isInside",
        value: function isInside(date) {
          return this.toDate && date.after(this.fromDate) && date.before(this.toDate);
        }
      }, {
        key: "isRange",
        value: function isRange(date) {
          return date.equals(this.fromDate) || this.toDate && date.equals(this.toDate) || this.isInside(date) || this.isHovered(date);
        }
      }, {
        key: "validateInput",
        value: function validateInput(currentValue, input) {
          var parsed = this.formatter.parse(input);
          return parsed && this.calendar.isValid(_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbDate"].from(parsed)) ? _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbDate"].from(parsed) : currentValue;
        }
      }]);

      return ShortLeadComponent;
    }(_BaseComp__WEBPACK_IMPORTED_MODULE_9__["BaseComp"]);

    ShortLeadComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
      }, {
        type: _userservice_service__WEBPACK_IMPORTED_MODULE_1__["UserserviceService"]
      }, {
        type: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbCalendar"]
      }, {
        type: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbDateParserFormatter"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"]
      }, {
        type: _aes_encryption_decryption_service__WEBPACK_IMPORTED_MODULE_8__["AesEncryptionDecryptionService"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])(_angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"], {
      "static": true
    })], ShortLeadComponent.prototype, "paginator", void 0);
    ShortLeadComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
      selector: 'app-short-lead',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./short-lead.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/short-lead/short-lead.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./short-lead.component.scss */
      "./src/app/short-lead/short-lead.component.scss"))["default"]]
    })], ShortLeadComponent); //
    // const ELEMENT_DATA: PeriodicElement[] = [
    //   {position: 1, name: 'shravan kumar vishwakarma', email: 'shravan.vishwakarma@avivaindia.com', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 2, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 3, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 4, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 5, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 6, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 7, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 8, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 9, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 10, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 11, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 12, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 13, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 14, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 15, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 16, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 17, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 18, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 19, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    //   {position: 20, name: 'Hydrogen', email: 'email', phone_number: 7665338191, date: '25/05/2020'},
    // ];

    /***/
  },

  /***/
  "./src/app/userservice.service.ts":
  /*!****************************************!*\
    !*** ./src/app/userservice.service.ts ***!
    \****************************************/

  /*! exports provided: UserserviceService */

  /***/
  function srcAppUserserviceServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UserserviceService", function () {
      return UserserviceService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");

    var UserserviceService = /*#__PURE__*/function () {
      function UserserviceService(http) {
        _classCallCheck(this, UserserviceService);

        this.http = http;
      }

      _createClass(UserserviceService, [{
        key: "allusers",
        value: function allusers() {
          this.http.get('http://localhost/sme/index.php/api/User/getAllUsers');
        }
      }]);

      return UserserviceService;
    }();

    UserserviceService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    UserserviceService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], UserserviceService);
    /***/
  },

  /***/
  "./src/environments/environment.ts":
  /*!*****************************************!*\
    !*** ./src/environments/environment.ts ***!
    \*****************************************/

  /*! exports provided: environment */

  /***/
  function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "environment", function () {
      return environment;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js"); // This file can be replaced during build by using the `fileReplacements` array.
    // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
    // The list of file replacements can be found in `angular.json`.


    var environment = {
      production: false
    };
    /*
     * For easier debugging in development mode, you can import the following file
     * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
     *
     * This import should be commented out in production mode because it will have a negative impact
     * on performance if an error is thrown.
     */
    // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

    /***/
  },

  /***/
  "./src/main.ts":
  /*!*********************!*\
    !*** ./src/main.ts ***!
    \*********************/

  /*! no exports provided */

  /***/
  function srcMainTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var hammerjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! hammerjs */
    "./node_modules/hammerjs/hammer.js");
    /* harmony import */


    var hammerjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_1__);
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/platform-browser-dynamic */
    "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
    /* harmony import */


    var _app_app_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./app/app.module */
    "./src/app/app.module.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./environments/environment */
    "./src/environments/environment.ts");

    if (_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].production) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["enableProdMode"])();
    }

    Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_4__["AppModule"])["catch"](function (err) {
      return console.error(err);
    });
    /***/
  },

  /***/
  0:
  /*!***************************!*\
    !*** multi ./src/main.ts ***!
    \***************************/

  /*! no static exports found */

  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__(
    /*! /Users/sunilvishwakarma/Desktop/projects/sme/smeadmin/src/main.ts */
    "./src/main.ts");
    /***/
  }
}, [[0, "runtime", "vendor"]]]);
//# sourceMappingURL=main-es5.js.map