<?php

require APPPATH . 'libraries/REST_Controller.php';
header('Access-Control-Allow-Origin: *');
header("Cache-Control: no-cache,no-store, must-revalidate,pre-check=0,max-age=0,s-maxage=0");
header("Pragma: no-cache"); //HTTP 1.0
header("Expires: 0");

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
     
class User extends REST_Controller {
    
     
    public function __construct() {
       parent::__construct();
       $this->load->database();
       $this->load->model('UserModel');
       $this->load->model('PdfModel');
        $this->load->library('Encryption');
    }

    public function getIP_get(){
		$service_url     = "http://checkip.amazonaws.com/";
		$curl            = curl_init($service_url);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_POST, false);
//		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		$curl_response   = curl_exec($curl);
		curl_close($curl);

		echo $curl_response;
	}
     
    public function test_get(){
        echo $this->Encryption->checkMethod();
    }

    public function parseRequest($data){

        $password="AVIVASME#2020";

        $request=$data['request'];
        $data=explode("%A%T",$request);
        $encString=$data[0];
        $iv=$data[1];
        $s=$data[2];

        $dec_arr=array('ct'=>$encString,'s'=>$s,'iv'=>$iv);


        return $this->cryptoJsAesDecrypt($password,json_encode($dec_arr));
    }

    public function parseTextRequest($request){

        $password="AVIVASME#2020";

        $data=explode("%A%T",$request);
        $encString=$data[0];
        $iv=$data[1];
        $s=$data[2];

        $dec_arr=array('ct'=>$encString,'s'=>$s,'iv'=>$iv);
        // echo "<br>requ:-".json_encode($dec_arr);

        return $this->cryptoJsAesDecrypt($password,json_encode($dec_arr));

    }

    public function encryptResponse($str){
        $password="AVIVASME#2020";
        $encryption=$this->cryptoJsAesEncrypt($password,$str);
        // echo "<br>encrypted string:-".$encryption;
        $encryptionArr=json_decode($encryption,true);
        $responseString=$encryptionArr['ct']."%A%T".$encryptionArr['iv']."%A%T".$encryptionArr['s'];
        return $responseString;
    }

    function cryptoJsAesDecrypt($passphrase, $jsonString){

        // echo "jsonString:-".$jsonString;

        $jsondata = json_decode($jsonString, true);
        $salt = hex2bin($jsondata["s"]);
        $ct = base64_decode($jsondata["ct"]);
        $iv  = hex2bin($jsondata["iv"]);
        $concatedPassphrase = $passphrase.$salt;
        $md5 = array();
        $md5[0] = md5($concatedPassphrase, true);
        $result = $md5[0];
        for ($i = 1; $i < 3; $i++) {
            $md5[$i] = md5($md5[$i - 1].$concatedPassphrase, true);
            $result .= $md5[$i];
        }
        $key = substr($result, 0, 32);
        $data = openssl_decrypt($ct, 'aes-256-cbc', $key, true, $iv);
        return json_decode($data, true);
    }

    /**
    * Encrypt value to a cryptojs compatiable json encoding string
    *
    * @param mixed $passphrase
    * @param mixed $value
    * @return string
    */
    function cryptoJsAesEncrypt($passphrase, $value){
        $salt = openssl_random_pseudo_bytes(8);
        $salted = '';
        $dx = '';
        while (strlen($salted) < 48) {
            $dx = md5($dx.$passphrase.$salt, true);
            $salted .= $dx;
        }
        $key = substr($salted, 0, 32);
        $iv  = substr($salted, 32,16);
        $encrypted_data = openssl_encrypt(json_encode($value), 'aes-256-cbc', $key, true, $iv);
        $data = array("ct" => base64_encode($encrypted_data), "iv" => bin2hex($iv), "s" => bin2hex($salt));
        return json_encode($data);
    }


    public function checkAdminLogin_post(){
		

        $_POST = $this->parseRequest(json_decode(file_get_contents("php://input"), true));
        
        $username=$_POST["user_name"];
        $password=$_POST["password"];
        $ip=$_POST["ip"];
//		echo "json:-".json_encode($admin_user);

		if($this->UserModel->fetchFailedAdminCount($ip,$username)>=5){
			$response=array("response"=>$this->encryptResponse(array('status'=>-1,'message'=>'Your id is blocked due to multiple login attempts. Please wait for 10 mins')));
			$this->set_response($response);
		}else{
			$admin_user=$this->PdfModel->getAdminUser($username,$password);
			if($admin_user){
				$response=array("response"=>$this->encryptResponse(array('status'=>1,'message'=>'users found')));
				$this->set_response($response);
			}else{
				$this->UserModel->failedAdmin($ip, $username);
				$response=array("response"=>$this->encryptResponse(array('status'=>0,'message'=>'no user found')));
				$this->set_response($response);
			}
		}
	}



    public function getAllUsers_post(){

        $_POST = $this->parseRequest(json_decode(file_get_contents("php://input"), true));
        
        $from_date=$_POST["from_date"];
        $to_date=$_POST["to_date"];

    	$all_users=$this->PdfModel->getAllUsersFROMTO($from_date,$to_date);
    	if($all_users){
    		$userList=array();
    		for($i=0;$i<count($all_users);$i++){

				$userData=$this->PdfModel->getUser($all_users[$i]->user_id);
				// echo "userdata:-".json_encode($userData);
				$userData->businessData=$this->PdfModel->getBusinessByUserID($all_users[$i]->user_id);
				$userData->employeeData=$this->PdfModel->getEmployerByUserID($all_users[$i]->user_id);
				$userData->hofData=$this->PdfModel->getHOFByUserID($all_users[$i]->user_id);

    			array_push($userList,$userData);
			}


            $response=array("response"=>$this->encryptResponse(array('status'=>1,'message'=>'users found','result'=>$userList)));

            $this->set_response($response);

		}else{
            $response=array("response"=>$this->encryptResponse(array('status'=>0,'message'=>'users not found')));

            $this->set_response($response);
		}
	}

    public function getAllUsersExcel_get(){


        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1',  'Salutation');
        $sheet->setCellValue('B1',  'Name');
        $sheet->setCellValue('C1',  'Date of Birth');
        $sheet->setCellValue('D1',  'Mobile Number');
        $sheet->setCellValue('E1',  'Email ID');
        $sheet->setCellValue('F1',  'Company Name');
        $sheet->setCellValue('G1',  'City');
        $sheet->setCellValue('H1',  'Aviva Employee Id');
        $sheet->setCellValue('I1',  'Added On');

        $sheet->setCellValue('J1',  'How is your company structured?');
        $sheet->setCellValue('K1',  'What is the partnerwise shareholding?');
        $sheet->setCellValue('L1',  'What is the annual turnover of your company?');
        $sheet->setCellValue('M1',  'What is the total value of assets of your company?');
        $sheet->setCellValue('N1',  'Are you planning any business expansion in the next 5 years?');
        $sheet->setCellValue('O1',  'Have you taken any loans for your business? If yes, for what purpose?');
        $sheet->setCellValue('P1',  'What is your current unsecured loan outstanding? ');

        $sheet->setCellValue('Q1',  'How many on roll employees do you have?');
        $sheet->setCellValue('R1',  'How many of your current employees are critical to the business (key people)?');
        $sheet->setCellValue('S1',  'When Key Employees leave, is it a challenge for your business?');
        $sheet->setCellValue('T1',  'What business insurance solutions have you opted for?');
        $sheet->setCellValue('U1',  'Have you made provisions for gratuity for your employees?');
        $sheet->setCellValue('V1',  'Do your employees have a PF facility? If yes, have you opted for an EDLI scheme?');

        $sheet->setCellValue('W1',  'Describe your immediate family/dependents.');
        $sheet->setCellValue('X1',  'What is your current life insurance cover? (In Lacs)');
        $sheet->setCellValue('Y1',  'Have you purchased any Insurance Plan under MWP Act to protect your family?');
        $sheet->setCellValue('Z1',  'What is your annual income? (In lacs)');
        $sheet->setCellValue('AA1',  'What is the approximate fluctuation in your annual income?');
        $sheet->setCellValue('AB1',  'When your income is lower, how do you manage family expenses?');
        $sheet->setCellValue('AC1',  'Have you made any specific investments for your family?');
        $sheet->setCellValue('AD1',  'How prepared is your family to manage household expenses in case of any unfortunate event?');
        $sheet->setCellValue('AE1',  'Quality education is very expensive. Have you started planning for your child/children’s education?');
        $sheet->setCellValue('AF1',  'Have you planned for your retirement years?');
        

//        $from_date=$_GET["from_date"];
//        $to_date=$_GET["to_date"];

//		$_POST = $this->parseRequest(json_decode(file_get_contents("php://input"), true));
//		$_POST = json_decode(file_get_contents("php://input"), true);

//		$from_date=$_POST["from_date"];
//		$to_date=$_POST["to_date"];

		$from_date=$_GET["from_date"];
		$to_date=$_GET["to_date"];

//		echo "from_date:-".$from_date;
//		echo "to_date:-".$to_date;

        $all_users=$this->PdfModel->getAllUsersFROMTO($from_date,$to_date);

        if($all_users){
            $userList=array();
            $businessList=array();
            $employeeList=array();
            $hofList=array();
            for($i=0;$i<count($all_users);$i++){

                $userdata=$this->PdfModel->getUser($all_users[$i]->user_id);
                // echo json_encode($userdata);
                // echo "userdata:-".json_encode($userData);
                $businessData=$this->PdfModel->getBusinessByUserID($all_users[$i]->user_id);
                $employeeData=$this->PdfModel->getEmployerByUserID($all_users[$i]->user_id);
                $hofData=$this->PdfModel->getHOFByUserID($all_users[$i]->user_id);

                if($userdata!=null&&$businessData!=null&&$employeeData!=null&&$hofData!=null){
                    array_push($userList,$userdata);
                    array_push($businessList,$businessData);
                    array_push($employeeList,$employeeData);
                    array_push($hofList,$hofData);
                }
            }

            // echo "userlist:-".json_encode($userList);

            if(count($userList)>0){
                for($i=0;$i<count($userList);$i++){
                    $sheet->setCellValue('A'.($i+2),  $userList[$i]->salutation);
                    $sheet->setCellValue('B'.($i+2),  $userList[$i]->name);
                    $sheet->setCellValue('C'.($i+2),  $userList[$i]->dob);
                    $sheet->setCellValue('D'.($i+2),  $userList[$i]->mobile);
                    $sheet->setCellValue('E'.($i+2),  $userList[$i]->email_id);
                    $sheet->setCellValue('F'.($i+2),  $userList[$i]->company_name);
                    $sheet->setCellValue('G'.($i+2),  $userList[$i]->city);
                    $sheet->setCellValue('H'.($i+2),  $userList[$i]->aviva_emp_id);
                    $sheet->setCellValue('I'.($i+2),  $userList[$i]->added_on);


                    $sheet->setCellValue('J'.($i+2),  $businessList[$i]->q1);
                    $sheet->setCellValue('K'.($i+2),  $businessList[$i]->q1a);
                    $sheet->setCellValue('L'.($i+2),  $businessList[$i]->q2);
                    $sheet->setCellValue('M'.($i+2),  $businessList[$i]->q3);
                    $sheet->setCellValue('N'.($i+2),  $businessList[$i]->q4);
                    $sheet->setCellValue('O'.($i+2),  $businessList[$i]->q5);
                    $sheet->setCellValue('P'.($i+2),  $businessList[$i]->q5a);


                    $sheet->setCellValue('Q'.($i+2),  $employeeList[$i]->q1);
                    $sheet->setCellValue('R'.($i+2),  $employeeList[$i]->q2);
                    $sheet->setCellValue('S'.($i+2),  $employeeList[$i]->q3);
                    $sheet->setCellValue('T'.($i+2),  $employeeList[$i]->q4);
                    $sheet->setCellValue('U'.($i+2),  $employeeList[$i]->q5);
                    $sheet->setCellValue('V'.($i+2),  $employeeList[$i]->q6);

                    $sheet->setCellValue('W'.($i+2),  $hofList[$i]->q1);
                    $sheet->setCellValue('X'.($i+2),  $hofList[$i]->q2);
                    $sheet->setCellValue('Y'.($i+2),  $hofList[$i]->q3);
                    $sheet->setCellValue('Z'.($i+2),  $hofList[$i]->q4);
                    $sheet->setCellValue('AA'.($i+2),  $hofList[$i]->q5);
                    $sheet->setCellValue('AB'.($i+2),  $hofList[$i]->q6);
                    $sheet->setCellValue('AC'.($i+2),  $hofList[$i]->q7);
                    $sheet->setCellValue('AD'.($i+2),  $hofList[$i]->q8);
                    $sheet->setCellValue('AE'.($i+2),  $hofList[$i]->q9);
                    $sheet->setCellValue('AF'.($i+2),  $hofList[$i]->q10);
                }
            }


            $writer = new Xlsx($spreadsheet);


            $date = date('YmdHis');
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment;filename="data_'. $date .'.xlsx"'); 
            header('Cache-Control: max-age=0');
            
            $writer->save('php://output');


        }else{
        }
    }

    public function getShortLeadExcel_get(){


        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1',  'Salutation');
        $sheet->setCellValue('B1',  'Name');
        $sheet->setCellValue('C1',  'Date of Birth');
        $sheet->setCellValue('D1',  'Mobile Number');
        $sheet->setCellValue('E1',  'Email ID');
        $sheet->setCellValue('F1',  'Company Name');
        $sheet->setCellValue('G1',  'City');
        $sheet->setCellValue('H1',  'Aviva Employee Id');
        $sheet->setCellValue('I1',  'Added On');


        $from_date=$_GET["from_date"];
        $to_date=$_GET["to_date"];

        // echo "data";
        // $from_date=$this->parseTextRequest($_GET["from_date"]);
        // // $to_date=$this->parseTextRequest($_GET["to_date"]);

        // echo "<br>from_date:-".$from_date;
        // echo "<br>to_date:-".$to_date;
        // die();

        $all_users=$this->PdfModel->getAllUsersFROMTO($from_date,$to_date);
        // echo json_encode($all_users);

        if($all_users){
            $userList=array();
            for($i=0;$i<count($all_users);$i++){

                $userdata=$this->PdfModel->getUser($all_users[$i]->user_id);
                // echo json_encode($userdata);
                // echo json_encode($userdata);
                // echo "userdata:-".json_encode($userData);
                $businessData=$this->PdfModel->getBusinessByUserID($all_users[$i]->user_id);
                $employeeData=$this->PdfModel->getEmployerByUserID($all_users[$i]->user_id);
                $hofData=$this->PdfModel->getHOFByUserID($all_users[$i]->user_id);

                if($userdata!=null&&$businessData==null&&$employeeData==null&&$hofData==null){
                    array_push($userList,$userdata);
                }
            }

            // echo "userlist:-".json_encode($userList);

            if(count($userList)>0){
                for($i=0;$i<count($userList);$i++){
                    $sheet->setCellValue('A'.($i+2),  $userList[$i]->salutation);
                    $sheet->setCellValue('B'.($i+2),  $userList[$i]->name);
                    $sheet->setCellValue('C'.($i+2),  $userList[$i]->dob);
                    $sheet->setCellValue('D'.($i+2),  $userList[$i]->mobile);
                    $sheet->setCellValue('E'.($i+2),  $userList[$i]->email_id);
                    $sheet->setCellValue('F'.($i+2),  $userList[$i]->company_name);
                    $sheet->setCellValue('G'.($i+2),  $userList[$i]->city);
                    $sheet->setCellValue('H'.($i+2),  $userList[$i]->aviva_emp_id);
                    $sheet->setCellValue('I'.($i+2),  $userList[$i]->added_on);

                }
            }


            $writer = new Xlsx($spreadsheet);


            $date = date('YmdHis');
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment;filename="data_'. $date .'.xlsx"'); 
            header('Cache-Control: max-age=0');
            
            $writer->save('php://output');


        }else{
        }
    }

    public function insertUser_post(){

        $_POST = $this->parseRequest(json_decode(file_get_contents("php://input"), true));
        
    	$salutation=$this->input->post('salutation');
    	$name=$this->input->post('name');
    	$dob=$this->input->post('dob');
    	$mobile=$this->input->post('mobile');
    	$email_id=$this->input->post('email_id');
    	$company_name=$this->input->post('company_name');
    	$city=$this->input->post('city');
    	$aviva_emp_id=$this->input->post('aviva_emp_id');

    	$date = date('Y-m-d H:i:s');

    	$added_on=$date;

    	$data=$this->UserModel->insertUser($salutation,$name,$dob,$mobile,$email_id,$company_name,$city,$aviva_emp_id,$added_on);

        $response=array("response"=>$this->encryptResponse($data));

    	$this->set_response($response);
    }

	public function updateUser_post(){

		$_POST = $this->parseRequest(json_decode(file_get_contents("php://input"), true));

		$salutation=$this->input->post('salutation');
		$name=$this->input->post('name');
		$dob=$this->input->post('dob');
		$mobile=$this->input->post('mobile');
		$email_id=$this->input->post('email_id');
		$company_name=$this->input->post('company_name');
		$city=$this->input->post('city');
		$aviva_emp_id=$this->input->post('aviva_emp_id');
		$user_id=$this->input->post('user_id');

		$date = date('Y-m-d H:i:s');

		$added_on=$date;

		$data=$this->UserModel->updateUser($user_id,$salutation,$name,$dob,$mobile,$email_id,$company_name,$city,$aviva_emp_id,$added_on);

		$response=array("response"=>$this->encryptResponse($data));

		$this->set_response($response);
	}

    public function saveBusinessOwner_post(){
    
        $_POST = $this->parseRequest(json_decode(file_get_contents("php://input"), true));

    	$user_id=$this->input->post('user_id');
    	$q1=$this->input->post('q1');
    	$q1a=$this->input->post('q1a');
    	$q2=$this->input->post('q2');
    	$q3=$this->input->post('q3');
    	$q4=$this->input->post('q4');
    	$q5=$this->input->post('q5');
    	$q5a=$this->input->post('q5a');


    	$data=$this->UserModel->saveBusinessOwner($user_id,$q1,$q1a,$q2,$q3,$q4,$q5,$q5a);

        $response=array("response"=>$this->encryptResponse($data));

    	$this->set_response($response);
    }

    public function saveEmployer_post(){

        $_POST = $this->parseRequest(json_decode(file_get_contents("php://input"), true));
    
    	$user_id=$this->input->post('user_id');
    	$q1=$this->input->post('q1');
    	$q2=$this->input->post('q2');
    	$q3=$this->input->post('q3');
    	$q4=$this->input->post('q4');
    	$q5=$this->input->post('q5');
    	$q6=$this->input->post('q6');


    	$data=$this->UserModel->saveEmployer($user_id,$q1,$q2,$q3,$q4,$q5,$q6);

        $response=array("response"=>$this->encryptResponse($data));

    	$this->set_response($response);
    }

    public function saveHOF_post(){

        $_POST = $this->parseRequest(json_decode(file_get_contents("php://input"), true));
    
    	$user_id=$this->input->post('user_id');
    	$q1=$this->input->post('q1');
    	$q2=$this->input->post('q2');
    	$q3=$this->input->post('q3');
    	$q4=$this->input->post('q4');
    	$q5=$this->input->post('q5');
    	$q6=$this->input->post('q6');
    	$q7=$this->input->post('q7');
    	$q8=$this->input->post('q8');
    	$q9=$this->input->post('q9');
    	$q10=$this->input->post('q10');

    	$data=$this->UserModel->saveHOF($user_id,$q1,$q2,$q3,$q4,$q5,$q6,$q7,$q8,$q9,$q10);

        $response=array("response"=>$this->encryptResponse($data));

    	$this->set_response($response);
    }

    public function sendMail(){
            $mailData=$this->db->getOne('mail_setup');
            $Uname=$this->cryptFunction($mailData['username'], 'd');
            $passwrd=$this->cryptFunction($mailData['password'], 'd');
            $host=$this->cryptFunction($mailData['host'], 'd');
            $port=$this->cryptFunction($mailData['port'], 'd');
            $timeOut=$mailData['timeout'];
            $subject=$mailData['subject'];



            $mail = new \PHPMailer();
            $mail->IsSMTP();
            $mail->Host = $host;  // specify main and backup server
            $mail->Username = '';
            $mail->Password = '';
            $mail->SMTPAuth = false;
            $mail->Timeout = $timeOut;
            $mail->Port = $port;
            $mail->SMTPSecure = 'auto';

            $mail->From = $mailData['from_mail'];
            $mail->FromName = $mailData['from_name'];
            $mail->AddAddress($clientEmail, $Rname);
            $file_to_attach = 'pdf/';
            $fileNamepdfAttach = 'Aviva_SME_Assist_Report-'.$Rname.'.pdf';
            $mail->AddAttachment($fileName, $fileNamepdfAttach);
            $mail->IsHTML(true);

            //$file_to_attach = 'pdf/';
            //$mail->AddAttachment($fileName, $ClientfileName );

            //$mail->IsHTML(true);

            // set email format to HTML
            $mailHtml ='';
            $mailHtml .='<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">';
            $mailHtml .='<html lang="en">';
            $mailHtml .='<head>';
            $mailHtml .='<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
                          <meta name="viewport" content="width=device-width, initial-scale=1">
                          <meta http-equiv="X-UA-Compatible" content="IE=edge">
                          <title>SME mailer 2019</title>
                          <!--[if !mso]><!-->
                            <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,600,700" rel="stylesheet">
                          <!--<![endif]-->';

            $mailHtml .='<style type="text/css">
                        /* CLIENT-SPECIFIC STYLES */
                        body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
                        table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
                        img { -ms-interpolation-mode: bicubic; }
                        /* RESET STYLES */
                        img { border: 0; outline: none; text-decoration: none; }
                        table { border-collapse: collapse !important; }
                        body { margin: 0 !important; padding: 0 !important; width: 100% !important; }
                        /* iOS BLUE LINKS */
                        a[x-apple-data-detectors] {
                          color: inherit !important;
                          text-decoration: none !important;
                          font-size: inherit !important;
                          font-family: inherit !important;
                          font-weight: inherit !important;
                          line-height: inherit !important;
                        }
                        /* ANDROID CENTER FIX */
                        div[style*="margin: 16px 0;"] { margin: 0 !important; }
                      </style>';

            $mailHtml .= '</head>';
            $mailHtml .='<body style="margin:0; padding:0; background-color:#FFFFFF;">
                      <center>
                    
                        <div style="background-color:#FFFFFF; max-width: 700px; margin: auto;">
                        <!--[if mso]>
                        <table role="presentation" width="700" cellspacing="0" cellpadding="0" border="0" align="center">
                        <tr>
                        <td>
                        <![endif]-->
                    
                          <table width="700" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:700px; width:100%;" bgcolor="#a4d8e7">
                            <tr>
                              <td align="center" valign="top" style="padding:0;">
                                
                                <table width="700" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:700px; width:100%;">
                                  <tr>
                                    <td align="center" valign="top">
                                      <img src="https://www.avivaindia.com/sites/default/files/SME-mailer-revised-2_01.jpg" height="auto" style="max-width:700px; width:100%; min-width: 360px; overflow: hidden;" alt="">
                                    </td>
                                  </tr>
                                </table>
                    
                              </td>
                           </tr>
                            <tr>
                            <td align="left" valign="top" style="padding:10px 20px 0 20px; font-size:1rem; font-family: Source Sans Pro, arial, sans-serif; line-height:20px; text-align:justify; color:#123274;">';

            $mailHtml .='<p>
                Dear '.$clientName.',<br /><br />
                Thank you for your active participation.<br />
                Our proprietary business tool <strong>SME ASSIST</strong> understands and provides solutions for your business insurance needs.<br /><br /> 
                
                We have assessed your requirements and enclosed is a detailed analysis that consists of the insurance solutions to help fulfill your role and responsibilities as:
                              
                 </p>';
            
            $mailHtml .=' </td>
                    </tr>
            
                     <tr>
                      <td align="center" valign="top" style="padding:0;">
                        
                        <table width="700" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:700px; width:100%;">
                          <tr>
                            <td align="center" valign="top">
                              <img src="https://www.avivaindia.com/sites/default/files/SME-mailer-revised-2_03.jpg" height="auto" style="max-width:700px; width:100%; min-width: 360px; overflow: hidden;" alt="">
                            </td>
                          </tr>
                        </table>
            
                      </td>
                   </tr>
                   <tr>
                   <td align="left" valign="top" style="padding:10px 20px 0 20px; font-size:1rem; font-family: Source Sans Pro, arial, sans-serif; line-height:20px; text-align:justify; color:#123274;">
                    <p>
                        For further assistance, please contact us at any of the below mentioned touch points.<br /><br />
        
                            Regards<br />
                            Team Aviva<br /><br />                 
                    </p>
        
                  </td>
                </tr>';
            $mailHtml .='<tr>
         <td align="center" valign="top" style="padding:0;">
            <table width="700" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:700px; width:100%;">
              <tr>
                <td align="center" valign="top">
                 <img src="https://www.avivaindia.com/sites/default/files/MTB-BB-animated.gif" height="auto" style="max-width:700px; width:100%; min-width: 360px; overflow: hidden;"  alt="">
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
        <td height="60" bgcolor="#FFFFFF">
            <table width="680" height="60" border="0" cellpadding="0" cellspacing="0" align="center" style="max-width:700px; width:100%;">
            <tr>
                <td width="670" height="60" style="padding:0px;">
                    <a href="tel:18001037766" target="_blank" ><img src="https://www.avivaindia.com/sites/default/files/call-new.jpg" style="float:left; margin:0px;"/></a>
                    <a href="mailto:customerservices@avivaindia.com" target="_blank" ><img src="https://www.avivaindia.com/sites/default/files/mail-new.jpg" style="float:left; margin:0px;"/></a>
                    <a href="https://www.avivaindia.com/" target="_blank" ><img src="https://www.avivaindia.com/sites/default/files/web-new.jpg" style="float:left; margin:0px;"/></a>
                    <a href="https://www.youtube.com/user/avivalifeinsurance" target="_blank"><img src="https://www.avivaindia.com/sites/default/files/YT-new.jpg" style="float:right; margin:0px;"/></a>
                    <a href="https://www.instagram.com/aviva_ind/" target="_blank"><img src="https://www.avivaindia.com/sites/default/files/insta-new.jpg" style="float:right; margin:0px;"/></a>
                    <a href="https://twitter.com/avivaindia" target="_blank"><img src="https://www.avivaindia.com/sites/default/files/tw-new.jpg" style="float:right; margin:0px;"/></a>
                    <a href="https://www.facebook.com/AvivaIndia" target="_blank"><img src="https://www.avivaindia.com/sites/default/files/fb-new.jpg" style="float:right; margin:0px;"/></a>
                </td>
            </tr>
            </table>
        </td>
        </tr>
        <tr>
            <td width="680" height="auto" style="max-width:700px; width:100%; ">
            <table width="100%" cellspacing="0" cellpadding="0" bgcolor="#e8e8e8">
              <tbody>
                  <tr>   
                    <td style="padding:0px 20px;text-align: justify; background-color:#e8e8e8; font-family: "Source Sans Pro", arial, sans-serif;">
                        <p style="font-size:0.7rem;border:1px solid #333;border-radius: 5px;padding: 5px; text-align: center;"><strong>BEWARE OF SPURIOUS/FRAUD PHONE CALLS!</strong> IRDAI is not involved in activities like selling insurance policies, announcing bonus or investment of premiums. Public receiving such phone calls are requested to lodge a police complaint.
            </p>                        <p style="font-size:0.7rem;font-family:Times New Roman, Times, serif;padding-bottom: 10px;">
            Trade logo displayed above belongs to Aviva Brands Limited and is used by Aviva Life Insurance Company India Limited under License. Aviva Life Insurance Company India Limited. IRDA of India No. 122. For more details on risk factors and terms and conditions, please read the sales brochure carefully before concluding a sale. Tax benefits are as per existing tax laws which are subject to change. Registered Office Address-2nd floor, Prakashdeep Building, 7, Tolstoy Marg, New Delhi - 110001. Telephone number.: 0124-2709000, Fax number: 0124-2571210, E-mail: customerservices@avivaindia.com, Helpline number: 1800-180-22-66/1800-103-77-66, Website: www.avivaindia.com, CIN:U66010DL2000PLC107880, Advt. No. Jul 34/19<br /><br /></p>
                                </td>
                              </tr>
                           </tbody>
                        </table>
                        </td>
                    </tr>
                  </table>
            
                  
            
                <!--[if mso]>
                </td>
                </tr>
                </table>
                <![endif]-->
                </div>
            
              </center>
            </body>
            </html>';

            $mail->Subject = $subject;
            $mail->Body    = "$mailHtml";
    }
    
        
}

?>
